module Graphics.XHB.Gen.XvMC.Types
       (deserializeError, deserializeEvent, CONTEXT, SURFACE, SUBPICTURE,
        SurfaceInfo(..), QueryVersion(..), QueryVersionReply(..),
        ListSurfaceTypes(..), ListSurfaceTypesReply(..), CreateContext(..),
        CreateContextReply(..), DestroyContext(..), CreateSurface(..),
        CreateSurfaceReply(..), DestroySurface(..), CreateSubpicture(..),
        CreateSubpictureReply(..), DestroySubpicture(..),
        ListSubpictureTypes(..), ListSubpictureTypesReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xv.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xv.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
newtype CONTEXT = MkCONTEXT Xid
                  deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype SURFACE = MkSURFACE Xid
                  deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype SUBPICTURE = MkSUBPICTURE Xid
                     deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
data SurfaceInfo = MkSurfaceInfo{id_SurfaceInfo :: SURFACE,
                                 chroma_format_SurfaceInfo :: Word16, pad0_SurfaceInfo :: Word16,
                                 max_width_SurfaceInfo :: Word16, max_height_SurfaceInfo :: Word16,
                                 subpicture_max_width_SurfaceInfo :: Word16,
                                 subpicture_max_height_SurfaceInfo :: Word16,
                                 mc_type_SurfaceInfo :: Word32, flags_SurfaceInfo :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Serialize SurfaceInfo where
        serialize x
          = do serialize (id_SurfaceInfo x)
               serialize (chroma_format_SurfaceInfo x)
               serialize (pad0_SurfaceInfo x)
               serialize (max_width_SurfaceInfo x)
               serialize (max_height_SurfaceInfo x)
               serialize (subpicture_max_width_SurfaceInfo x)
               serialize (subpicture_max_height_SurfaceInfo x)
               serialize (mc_type_SurfaceInfo x)
               serialize (flags_SurfaceInfo x)
        size x
          = size (id_SurfaceInfo x) + size (chroma_format_SurfaceInfo x) +
              size (pad0_SurfaceInfo x)
              + size (max_width_SurfaceInfo x)
              + size (max_height_SurfaceInfo x)
              + size (subpicture_max_width_SurfaceInfo x)
              + size (subpicture_max_height_SurfaceInfo x)
              + size (mc_type_SurfaceInfo x)
              + size (flags_SurfaceInfo x)
 
instance Deserialize SurfaceInfo where
        deserialize
          = do id <- deserialize
               chroma_format <- deserialize
               pad0 <- deserialize
               max_width <- deserialize
               max_height <- deserialize
               subpicture_max_width <- deserialize
               subpicture_max_height <- deserialize
               mc_type <- deserialize
               flags <- deserialize
               return
                 (MkSurfaceInfo id chroma_format pad0 max_width max_height
                    subpicture_max_width
                    subpicture_max_height
                    mc_type
                    flags)
 
data QueryVersion = MkQueryVersion{}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_QueryVersionReply
                                             :: Word32,
                                             minor_QueryVersionReply :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major <- deserialize
               minor <- deserialize
               let _ = isCard32 length
               return (MkQueryVersionReply major minor)
 
data ListSurfaceTypes = MkListSurfaceTypes{port_id_ListSurfaceTypes
                                           :: PORT}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ListSurfaceTypes where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4 + size (port_id_ListSurfaceTypes x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (port_id_ListSurfaceTypes x)
               putSkip (requiredPadding size__)
 
data ListSurfaceTypesReply = MkListSurfaceTypesReply{num_ListSurfaceTypesReply
                                                     :: Word32,
                                                     surfaces_ListSurfaceTypesReply ::
                                                     [SurfaceInfo]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ListSurfaceTypesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num <- deserialize
               skip 20
               surfaces <- deserializeList (fromIntegral num)
               let _ = isCard32 length
               return (MkListSurfaceTypesReply num surfaces)
 
data CreateContext = MkCreateContext{context_id_CreateContext ::
                                     CONTEXT,
                                     port_id_CreateContext :: PORT,
                                     surface_id_CreateContext :: SURFACE,
                                     width_CreateContext :: Word16, height_CreateContext :: Word16,
                                     flags_CreateContext :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateContext where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (context_id_CreateContext x) +
                         size (port_id_CreateContext x)
                         + size (surface_id_CreateContext x)
                         + size (width_CreateContext x)
                         + size (height_CreateContext x)
                         + size (flags_CreateContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_id_CreateContext x)
               serialize (port_id_CreateContext x)
               serialize (surface_id_CreateContext x)
               serialize (width_CreateContext x)
               serialize (height_CreateContext x)
               serialize (flags_CreateContext x)
               putSkip (requiredPadding size__)
 
data CreateContextReply = MkCreateContextReply{width_actual_CreateContextReply
                                               :: Word16,
                                               height_actual_CreateContextReply :: Word16,
                                               flags_return_CreateContextReply :: Word32,
                                               priv_data_CreateContextReply :: [Word32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize CreateContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               width_actual <- deserialize
               height_actual <- deserialize
               flags_return <- deserialize
               skip 20
               priv_data <- deserializeList (fromIntegral length)
               let _ = isCard32 length
               return
                 (MkCreateContextReply width_actual height_actual flags_return
                    priv_data)
 
data DestroyContext = MkDestroyContext{context_id_DestroyContext ::
                                       CONTEXT}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyContext where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__ = 4 + size (context_id_DestroyContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_id_DestroyContext x)
               putSkip (requiredPadding size__)
 
data CreateSurface = MkCreateSurface{surface_id_CreateSurface ::
                                     SURFACE,
                                     context_id_CreateSurface :: CONTEXT}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateSurface where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__
                     = 4 + size (surface_id_CreateSurface x) +
                         size (context_id_CreateSurface x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (surface_id_CreateSurface x)
               serialize (context_id_CreateSurface x)
               putSkip (requiredPadding size__)
 
data CreateSurfaceReply = MkCreateSurfaceReply{priv_data_CreateSurfaceReply
                                               :: [Word32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize CreateSurfaceReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               priv_data <- deserializeList (fromIntegral length)
               let _ = isCard32 length
               return (MkCreateSurfaceReply priv_data)
 
data DestroySurface = MkDestroySurface{surface_id_DestroySurface ::
                                       SURFACE}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroySurface where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__ = 4 + size (surface_id_DestroySurface x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (surface_id_DestroySurface x)
               putSkip (requiredPadding size__)
 
data CreateSubpicture = MkCreateSubpicture{subpicture_id_CreateSubpicture
                                           :: SUBPICTURE,
                                           context_CreateSubpicture :: CONTEXT,
                                           xvimage_id_CreateSubpicture :: Word32,
                                           width_CreateSubpicture :: Word16,
                                           height_CreateSubpicture :: Word16}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateSubpicture where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__
                     = 4 + size (subpicture_id_CreateSubpicture x) +
                         size (context_CreateSubpicture x)
                         + size (xvimage_id_CreateSubpicture x)
                         + size (width_CreateSubpicture x)
                         + size (height_CreateSubpicture x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (subpicture_id_CreateSubpicture x)
               serialize (context_CreateSubpicture x)
               serialize (xvimage_id_CreateSubpicture x)
               serialize (width_CreateSubpicture x)
               serialize (height_CreateSubpicture x)
               putSkip (requiredPadding size__)
 
data CreateSubpictureReply = MkCreateSubpictureReply{width_actual_CreateSubpictureReply
                                                     :: Word16,
                                                     height_actual_CreateSubpictureReply :: Word16,
                                                     num_palette_entries_CreateSubpictureReply ::
                                                     Word16,
                                                     entry_bytes_CreateSubpictureReply :: Word16,
                                                     component_order_CreateSubpictureReply ::
                                                     [Word8],
                                                     priv_data_CreateSubpictureReply :: [Word32]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize CreateSubpictureReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               width_actual <- deserialize
               height_actual <- deserialize
               num_palette_entries <- deserialize
               entry_bytes <- deserialize
               component_order <- deserializeList (fromIntegral 4)
               skip 12
               priv_data <- deserializeList (fromIntegral length)
               let _ = isCard32 length
               return
                 (MkCreateSubpictureReply width_actual height_actual
                    num_palette_entries
                    entry_bytes
                    component_order
                    priv_data)
 
data DestroySubpicture = MkDestroySubpicture{subpicture_id_DestroySubpicture
                                             :: SUBPICTURE}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroySubpicture where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4 + size (subpicture_id_DestroySubpicture x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (subpicture_id_DestroySubpicture x)
               putSkip (requiredPadding size__)
 
data ListSubpictureTypes = MkListSubpictureTypes{port_id_ListSubpictureTypes
                                                 :: PORT,
                                                 surface_id_ListSubpictureTypes :: SURFACE}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ListSubpictureTypes where
        extensionId _ = "XVideo-MotionCompensation"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__
                     = 4 + size (port_id_ListSubpictureTypes x) +
                         size (surface_id_ListSubpictureTypes x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (port_id_ListSubpictureTypes x)
               serialize (surface_id_ListSubpictureTypes x)
               putSkip (requiredPadding size__)
 
data ListSubpictureTypesReply = MkListSubpictureTypesReply{num_ListSubpictureTypesReply
                                                           :: Word32,
                                                           types_ListSubpictureTypesReply ::
                                                           [ImageFormatInfo]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ListSubpictureTypesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num <- deserialize
               skip 20
               types <- deserializeList (fromIntegral num)
               let _ = isCard32 length
               return (MkListSubpictureTypesReply num types)