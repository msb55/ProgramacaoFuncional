module Graphics.XHB.Gen.Composite
       (extension, queryVersion, redirectWindow, redirectSubwindows,
        unredirectWindow, unredirectSubwindows, createRegionFromBorderClip,
        nameWindowPixmap, getOverlayWindow, releaseOverlayWindow,
        module Graphics.XHB.Gen.Composite.Types)
       where
import Graphics.XHB.Gen.Composite.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
import Graphics.XHB.Gen.XFixes.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.XFixes.Types
 
extension :: ExtensionId
extension = "Composite"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word32 -> Word32 -> IO (Receipt QueryVersionReply)
queryVersion c client_major_version client_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion client_major_version client_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
redirectWindow ::
                 Graphics.XHB.Connection.Types.Connection ->
                   WINDOW -> Redirect -> IO ()
redirectWindow c window update
  = do let req = MkRedirectWindow window update
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
redirectSubwindows ::
                     Graphics.XHB.Connection.Types.Connection ->
                       WINDOW -> Redirect -> IO ()
redirectSubwindows c window update
  = do let req = MkRedirectSubwindows window update
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
unredirectWindow ::
                   Graphics.XHB.Connection.Types.Connection ->
                     WINDOW -> Redirect -> IO ()
unredirectWindow c window update
  = do let req = MkUnredirectWindow window update
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
unredirectSubwindows ::
                       Graphics.XHB.Connection.Types.Connection ->
                         WINDOW -> Redirect -> IO ()
unredirectSubwindows c window update
  = do let req = MkUnredirectSubwindows window update
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createRegionFromBorderClip ::
                             Graphics.XHB.Connection.Types.Connection ->
                               REGION -> WINDOW -> IO ()
createRegionFromBorderClip c region window
  = do let req = MkCreateRegionFromBorderClip region window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
nameWindowPixmap ::
                   Graphics.XHB.Connection.Types.Connection ->
                     WINDOW -> PIXMAP -> IO ()
nameWindowPixmap c window pixmap
  = do let req = MkNameWindowPixmap window pixmap
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getOverlayWindow ::
                   Graphics.XHB.Connection.Types.Connection ->
                     WINDOW -> IO (Receipt WINDOW)
getOverlayWindow c window
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (overlay_win_GetOverlayWindowReply `fmap` deserialize))
       let req = MkGetOverlayWindow window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
releaseOverlayWindow ::
                       Graphics.XHB.Connection.Types.Connection -> WINDOW -> IO ()
releaseOverlayWindow c window
  = do let req = MkReleaseOverlayWindow window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk