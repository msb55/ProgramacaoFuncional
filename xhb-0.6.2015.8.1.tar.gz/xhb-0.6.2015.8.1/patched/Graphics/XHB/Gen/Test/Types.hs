module Graphics.XHB.Gen.Test.Types
       (deserializeError, deserializeEvent, GetVersion(..),
        GetVersionReply(..), Cursor(..), CompareCursor(..),
        CompareCursorReply(..), FakeInput(..), GrabControl(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (Cursor(..), deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data GetVersion = MkGetVersion{major_version_GetVersion :: Word8,
                               minor_version_GetVersion :: Word16}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetVersion where
        extensionId _ = "XTEST"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (major_version_GetVersion x) + 1 +
                         size (minor_version_GetVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (major_version_GetVersion x)
               putSkip 1
               serialize (minor_version_GetVersion x)
               putSkip (requiredPadding size__)
 
data GetVersionReply = MkGetVersionReply{major_version_GetVersionReply
                                         :: Word8,
                                         minor_version_GetVersionReply :: Word16}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetVersionReply where
        deserialize
          = do skip 1
               major_version <- deserialize
               skip 2
               length <- deserialize
               minor_version <- deserialize
               let _ = isCard32 length
               return (MkGetVersionReply major_version minor_version)
 
data Cursor = CursorNone
            | CursorCurrent
            deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Cursor where
        toValue CursorNone{} = 0
        toValue CursorCurrent{} = 1
        fromValue 0 = CursorNone
        fromValue 1 = CursorCurrent
 
data CompareCursor = MkCompareCursor{window_CompareCursor ::
                                     WINDOW,
                                     cursor_CompareCursor :: CURSOR}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CompareCursor where
        extensionId _ = "XTEST"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (window_CompareCursor x) + size (cursor_CompareCursor x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_CompareCursor x)
               serialize (cursor_CompareCursor x)
               putSkip (requiredPadding size__)
 
data CompareCursorReply = MkCompareCursorReply{same_CompareCursorReply
                                               :: Bool}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize CompareCursorReply where
        deserialize
          = do skip 1
               same <- deserialize
               skip 2
               length <- deserialize
               let _ = isCard32 length
               return (MkCompareCursorReply same)
 
data FakeInput = MkFakeInput{type_FakeInput :: Word8,
                             detail_FakeInput :: Word8, time_FakeInput :: Word32,
                             root_FakeInput :: WINDOW, rootX_FakeInput :: Word16,
                             rootY_FakeInput :: Word16, deviceid_FakeInput :: Word8}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest FakeInput where
        extensionId _ = "XTEST"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (type_FakeInput x) + size (detail_FakeInput x) + 2 +
                         size (time_FakeInput x)
                         + size (root_FakeInput x)
                         + 8
                         + size (rootX_FakeInput x)
                         + size (rootY_FakeInput x)
                         + 7
                         + size (deviceid_FakeInput x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (type_FakeInput x)
               serialize (detail_FakeInput x)
               putSkip 2
               serialize (time_FakeInput x)
               serialize (root_FakeInput x)
               putSkip 8
               serialize (rootX_FakeInput x)
               serialize (rootY_FakeInput x)
               putSkip 7
               serialize (deviceid_FakeInput x)
               putSkip (requiredPadding size__)
 
data GrabControl = MkGrabControl{impervious_GrabControl :: Bool}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GrabControl where
        extensionId _ = "XTEST"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__ = 4 + size (impervious_GrabControl x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (impervious_GrabControl x)
               putSkip 3
               putSkip (requiredPadding size__)