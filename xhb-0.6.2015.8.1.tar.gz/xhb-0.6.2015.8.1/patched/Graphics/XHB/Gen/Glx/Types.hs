module Graphics.XHB.Gen.Glx.Types
       (deserializeError, deserializeEvent, PIXMAP, CONTEXT, PBUFFER,
        WINDOW, FBCONFIG, DRAWABLE, FLOAT32, FLOAT64, BOOL32, CONTEXT_TAG,
        GenericError(..), BadContextError(..), BadContextStateError(..),
        BadDrawableError(..), BadPixmapError(..), BadContextTagError(..),
        BadCurrentWindowError(..), BadRenderRequestError(..),
        BadLargeRequestError(..), UnsupportedPrivateRequestError(..),
        BadFBConfigError(..), BadPbufferError(..),
        BadCurrentDrawableError(..), BadWindowError(..),
        PbufferClobberEvent(..), PBCET(..), PBCDT(..), Render(..),
        RenderLarge(..), CreateContext(..), DestroyContext(..),
        MakeCurrent(..), MakeCurrentReply(..), IsDirect(..),
        IsDirectReply(..), QueryVersion(..), QueryVersionReply(..),
        WaitGL(..), WaitX(..), CopyContext(..), GC(..), SwapBuffers(..),
        UseXFont(..), CreateGLXPixmap(..), GetVisualConfigs(..),
        GetVisualConfigsReply(..), DestroyGLXPixmap(..), VendorPrivate(..),
        VendorPrivateWithReply(..), VendorPrivateWithReplyReply(..),
        QueryExtensionsString(..), QueryExtensionsStringReply(..),
        QueryServerString(..), QueryServerStringReply(..), ClientInfo(..),
        GetFBConfigs(..), GetFBConfigsReply(..), CreatePixmap(..),
        DestroyPixmap(..), CreateNewContext(..), QueryContext(..),
        QueryContextReply(..), MakeContextCurrent(..),
        MakeContextCurrentReply(..), CreatePbuffer(..), DestroyPbuffer(..),
        GetDrawableAttributes(..), GetDrawableAttributesReply(..),
        ChangeDrawableAttributes(..), CreateWindow(..), DeleteWindow(..),
        NewList(..), EndList(..), DeleteLists(..), GenLists(..),
        GenListsReply(..), FeedbackBuffer(..), SelectBuffer(..),
        RenderMode(..), RenderModeReply(..), RM(..), Finish(..),
        FinishReply(..), PixelStoref(..), PixelStorei(..), ReadPixels(..),
        ReadPixelsReply(..), GetBooleanv(..), GetBooleanvReply(..),
        GetClipPlane(..), GetClipPlaneReply(..), GetDoublev(..),
        GetDoublevReply(..), GetError(..), GetErrorReply(..),
        GetFloatv(..), GetFloatvReply(..), GetIntegerv(..),
        GetIntegervReply(..), GetLightfv(..), GetLightfvReply(..),
        GetLightiv(..), GetLightivReply(..), GetMapdv(..),
        GetMapdvReply(..), GetMapfv(..), GetMapfvReply(..), GetMapiv(..),
        GetMapivReply(..), GetMaterialfv(..), GetMaterialfvReply(..),
        GetMaterialiv(..), GetMaterialivReply(..), GetPixelMapfv(..),
        GetPixelMapfvReply(..), GetPixelMapuiv(..),
        GetPixelMapuivReply(..), GetPixelMapusv(..),
        GetPixelMapusvReply(..), GetPolygonStipple(..),
        GetPolygonStippleReply(..), GetString(..), GetStringReply(..),
        GetTexEnvfv(..), GetTexEnvfvReply(..), GetTexEnviv(..),
        GetTexEnvivReply(..), GetTexGendv(..), GetTexGendvReply(..),
        GetTexGenfv(..), GetTexGenfvReply(..), GetTexGeniv(..),
        GetTexGenivReply(..), GetTexImage(..), GetTexImageReply(..),
        GetTexParameterfv(..), GetTexParameterfvReply(..),
        GetTexParameteriv(..), GetTexParameterivReply(..),
        GetTexLevelParameterfv(..), GetTexLevelParameterfvReply(..),
        GetTexLevelParameteriv(..), GetTexLevelParameterivReply(..),
        IsList(..), IsListReply(..), Flush(..), AreTexturesResident(..),
        AreTexturesResidentReply(..), DeleteTextures(..), GenTextures(..),
        GenTexturesReply(..), IsTexture(..), IsTextureReply(..),
        GetColorTable(..), GetColorTableReply(..),
        GetColorTableParameterfv(..), GetColorTableParameterfvReply(..),
        GetColorTableParameteriv(..), GetColorTableParameterivReply(..),
        GetConvolutionFilter(..), GetConvolutionFilterReply(..),
        GetConvolutionParameterfv(..), GetConvolutionParameterfvReply(..),
        GetConvolutionParameteriv(..), GetConvolutionParameterivReply(..),
        GetSeparableFilter(..), GetSeparableFilterReply(..),
        GetHistogram(..), GetHistogramReply(..),
        GetHistogramParameterfv(..), GetHistogramParameterfvReply(..),
        GetHistogramParameteriv(..), GetHistogramParameterivReply(..),
        GetMinmax(..), GetMinmaxReply(..), GetMinmaxParameterfv(..),
        GetMinmaxParameterfvReply(..), GetMinmaxParameteriv(..),
        GetMinmaxParameterivReply(..), GetCompressedTexImageARB(..),
        GetCompressedTexImageARBReply(..), DeleteQueriesARB(..),
        GenQueriesARB(..), GenQueriesARBReply(..), IsQueryARB(..),
        IsQueryARBReply(..), GetQueryivARB(..), GetQueryivARBReply(..),
        GetQueryObjectivARB(..), GetQueryObjectivARBReply(..),
        GetQueryObjectuivARB(..), GetQueryObjectuivARBReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (PIXMAP(..), WINDOW(..), DRAWABLE(..), GC(..),
               CreatePixmap(..), CreateWindow(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError 0
  = return (liftM toError (deserialize :: Get BadContextError))
deserializeError 1
  = return (liftM toError (deserialize :: Get BadContextStateError))
deserializeError 2
  = return (liftM toError (deserialize :: Get BadDrawableError))
deserializeError 3
  = return (liftM toError (deserialize :: Get BadPixmapError))
deserializeError 4
  = return (liftM toError (deserialize :: Get BadContextTagError))
deserializeError 5
  = return (liftM toError (deserialize :: Get BadCurrentWindowError))
deserializeError 6
  = return (liftM toError (deserialize :: Get BadRenderRequestError))
deserializeError 7
  = return (liftM toError (deserialize :: Get BadLargeRequestError))
deserializeError 8
  = return
      (liftM toError (deserialize :: Get UnsupportedPrivateRequestError))
deserializeError 9
  = return (liftM toError (deserialize :: Get BadFBConfigError))
deserializeError 10
  = return (liftM toError (deserialize :: Get BadPbufferError))
deserializeError 11
  = return
      (liftM toError (deserialize :: Get BadCurrentDrawableError))
deserializeError 12
  = return (liftM toError (deserialize :: Get BadWindowError))
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get PbufferClobberEvent))
deserializeEvent _ = Nothing
 
newtype PIXMAP = MkPIXMAP Xid
                 deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype CONTEXT = MkCONTEXT Xid
                  deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype PBUFFER = MkPBUFFER Xid
                  deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype WINDOW = MkWINDOW Xid
                 deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype FBCONFIG = MkFBCONFIG Xid
                   deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype DRAWABLE = MkDRAWABLE Xid
                   deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
type FLOAT32 = CFloat
 
type FLOAT64 = CDouble
 
type BOOL32 = Word32
 
type CONTEXT_TAG = Word32
 
data GenericError = MkGenericError{bad_value_GenericError ::
                                   Word32,
                                   minor_opcode_GenericError :: Word16,
                                   major_opcode_GenericError :: Word8}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error GenericError
 
instance Deserialize GenericError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkGenericError bad_value minor_opcode major_opcode)
 
data BadContextError = MkBadContextError{bad_value_BadContextError
                                         :: Word32,
                                         minor_opcode_BadContextError :: Word16,
                                         major_opcode_BadContextError :: Word8}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadContextError
 
instance Deserialize BadContextError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadContextError bad_value minor_opcode major_opcode)
 
data BadContextStateError = MkBadContextStateError{bad_value_BadContextStateError
                                                   :: Word32,
                                                   minor_opcode_BadContextStateError :: Word16,
                                                   major_opcode_BadContextStateError :: Word8}
                          deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadContextStateError
 
instance Deserialize BadContextStateError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadContextStateError bad_value minor_opcode major_opcode)
 
data BadDrawableError = MkBadDrawableError{bad_value_BadDrawableError
                                           :: Word32,
                                           minor_opcode_BadDrawableError :: Word16,
                                           major_opcode_BadDrawableError :: Word8}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadDrawableError
 
instance Deserialize BadDrawableError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadDrawableError bad_value minor_opcode major_opcode)
 
data BadPixmapError = MkBadPixmapError{bad_value_BadPixmapError ::
                                       Word32,
                                       minor_opcode_BadPixmapError :: Word16,
                                       major_opcode_BadPixmapError :: Word8}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadPixmapError
 
instance Deserialize BadPixmapError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadPixmapError bad_value minor_opcode major_opcode)
 
data BadContextTagError = MkBadContextTagError{bad_value_BadContextTagError
                                               :: Word32,
                                               minor_opcode_BadContextTagError :: Word16,
                                               major_opcode_BadContextTagError :: Word8}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadContextTagError
 
instance Deserialize BadContextTagError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadContextTagError bad_value minor_opcode major_opcode)
 
data BadCurrentWindowError = MkBadCurrentWindowError{bad_value_BadCurrentWindowError
                                                     :: Word32,
                                                     minor_opcode_BadCurrentWindowError :: Word16,
                                                     major_opcode_BadCurrentWindowError :: Word8}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadCurrentWindowError
 
instance Deserialize BadCurrentWindowError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return
                 (MkBadCurrentWindowError bad_value minor_opcode major_opcode)
 
data BadRenderRequestError = MkBadRenderRequestError{bad_value_BadRenderRequestError
                                                     :: Word32,
                                                     minor_opcode_BadRenderRequestError :: Word16,
                                                     major_opcode_BadRenderRequestError :: Word8}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadRenderRequestError
 
instance Deserialize BadRenderRequestError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return
                 (MkBadRenderRequestError bad_value minor_opcode major_opcode)
 
data BadLargeRequestError = MkBadLargeRequestError{bad_value_BadLargeRequestError
                                                   :: Word32,
                                                   minor_opcode_BadLargeRequestError :: Word16,
                                                   major_opcode_BadLargeRequestError :: Word8}
                          deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadLargeRequestError
 
instance Deserialize BadLargeRequestError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadLargeRequestError bad_value minor_opcode major_opcode)
 
data UnsupportedPrivateRequestError = MkUnsupportedPrivateRequestError{bad_value_UnsupportedPrivateRequestError
                                                                       :: Word32,
                                                                       minor_opcode_UnsupportedPrivateRequestError
                                                                       :: Word16,
                                                                       major_opcode_UnsupportedPrivateRequestError
                                                                       :: Word8}
                                    deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error UnsupportedPrivateRequestError
 
instance Deserialize UnsupportedPrivateRequestError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return
                 (MkUnsupportedPrivateRequestError bad_value minor_opcode
                    major_opcode)
 
data BadFBConfigError = MkBadFBConfigError{bad_value_BadFBConfigError
                                           :: Word32,
                                           minor_opcode_BadFBConfigError :: Word16,
                                           major_opcode_BadFBConfigError :: Word8}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadFBConfigError
 
instance Deserialize BadFBConfigError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadFBConfigError bad_value minor_opcode major_opcode)
 
data BadPbufferError = MkBadPbufferError{bad_value_BadPbufferError
                                         :: Word32,
                                         minor_opcode_BadPbufferError :: Word16,
                                         major_opcode_BadPbufferError :: Word8}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadPbufferError
 
instance Deserialize BadPbufferError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadPbufferError bad_value minor_opcode major_opcode)
 
data BadCurrentDrawableError = MkBadCurrentDrawableError{bad_value_BadCurrentDrawableError
                                                         :: Word32,
                                                         minor_opcode_BadCurrentDrawableError ::
                                                         Word16,
                                                         major_opcode_BadCurrentDrawableError ::
                                                         Word8}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadCurrentDrawableError
 
instance Deserialize BadCurrentDrawableError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return
                 (MkBadCurrentDrawableError bad_value minor_opcode major_opcode)
 
data BadWindowError = MkBadWindowError{bad_value_BadWindowError ::
                                       Word32,
                                       minor_opcode_BadWindowError :: Word16,
                                       major_opcode_BadWindowError :: Word8}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadWindowError
 
instance Deserialize BadWindowError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 21
               return (MkBadWindowError bad_value minor_opcode major_opcode)
 
data PbufferClobberEvent = MkPbufferClobberEvent{event_type_PbufferClobberEvent
                                                 :: Word16,
                                                 draw_type_PbufferClobberEvent :: Word16,
                                                 drawable_PbufferClobberEvent ::
                                                 Graphics.XHB.Gen.Glx.Types.DRAWABLE,
                                                 b_mask_PbufferClobberEvent :: Word32,
                                                 aux_buffer_PbufferClobberEvent :: Word16,
                                                 x_PbufferClobberEvent :: Word16,
                                                 y_PbufferClobberEvent :: Word16,
                                                 width_PbufferClobberEvent :: Word16,
                                                 height_PbufferClobberEvent :: Word16,
                                                 count_PbufferClobberEvent :: Word16}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event PbufferClobberEvent
 
instance Deserialize PbufferClobberEvent where
        deserialize
          = do skip 1
               skip 1
               skip 2
               event_type <- deserialize
               draw_type <- deserialize
               drawable <- deserialize
               b_mask <- deserialize
               aux_buffer <- deserialize
               x <- deserialize
               y <- deserialize
               width <- deserialize
               height <- deserialize
               count <- deserialize
               skip 4
               return
                 (MkPbufferClobberEvent event_type draw_type drawable b_mask
                    aux_buffer
                    x
                    y
                    width
                    height
                    count)
 
data PBCET = PBCETDamaged
           | PBCETSaved
           deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum PBCET where
        toValue PBCETDamaged{} = 32791
        toValue PBCETSaved{} = 32792
        fromValue 32791 = PBCETDamaged
        fromValue 32792 = PBCETSaved
 
data PBCDT = PBCDTWindow
           | PBCDTPbuffer
           deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum PBCDT where
        toValue PBCDTWindow{} = 32793
        toValue PBCDTPbuffer{} = 32794
        fromValue 32793 = PBCDTWindow
        fromValue 32794 = PBCDTPbuffer
 
data Render = MkRender{context_tag_Render :: CONTEXT_TAG,
                       data_Render :: [Word8]}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Render where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (context_tag_Render x) + sum (map size (data_Render x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_Render x)
               serializeList (data_Render x)
               putSkip (requiredPadding size__)
 
data RenderLarge = MkRenderLarge{context_tag_RenderLarge ::
                                 CONTEXT_TAG,
                                 request_num_RenderLarge :: Word16,
                                 request_total_RenderLarge :: Word16,
                                 data_len_RenderLarge :: Word32, data_RenderLarge :: [Word8]}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest RenderLarge where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (context_tag_RenderLarge x) +
                         size (request_num_RenderLarge x)
                         + size (request_total_RenderLarge x)
                         + size (data_len_RenderLarge x)
                         + sum (map size (data_RenderLarge x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_RenderLarge x)
               serialize (request_num_RenderLarge x)
               serialize (request_total_RenderLarge x)
               serialize (data_len_RenderLarge x)
               serializeList (data_RenderLarge x)
               putSkip (requiredPadding size__)
 
data CreateContext = MkCreateContext{context_CreateContext ::
                                     Graphics.XHB.Gen.Glx.Types.CONTEXT,
                                     visual_CreateContext :: VISUALID,
                                     screen_CreateContext :: Word32,
                                     share_list_CreateContext :: Graphics.XHB.Gen.Glx.Types.CONTEXT,
                                     is_direct_CreateContext :: Bool}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateContext where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (context_CreateContext x) +
                         size (visual_CreateContext x)
                         + size (screen_CreateContext x)
                         + size (share_list_CreateContext x)
                         + size (is_direct_CreateContext x)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_CreateContext x)
               serialize (visual_CreateContext x)
               serialize (screen_CreateContext x)
               serialize (share_list_CreateContext x)
               serialize (is_direct_CreateContext x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data DestroyContext = MkDestroyContext{context_DestroyContext ::
                                       Graphics.XHB.Gen.Glx.Types.CONTEXT}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyContext where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4 + size (context_DestroyContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_DestroyContext x)
               putSkip (requiredPadding size__)
 
data MakeCurrent = MkMakeCurrent{drawable_MakeCurrent ::
                                 Graphics.XHB.Gen.Glx.Types.DRAWABLE,
                                 context_MakeCurrent :: Graphics.XHB.Gen.Glx.Types.CONTEXT,
                                 old_context_tag_MakeCurrent :: CONTEXT_TAG}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest MakeCurrent where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (drawable_MakeCurrent x) + size (context_MakeCurrent x)
                         + size (old_context_tag_MakeCurrent x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_MakeCurrent x)
               serialize (context_MakeCurrent x)
               serialize (old_context_tag_MakeCurrent x)
               putSkip (requiredPadding size__)
 
data MakeCurrentReply = MkMakeCurrentReply{context_tag_MakeCurrentReply
                                           :: CONTEXT_TAG}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize MakeCurrentReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_tag <- deserialize
               skip 20
               let _ = isCard32 length
               return (MkMakeCurrentReply context_tag)
 
data IsDirect = MkIsDirect{context_IsDirect ::
                           Graphics.XHB.Gen.Glx.Types.CONTEXT}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest IsDirect where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__ = 4 + size (context_IsDirect x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_IsDirect x)
               putSkip (requiredPadding size__)
 
data IsDirectReply = MkIsDirectReply{is_direct_IsDirectReply ::
                                     Bool}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize IsDirectReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               is_direct <- deserialize
               skip 23
               let _ = isCard32 length
               return (MkIsDirectReply is_direct)
 
data QueryVersion = MkQueryVersion{major_version_QueryVersion ::
                                   Word32,
                                   minor_version_QueryVersion :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__
                     = 4 + size (major_version_QueryVersion x) +
                         size (minor_version_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (major_version_QueryVersion x)
               serialize (minor_version_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_version_QueryVersionReply
                                             :: Word32,
                                             minor_version_QueryVersionReply :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               skip 16
               let _ = isCard32 length
               return (MkQueryVersionReply major_version minor_version)
 
data WaitGL = MkWaitGL{context_tag_WaitGL :: CONTEXT_TAG}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest WaitGL where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__ = 4 + size (context_tag_WaitGL x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_WaitGL x)
               putSkip (requiredPadding size__)
 
data WaitX = MkWaitX{context_tag_WaitX :: CONTEXT_TAG}
           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest WaitX where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 9
               let size__ = 4 + size (context_tag_WaitX x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_WaitX x)
               putSkip (requiredPadding size__)
 
data CopyContext = MkCopyContext{src_CopyContext ::
                                 Graphics.XHB.Gen.Glx.Types.CONTEXT,
                                 dest_CopyContext :: Graphics.XHB.Gen.Glx.Types.CONTEXT,
                                 mask_CopyContext :: Word32,
                                 src_context_tag_CopyContext :: CONTEXT_TAG}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CopyContext where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 10
               let size__
                     = 4 + size (src_CopyContext x) + size (dest_CopyContext x) +
                         size (mask_CopyContext x)
                         + size (src_context_tag_CopyContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (src_CopyContext x)
               serialize (dest_CopyContext x)
               serialize (mask_CopyContext x)
               serialize (src_context_tag_CopyContext x)
               putSkip (requiredPadding size__)
 
data GC = GCGL_CURRENT_BIT
        | GCGL_POINT_BIT
        | GCGL_LINE_BIT
        | GCGL_POLYGON_BIT
        | GCGL_POLYGON_STIPPLE_BIT
        | GCGL_PIXEL_MODE_BIT
        | GCGL_LIGHTING_BIT
        | GCGL_FOG_BIT
        | GCGL_DEPTH_BUFFER_BIT
        | GCGL_ACCUM_BUFFER_BIT
        | GCGL_STENCIL_BUFFER_BIT
        | GCGL_VIEWPORT_BIT
        | GCGL_TRANSFORM_BIT
        | GCGL_ENABLE_BIT
        | GCGL_COLOR_BUFFER_BIT
        | GCGL_HINT_BIT
        | GCGL_EVAL_BIT
        | GCGL_LIST_BIT
        | GCGL_TEXTURE_BIT
        | GCGL_SCISSOR_BIT
        deriving (Show, Eq, Ord, Enum, Typeable)
 
instance BitEnum GC where
        toBit GCGL_CURRENT_BIT{} = 0
        toBit GCGL_POINT_BIT{} = 1
        toBit GCGL_LINE_BIT{} = 2
        toBit GCGL_POLYGON_BIT{} = 3
        toBit GCGL_POLYGON_STIPPLE_BIT{} = 4
        toBit GCGL_PIXEL_MODE_BIT{} = 5
        toBit GCGL_LIGHTING_BIT{} = 6
        toBit GCGL_FOG_BIT{} = 7
        toBit GCGL_DEPTH_BUFFER_BIT{} = 8
        toBit GCGL_ACCUM_BUFFER_BIT{} = 9
        toBit GCGL_STENCIL_BUFFER_BIT{} = 10
        toBit GCGL_VIEWPORT_BIT{} = 11
        toBit GCGL_TRANSFORM_BIT{} = 12
        toBit GCGL_ENABLE_BIT{} = 13
        toBit GCGL_COLOR_BUFFER_BIT{} = 14
        toBit GCGL_HINT_BIT{} = 15
        toBit GCGL_EVAL_BIT{} = 16
        toBit GCGL_LIST_BIT{} = 17
        toBit GCGL_TEXTURE_BIT{} = 18
        toBit GCGL_SCISSOR_BIT{} = 19
        fromBit 0 = GCGL_CURRENT_BIT
        fromBit 1 = GCGL_POINT_BIT
        fromBit 2 = GCGL_LINE_BIT
        fromBit 3 = GCGL_POLYGON_BIT
        fromBit 4 = GCGL_POLYGON_STIPPLE_BIT
        fromBit 5 = GCGL_PIXEL_MODE_BIT
        fromBit 6 = GCGL_LIGHTING_BIT
        fromBit 7 = GCGL_FOG_BIT
        fromBit 8 = GCGL_DEPTH_BUFFER_BIT
        fromBit 9 = GCGL_ACCUM_BUFFER_BIT
        fromBit 10 = GCGL_STENCIL_BUFFER_BIT
        fromBit 11 = GCGL_VIEWPORT_BIT
        fromBit 12 = GCGL_TRANSFORM_BIT
        fromBit 13 = GCGL_ENABLE_BIT
        fromBit 14 = GCGL_COLOR_BUFFER_BIT
        fromBit 15 = GCGL_HINT_BIT
        fromBit 16 = GCGL_EVAL_BIT
        fromBit 17 = GCGL_LIST_BIT
        fromBit 18 = GCGL_TEXTURE_BIT
        fromBit 19 = GCGL_SCISSOR_BIT
 
data SwapBuffers = MkSwapBuffers{context_tag_SwapBuffers ::
                                 CONTEXT_TAG,
                                 drawable_SwapBuffers :: Graphics.XHB.Gen.Glx.Types.DRAWABLE}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SwapBuffers where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 11
               let size__
                     = 4 + size (context_tag_SwapBuffers x) +
                         size (drawable_SwapBuffers x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_SwapBuffers x)
               serialize (drawable_SwapBuffers x)
               putSkip (requiredPadding size__)
 
data UseXFont = MkUseXFont{context_tag_UseXFont :: CONTEXT_TAG,
                           font_UseXFont :: FONT, first_UseXFont :: Word32,
                           count_UseXFont :: Word32, list_base_UseXFont :: Word32}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest UseXFont where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 12
               let size__
                     = 4 + size (context_tag_UseXFont x) + size (font_UseXFont x) +
                         size (first_UseXFont x)
                         + size (count_UseXFont x)
                         + size (list_base_UseXFont x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_UseXFont x)
               serialize (font_UseXFont x)
               serialize (first_UseXFont x)
               serialize (count_UseXFont x)
               serialize (list_base_UseXFont x)
               putSkip (requiredPadding size__)
 
data CreateGLXPixmap = MkCreateGLXPixmap{screen_CreateGLXPixmap ::
                                         Word32,
                                         visual_CreateGLXPixmap :: VISUALID,
                                         pixmap_CreateGLXPixmap ::
                                         Graphics.XHB.Gen.Xproto.Types.PIXMAP,
                                         glx_pixmap_CreateGLXPixmap ::
                                         Graphics.XHB.Gen.Glx.Types.PIXMAP}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateGLXPixmap where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 13
               let size__
                     = 4 + size (screen_CreateGLXPixmap x) +
                         size (visual_CreateGLXPixmap x)
                         + size (pixmap_CreateGLXPixmap x)
                         + size (glx_pixmap_CreateGLXPixmap x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_CreateGLXPixmap x)
               serialize (visual_CreateGLXPixmap x)
               serialize (pixmap_CreateGLXPixmap x)
               serialize (glx_pixmap_CreateGLXPixmap x)
               putSkip (requiredPadding size__)
 
data GetVisualConfigs = MkGetVisualConfigs{screen_GetVisualConfigs
                                           :: Word32}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetVisualConfigs where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 14
               let size__ = 4 + size (screen_GetVisualConfigs x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_GetVisualConfigs x)
               putSkip (requiredPadding size__)
 
data GetVisualConfigsReply = MkGetVisualConfigsReply{num_visuals_GetVisualConfigsReply
                                                     :: Word32,
                                                     num_properties_GetVisualConfigsReply :: Word32,
                                                     property_list_GetVisualConfigsReply ::
                                                     [Word32]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetVisualConfigsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_visuals <- deserialize
               num_properties <- deserialize
               skip 16
               property_list <- deserializeList (fromIntegral length)
               let _ = isCard32 length
               return
                 (MkGetVisualConfigsReply num_visuals num_properties property_list)
 
data DestroyGLXPixmap = MkDestroyGLXPixmap{glx_pixmap_DestroyGLXPixmap
                                           :: Graphics.XHB.Gen.Glx.Types.PIXMAP}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyGLXPixmap where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 15
               let size__ = 4 + size (glx_pixmap_DestroyGLXPixmap x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (glx_pixmap_DestroyGLXPixmap x)
               putSkip (requiredPadding size__)
 
data VendorPrivate = MkVendorPrivate{vendor_code_VendorPrivate ::
                                     Word32,
                                     context_tag_VendorPrivate :: CONTEXT_TAG,
                                     data_VendorPrivate :: [Word8]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest VendorPrivate where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 16
               let size__
                     = 4 + size (vendor_code_VendorPrivate x) +
                         size (context_tag_VendorPrivate x)
                         + sum (map size (data_VendorPrivate x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (vendor_code_VendorPrivate x)
               serialize (context_tag_VendorPrivate x)
               serializeList (data_VendorPrivate x)
               putSkip (requiredPadding size__)
 
data VendorPrivateWithReply = MkVendorPrivateWithReply{vendor_code_VendorPrivateWithReply
                                                       :: Word32,
                                                       context_tag_VendorPrivateWithReply ::
                                                       CONTEXT_TAG,
                                                       data_VendorPrivateWithReply :: [Word8]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest VendorPrivateWithReply where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 17
               let size__
                     = 4 + size (vendor_code_VendorPrivateWithReply x) +
                         size (context_tag_VendorPrivateWithReply x)
                         + sum (map size (data_VendorPrivateWithReply x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (vendor_code_VendorPrivateWithReply x)
               serialize (context_tag_VendorPrivateWithReply x)
               serializeList (data_VendorPrivateWithReply x)
               putSkip (requiredPadding size__)
 
data VendorPrivateWithReplyReply = MkVendorPrivateWithReplyReply{retval_VendorPrivateWithReplyReply
                                                                 :: Word32,
                                                                 data1_VendorPrivateWithReplyReply
                                                                 :: [Word8],
                                                                 data2_VendorPrivateWithReplyReply
                                                                 :: [Word8]}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize VendorPrivateWithReplyReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               retval <- deserialize
               data1 <- deserializeList (fromIntegral 24)
               data2 <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkVendorPrivateWithReplyReply retval data1 data2)
 
data QueryExtensionsString = MkQueryExtensionsString{screen_QueryExtensionsString
                                                     :: Word32}
                           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryExtensionsString where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 18
               let size__ = 4 + size (screen_QueryExtensionsString x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_QueryExtensionsString x)
               putSkip (requiredPadding size__)
 
data QueryExtensionsStringReply = MkQueryExtensionsStringReply{n_QueryExtensionsStringReply
                                                               :: Word32}
                                deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryExtensionsStringReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               skip 16
               let _ = isCard32 length
               return (MkQueryExtensionsStringReply n)
 
data QueryServerString = MkQueryServerString{screen_QueryServerString
                                             :: Word32,
                                             name_QueryServerString :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryServerString where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 19
               let size__
                     = 4 + size (screen_QueryServerString x) +
                         size (name_QueryServerString x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_QueryServerString x)
               serialize (name_QueryServerString x)
               putSkip (requiredPadding size__)
 
data QueryServerStringReply = MkQueryServerStringReply{str_len_QueryServerStringReply
                                                       :: Word32,
                                                       string_QueryServerStringReply :: [CChar]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryServerStringReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               str_len <- deserialize
               skip 16
               string <- deserializeList (fromIntegral str_len)
               let _ = isCard32 length
               return (MkQueryServerStringReply str_len string)
 
data ClientInfo = MkClientInfo{major_version_ClientInfo :: Word32,
                               minor_version_ClientInfo :: Word32, str_len_ClientInfo :: Word32,
                               string_ClientInfo :: [CChar]}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ClientInfo where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 20
               let size__
                     = 4 + size (major_version_ClientInfo x) +
                         size (minor_version_ClientInfo x)
                         + size (str_len_ClientInfo x)
                         + sum (map size (string_ClientInfo x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (major_version_ClientInfo x)
               serialize (minor_version_ClientInfo x)
               serialize (str_len_ClientInfo x)
               serializeList (string_ClientInfo x)
               putSkip (requiredPadding size__)
 
data GetFBConfigs = MkGetFBConfigs{screen_GetFBConfigs :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetFBConfigs where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 21
               let size__ = 4 + size (screen_GetFBConfigs x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_GetFBConfigs x)
               putSkip (requiredPadding size__)
 
data GetFBConfigsReply = MkGetFBConfigsReply{num_FB_configs_GetFBConfigsReply
                                             :: Word32,
                                             num_properties_GetFBConfigsReply :: Word32,
                                             property_list_GetFBConfigsReply :: [Word32]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetFBConfigsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_FB_configs <- deserialize
               num_properties <- deserialize
               skip 16
               property_list <- deserializeList (fromIntegral length)
               let _ = isCard32 length
               return
                 (MkGetFBConfigsReply num_FB_configs num_properties property_list)
 
data CreatePixmap = MkCreatePixmap{screen_CreatePixmap :: Word32,
                                   fbconfig_CreatePixmap :: Word32,
                                   pixmap_CreatePixmap :: Graphics.XHB.Gen.Xproto.Types.PIXMAP,
                                   glx_pixmap_CreatePixmap :: Graphics.XHB.Gen.Glx.Types.PIXMAP,
                                   num_attribs_CreatePixmap :: Word32,
                                   attribs_CreatePixmap :: [Word32]}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreatePixmap where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 22
               let size__
                     = 4 + size (screen_CreatePixmap x) + size (fbconfig_CreatePixmap x)
                         + size (pixmap_CreatePixmap x)
                         + size (glx_pixmap_CreatePixmap x)
                         + size (num_attribs_CreatePixmap x)
                         + sum (map size (attribs_CreatePixmap x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_CreatePixmap x)
               serialize (fbconfig_CreatePixmap x)
               serialize (pixmap_CreatePixmap x)
               serialize (glx_pixmap_CreatePixmap x)
               serialize (num_attribs_CreatePixmap x)
               serializeList (attribs_CreatePixmap x)
               putSkip (requiredPadding size__)
 
data DestroyPixmap = MkDestroyPixmap{glx_pixmap_DestroyPixmap ::
                                     Graphics.XHB.Gen.Glx.Types.PIXMAP}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyPixmap where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 23
               let size__ = 4 + size (glx_pixmap_DestroyPixmap x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (glx_pixmap_DestroyPixmap x)
               putSkip (requiredPadding size__)
 
data CreateNewContext = MkCreateNewContext{context_CreateNewContext
                                           :: Graphics.XHB.Gen.Glx.Types.CONTEXT,
                                           fbconfig_CreateNewContext :: Word32,
                                           screen_CreateNewContext :: Word32,
                                           render_type_CreateNewContext :: Word32,
                                           share_list_CreateNewContext :: Word32,
                                           is_direct_CreateNewContext :: Bool,
                                           reserved1_CreateNewContext :: Word8,
                                           reserved2_CreateNewContext :: Word16}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateNewContext where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 24
               let size__
                     = 4 + size (context_CreateNewContext x) +
                         size (fbconfig_CreateNewContext x)
                         + size (screen_CreateNewContext x)
                         + size (render_type_CreateNewContext x)
                         + size (share_list_CreateNewContext x)
                         + size (is_direct_CreateNewContext x)
                         + size (reserved1_CreateNewContext x)
                         + size (reserved2_CreateNewContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_CreateNewContext x)
               serialize (fbconfig_CreateNewContext x)
               serialize (screen_CreateNewContext x)
               serialize (render_type_CreateNewContext x)
               serialize (share_list_CreateNewContext x)
               serialize (is_direct_CreateNewContext x)
               serialize (reserved1_CreateNewContext x)
               serialize (reserved2_CreateNewContext x)
               putSkip (requiredPadding size__)
 
data QueryContext = MkQueryContext{context_QueryContext ::
                                   Graphics.XHB.Gen.Glx.Types.CONTEXT}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryContext where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 25
               let size__ = 4 + size (context_QueryContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_QueryContext x)
               putSkip (requiredPadding size__)
 
data QueryContextReply = MkQueryContextReply{num_attribs_QueryContextReply
                                             :: Word32,
                                             attribs_QueryContextReply :: [Word32]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_attribs <- deserialize
               skip 20
               attribs <- deserializeList
                            (fromIntegral (fromIntegral (num_attribs * 2)))
               let _ = isCard32 length
               return (MkQueryContextReply num_attribs attribs)
 
data MakeContextCurrent = MkMakeContextCurrent{old_context_tag_MakeContextCurrent
                                               :: CONTEXT_TAG,
                                               drawable_MakeContextCurrent ::
                                               Graphics.XHB.Gen.Glx.Types.DRAWABLE,
                                               read_drawable_MakeContextCurrent ::
                                               Graphics.XHB.Gen.Glx.Types.DRAWABLE,
                                               context_MakeContextCurrent ::
                                               Graphics.XHB.Gen.Glx.Types.CONTEXT}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest MakeContextCurrent where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 26
               let size__
                     = 4 + size (old_context_tag_MakeContextCurrent x) +
                         size (drawable_MakeContextCurrent x)
                         + size (read_drawable_MakeContextCurrent x)
                         + size (context_MakeContextCurrent x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (old_context_tag_MakeContextCurrent x)
               serialize (drawable_MakeContextCurrent x)
               serialize (read_drawable_MakeContextCurrent x)
               serialize (context_MakeContextCurrent x)
               putSkip (requiredPadding size__)
 
data MakeContextCurrentReply = MkMakeContextCurrentReply{context_tag_MakeContextCurrentReply
                                                         :: CONTEXT_TAG}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize MakeContextCurrentReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_tag <- deserialize
               skip 20
               let _ = isCard32 length
               return (MkMakeContextCurrentReply context_tag)
 
data CreatePbuffer = MkCreatePbuffer{screen_CreatePbuffer ::
                                     Word32,
                                     fbconfig_CreatePbuffer :: FBCONFIG,
                                     pbuffer_CreatePbuffer :: PBUFFER,
                                     num_attribs_CreatePbuffer :: Word32,
                                     attribs_CreatePbuffer :: [Word32]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreatePbuffer where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 27
               let size__
                     = 4 + size (screen_CreatePbuffer x) +
                         size (fbconfig_CreatePbuffer x)
                         + size (pbuffer_CreatePbuffer x)
                         + size (num_attribs_CreatePbuffer x)
                         + sum (map size (attribs_CreatePbuffer x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_CreatePbuffer x)
               serialize (fbconfig_CreatePbuffer x)
               serialize (pbuffer_CreatePbuffer x)
               serialize (num_attribs_CreatePbuffer x)
               serializeList (attribs_CreatePbuffer x)
               putSkip (requiredPadding size__)
 
data DestroyPbuffer = MkDestroyPbuffer{pbuffer_DestroyPbuffer ::
                                       PBUFFER}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyPbuffer where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 28
               let size__ = 4 + size (pbuffer_DestroyPbuffer x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (pbuffer_DestroyPbuffer x)
               putSkip (requiredPadding size__)
 
data GetDrawableAttributes = MkGetDrawableAttributes{drawable_GetDrawableAttributes
                                                     :: Graphics.XHB.Gen.Glx.Types.DRAWABLE}
                           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDrawableAttributes where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 29
               let size__ = 4 + size (drawable_GetDrawableAttributes x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_GetDrawableAttributes x)
               putSkip (requiredPadding size__)
 
data GetDrawableAttributesReply = MkGetDrawableAttributesReply{num_attribs_GetDrawableAttributesReply
                                                               :: Word32,
                                                               attribs_GetDrawableAttributesReply ::
                                                               [Word32]}
                                deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDrawableAttributesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_attribs <- deserialize
               skip 20
               attribs <- deserializeList
                            (fromIntegral (fromIntegral (num_attribs * 2)))
               let _ = isCard32 length
               return (MkGetDrawableAttributesReply num_attribs attribs)
 
data ChangeDrawableAttributes = MkChangeDrawableAttributes{drawable_ChangeDrawableAttributes
                                                           :: Graphics.XHB.Gen.Glx.Types.DRAWABLE,
                                                           num_attribs_ChangeDrawableAttributes ::
                                                           Word32,
                                                           attribs_ChangeDrawableAttributes ::
                                                           [Word32]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeDrawableAttributes where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 30
               let size__
                     = 4 + size (drawable_ChangeDrawableAttributes x) +
                         size (num_attribs_ChangeDrawableAttributes x)
                         + sum (map size (attribs_ChangeDrawableAttributes x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_ChangeDrawableAttributes x)
               serialize (num_attribs_ChangeDrawableAttributes x)
               serializeList (attribs_ChangeDrawableAttributes x)
               putSkip (requiredPadding size__)
 
data CreateWindow = MkCreateWindow{screen_CreateWindow :: Word32,
                                   fbconfig_CreateWindow :: FBCONFIG,
                                   window_CreateWindow :: Graphics.XHB.Gen.Xproto.Types.WINDOW,
                                   glx_window_CreateWindow :: Graphics.XHB.Gen.Glx.Types.WINDOW,
                                   num_attribs_CreateWindow :: Word32,
                                   attribs_CreateWindow :: [Word32]}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateWindow where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 31
               let size__
                     = 4 + size (screen_CreateWindow x) + size (fbconfig_CreateWindow x)
                         + size (window_CreateWindow x)
                         + size (glx_window_CreateWindow x)
                         + size (num_attribs_CreateWindow x)
                         + sum (map size (attribs_CreateWindow x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_CreateWindow x)
               serialize (fbconfig_CreateWindow x)
               serialize (window_CreateWindow x)
               serialize (glx_window_CreateWindow x)
               serialize (num_attribs_CreateWindow x)
               serializeList (attribs_CreateWindow x)
               putSkip (requiredPadding size__)
 
data DeleteWindow = MkDeleteWindow{glxwindow_DeleteWindow ::
                                   Graphics.XHB.Gen.Glx.Types.WINDOW}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DeleteWindow where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 32
               let size__ = 4 + size (glxwindow_DeleteWindow x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (glxwindow_DeleteWindow x)
               putSkip (requiredPadding size__)
 
data NewList = MkNewList{context_tag_NewList :: CONTEXT_TAG,
                         list_NewList :: Word32, mode_NewList :: Word32}
             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest NewList where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 101
               let size__
                     = 4 + size (context_tag_NewList x) + size (list_NewList x) +
                         size (mode_NewList x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_NewList x)
               serialize (list_NewList x)
               serialize (mode_NewList x)
               putSkip (requiredPadding size__)
 
data EndList = MkEndList{context_tag_EndList :: CONTEXT_TAG}
             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest EndList where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 102
               let size__ = 4 + size (context_tag_EndList x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_EndList x)
               putSkip (requiredPadding size__)
 
data DeleteLists = MkDeleteLists{context_tag_DeleteLists ::
                                 CONTEXT_TAG,
                                 list_DeleteLists :: Word32, range_DeleteLists :: Int32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DeleteLists where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 103
               let size__
                     = 4 + size (context_tag_DeleteLists x) + size (list_DeleteLists x)
                         + size (range_DeleteLists x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_DeleteLists x)
               serialize (list_DeleteLists x)
               serialize (range_DeleteLists x)
               putSkip (requiredPadding size__)
 
data GenLists = MkGenLists{context_tag_GenLists :: CONTEXT_TAG,
                           range_GenLists :: Int32}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GenLists where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 104
               let size__
                     = 4 + size (context_tag_GenLists x) + size (range_GenLists x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GenLists x)
               serialize (range_GenLists x)
               putSkip (requiredPadding size__)
 
data GenListsReply = MkGenListsReply{ret_val_GenListsReply ::
                                     Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GenListsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               ret_val <- deserialize
               let _ = isCard32 length
               return (MkGenListsReply ret_val)
 
data FeedbackBuffer = MkFeedbackBuffer{context_tag_FeedbackBuffer
                                       :: CONTEXT_TAG,
                                       size_FeedbackBuffer :: Int32, type_FeedbackBuffer :: Int32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest FeedbackBuffer where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 105
               let size__
                     = 4 + size (context_tag_FeedbackBuffer x) +
                         size (size_FeedbackBuffer x)
                         + size (type_FeedbackBuffer x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_FeedbackBuffer x)
               serialize (size_FeedbackBuffer x)
               serialize (type_FeedbackBuffer x)
               putSkip (requiredPadding size__)
 
data SelectBuffer = MkSelectBuffer{context_tag_SelectBuffer ::
                                   CONTEXT_TAG,
                                   size_SelectBuffer :: Int32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SelectBuffer where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 106
               let size__
                     = 4 + size (context_tag_SelectBuffer x) +
                         size (size_SelectBuffer x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_SelectBuffer x)
               serialize (size_SelectBuffer x)
               putSkip (requiredPadding size__)
 
data RenderMode = MkRenderMode{context_tag_RenderMode ::
                               CONTEXT_TAG,
                               mode_RenderMode :: Word32}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest RenderMode where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 107
               let size__
                     = 4 + size (context_tag_RenderMode x) + size (mode_RenderMode x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_RenderMode x)
               serialize (mode_RenderMode x)
               putSkip (requiredPadding size__)
 
data RenderModeReply = MkRenderModeReply{ret_val_RenderModeReply ::
                                         Word32,
                                         n_RenderModeReply :: Word32,
                                         new_mode_RenderModeReply :: Word32,
                                         data_RenderModeReply :: [Word32]}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize RenderModeReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               ret_val <- deserialize
               n <- deserialize
               new_mode <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkRenderModeReply ret_val n new_mode data_)
 
data RM = RMGL_RENDER
        | RMGL_FEEDBACK
        | RMGL_SELECT
        deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum RM where
        toValue RMGL_RENDER{} = 7168
        toValue RMGL_FEEDBACK{} = 7169
        toValue RMGL_SELECT{} = 7170
        fromValue 7168 = RMGL_RENDER
        fromValue 7169 = RMGL_FEEDBACK
        fromValue 7170 = RMGL_SELECT
 
data Finish = MkFinish{context_tag_Finish :: CONTEXT_TAG}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Finish where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 108
               let size__ = 4 + size (context_tag_Finish x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_Finish x)
               putSkip (requiredPadding size__)
 
data FinishReply = MkFinishReply{}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize FinishReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               let _ = isCard32 length
               return (MkFinishReply)
 
data PixelStoref = MkPixelStoref{context_tag_PixelStoref ::
                                 CONTEXT_TAG,
                                 pname_PixelStoref :: Word32, datum_PixelStoref :: FLOAT32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PixelStoref where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 109
               let size__
                     = 4 + size (context_tag_PixelStoref x) + size (pname_PixelStoref x)
                         + size (datum_PixelStoref x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_PixelStoref x)
               serialize (pname_PixelStoref x)
               serialize (datum_PixelStoref x)
               putSkip (requiredPadding size__)
 
data PixelStorei = MkPixelStorei{context_tag_PixelStorei ::
                                 CONTEXT_TAG,
                                 pname_PixelStorei :: Word32, datum_PixelStorei :: Int32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PixelStorei where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 110
               let size__
                     = 4 + size (context_tag_PixelStorei x) + size (pname_PixelStorei x)
                         + size (datum_PixelStorei x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_PixelStorei x)
               serialize (pname_PixelStorei x)
               serialize (datum_PixelStorei x)
               putSkip (requiredPadding size__)
 
data ReadPixels = MkReadPixels{context_tag_ReadPixels ::
                               CONTEXT_TAG,
                               x_ReadPixels :: Int32, y_ReadPixels :: Int32,
                               width_ReadPixels :: Int32, height_ReadPixels :: Int32,
                               format_ReadPixels :: Word32, type_ReadPixels :: Word32,
                               swap_bytes_ReadPixels :: Bool, lsb_first_ReadPixels :: Bool}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ReadPixels where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 111
               let size__
                     = 4 + size (context_tag_ReadPixels x) + size (x_ReadPixels x) +
                         size (y_ReadPixels x)
                         + size (width_ReadPixels x)
                         + size (height_ReadPixels x)
                         + size (format_ReadPixels x)
                         + size (type_ReadPixels x)
                         + size (swap_bytes_ReadPixels x)
                         + size (lsb_first_ReadPixels x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_ReadPixels x)
               serialize (x_ReadPixels x)
               serialize (y_ReadPixels x)
               serialize (width_ReadPixels x)
               serialize (height_ReadPixels x)
               serialize (format_ReadPixels x)
               serialize (type_ReadPixels x)
               serialize (swap_bytes_ReadPixels x)
               serialize (lsb_first_ReadPixels x)
               putSkip (requiredPadding size__)
 
data ReadPixelsReply = MkReadPixelsReply{data_ReadPixelsReply ::
                                         [Word8]}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ReadPixelsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkReadPixelsReply data_)
 
data GetBooleanv = MkGetBooleanv{context_tag_GetBooleanv ::
                                 CONTEXT_TAG,
                                 pname_GetBooleanv :: Int32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetBooleanv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 112
               let size__
                     = 4 + size (context_tag_GetBooleanv x) + size (pname_GetBooleanv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetBooleanv x)
               serialize (pname_GetBooleanv x)
               putSkip (requiredPadding size__)
 
data GetBooleanvReply = MkGetBooleanvReply{n_GetBooleanvReply ::
                                           Word32,
                                           datum_GetBooleanvReply :: Bool,
                                           data_GetBooleanvReply :: [Bool]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetBooleanvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 15
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetBooleanvReply n datum data_)
 
data GetClipPlane = MkGetClipPlane{context_tag_GetClipPlane ::
                                   CONTEXT_TAG,
                                   plane_GetClipPlane :: Int32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetClipPlane where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 113
               let size__
                     = 4 + size (context_tag_GetClipPlane x) +
                         size (plane_GetClipPlane x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetClipPlane x)
               serialize (plane_GetClipPlane x)
               putSkip (requiredPadding size__)
 
data GetClipPlaneReply = MkGetClipPlaneReply{data_GetClipPlaneReply
                                             :: [FLOAT64]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetClipPlaneReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               data_ <- deserializeList
                          (fromIntegral (fromIntegral (length `div` 2)))
               let _ = isCard32 length
               return (MkGetClipPlaneReply data_)
 
data GetDoublev = MkGetDoublev{context_tag_GetDoublev ::
                               CONTEXT_TAG,
                               pname_GetDoublev :: Word32}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDoublev where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 114
               let size__
                     = 4 + size (context_tag_GetDoublev x) + size (pname_GetDoublev x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetDoublev x)
               serialize (pname_GetDoublev x)
               putSkip (requiredPadding size__)
 
data GetDoublevReply = MkGetDoublevReply{n_GetDoublevReply ::
                                         Word32,
                                         datum_GetDoublevReply :: FLOAT64,
                                         data_GetDoublevReply :: [FLOAT64]}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDoublevReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 8
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetDoublevReply n datum data_)
 
data GetError = MkGetError{context_tag_GetError :: CONTEXT_TAG}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetError where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 115
               let size__ = 4 + size (context_tag_GetError x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetError x)
               putSkip (requiredPadding size__)
 
data GetErrorReply = MkGetErrorReply{error_GetErrorReply :: Int32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetErrorReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               error <- deserialize
               let _ = isCard32 length
               return (MkGetErrorReply error)
 
data GetFloatv = MkGetFloatv{context_tag_GetFloatv :: CONTEXT_TAG,
                             pname_GetFloatv :: Word32}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetFloatv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 116
               let size__
                     = 4 + size (context_tag_GetFloatv x) + size (pname_GetFloatv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetFloatv x)
               serialize (pname_GetFloatv x)
               putSkip (requiredPadding size__)
 
data GetFloatvReply = MkGetFloatvReply{n_GetFloatvReply :: Word32,
                                       datum_GetFloatvReply :: FLOAT32,
                                       data_GetFloatvReply :: [FLOAT32]}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetFloatvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetFloatvReply n datum data_)
 
data GetIntegerv = MkGetIntegerv{context_tag_GetIntegerv ::
                                 CONTEXT_TAG,
                                 pname_GetIntegerv :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetIntegerv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 117
               let size__
                     = 4 + size (context_tag_GetIntegerv x) + size (pname_GetIntegerv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetIntegerv x)
               serialize (pname_GetIntegerv x)
               putSkip (requiredPadding size__)
 
data GetIntegervReply = MkGetIntegervReply{n_GetIntegervReply ::
                                           Word32,
                                           datum_GetIntegervReply :: Int32,
                                           data_GetIntegervReply :: [Int32]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetIntegervReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetIntegervReply n datum data_)
 
data GetLightfv = MkGetLightfv{context_tag_GetLightfv ::
                               CONTEXT_TAG,
                               light_GetLightfv :: Word32, pname_GetLightfv :: Word32}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetLightfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 118
               let size__
                     = 4 + size (context_tag_GetLightfv x) + size (light_GetLightfv x) +
                         size (pname_GetLightfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetLightfv x)
               serialize (light_GetLightfv x)
               serialize (pname_GetLightfv x)
               putSkip (requiredPadding size__)
 
data GetLightfvReply = MkGetLightfvReply{n_GetLightfvReply ::
                                         Word32,
                                         datum_GetLightfvReply :: FLOAT32,
                                         data_GetLightfvReply :: [FLOAT32]}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetLightfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetLightfvReply n datum data_)
 
data GetLightiv = MkGetLightiv{context_tag_GetLightiv ::
                               CONTEXT_TAG,
                               light_GetLightiv :: Word32, pname_GetLightiv :: Word32}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetLightiv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 119
               let size__
                     = 4 + size (context_tag_GetLightiv x) + size (light_GetLightiv x) +
                         size (pname_GetLightiv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetLightiv x)
               serialize (light_GetLightiv x)
               serialize (pname_GetLightiv x)
               putSkip (requiredPadding size__)
 
data GetLightivReply = MkGetLightivReply{n_GetLightivReply ::
                                         Word32,
                                         datum_GetLightivReply :: Int32,
                                         data_GetLightivReply :: [Int32]}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetLightivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetLightivReply n datum data_)
 
data GetMapdv = MkGetMapdv{context_tag_GetMapdv :: CONTEXT_TAG,
                           target_GetMapdv :: Word32, query_GetMapdv :: Word32}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetMapdv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 120
               let size__
                     = 4 + size (context_tag_GetMapdv x) + size (target_GetMapdv x) +
                         size (query_GetMapdv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetMapdv x)
               serialize (target_GetMapdv x)
               serialize (query_GetMapdv x)
               putSkip (requiredPadding size__)
 
data GetMapdvReply = MkGetMapdvReply{n_GetMapdvReply :: Word32,
                                     datum_GetMapdvReply :: FLOAT64,
                                     data_GetMapdvReply :: [FLOAT64]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetMapdvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 8
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetMapdvReply n datum data_)
 
data GetMapfv = MkGetMapfv{context_tag_GetMapfv :: CONTEXT_TAG,
                           target_GetMapfv :: Word32, query_GetMapfv :: Word32}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetMapfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 121
               let size__
                     = 4 + size (context_tag_GetMapfv x) + size (target_GetMapfv x) +
                         size (query_GetMapfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetMapfv x)
               serialize (target_GetMapfv x)
               serialize (query_GetMapfv x)
               putSkip (requiredPadding size__)
 
data GetMapfvReply = MkGetMapfvReply{n_GetMapfvReply :: Word32,
                                     datum_GetMapfvReply :: FLOAT32,
                                     data_GetMapfvReply :: [FLOAT32]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetMapfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetMapfvReply n datum data_)
 
data GetMapiv = MkGetMapiv{context_tag_GetMapiv :: CONTEXT_TAG,
                           target_GetMapiv :: Word32, query_GetMapiv :: Word32}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetMapiv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 122
               let size__
                     = 4 + size (context_tag_GetMapiv x) + size (target_GetMapiv x) +
                         size (query_GetMapiv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetMapiv x)
               serialize (target_GetMapiv x)
               serialize (query_GetMapiv x)
               putSkip (requiredPadding size__)
 
data GetMapivReply = MkGetMapivReply{n_GetMapivReply :: Word32,
                                     datum_GetMapivReply :: Int32, data_GetMapivReply :: [Int32]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetMapivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetMapivReply n datum data_)
 
data GetMaterialfv = MkGetMaterialfv{context_tag_GetMaterialfv ::
                                     CONTEXT_TAG,
                                     face_GetMaterialfv :: Word32, pname_GetMaterialfv :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetMaterialfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 123
               let size__
                     = 4 + size (context_tag_GetMaterialfv x) +
                         size (face_GetMaterialfv x)
                         + size (pname_GetMaterialfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetMaterialfv x)
               serialize (face_GetMaterialfv x)
               serialize (pname_GetMaterialfv x)
               putSkip (requiredPadding size__)
 
data GetMaterialfvReply = MkGetMaterialfvReply{n_GetMaterialfvReply
                                               :: Word32,
                                               datum_GetMaterialfvReply :: FLOAT32,
                                               data_GetMaterialfvReply :: [FLOAT32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetMaterialfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetMaterialfvReply n datum data_)
 
data GetMaterialiv = MkGetMaterialiv{context_tag_GetMaterialiv ::
                                     CONTEXT_TAG,
                                     face_GetMaterialiv :: Word32, pname_GetMaterialiv :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetMaterialiv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 124
               let size__
                     = 4 + size (context_tag_GetMaterialiv x) +
                         size (face_GetMaterialiv x)
                         + size (pname_GetMaterialiv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetMaterialiv x)
               serialize (face_GetMaterialiv x)
               serialize (pname_GetMaterialiv x)
               putSkip (requiredPadding size__)
 
data GetMaterialivReply = MkGetMaterialivReply{n_GetMaterialivReply
                                               :: Word32,
                                               datum_GetMaterialivReply :: Int32,
                                               data_GetMaterialivReply :: [Int32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetMaterialivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetMaterialivReply n datum data_)
 
data GetPixelMapfv = MkGetPixelMapfv{context_tag_GetPixelMapfv ::
                                     CONTEXT_TAG,
                                     map_GetPixelMapfv :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPixelMapfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 125
               let size__
                     = 4 + size (context_tag_GetPixelMapfv x) +
                         size (map_GetPixelMapfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetPixelMapfv x)
               serialize (map_GetPixelMapfv x)
               putSkip (requiredPadding size__)
 
data GetPixelMapfvReply = MkGetPixelMapfvReply{n_GetPixelMapfvReply
                                               :: Word32,
                                               datum_GetPixelMapfvReply :: FLOAT32,
                                               data_GetPixelMapfvReply :: [FLOAT32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPixelMapfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetPixelMapfvReply n datum data_)
 
data GetPixelMapuiv = MkGetPixelMapuiv{context_tag_GetPixelMapuiv
                                       :: CONTEXT_TAG,
                                       map_GetPixelMapuiv :: Word32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPixelMapuiv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 126
               let size__
                     = 4 + size (context_tag_GetPixelMapuiv x) +
                         size (map_GetPixelMapuiv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetPixelMapuiv x)
               serialize (map_GetPixelMapuiv x)
               putSkip (requiredPadding size__)
 
data GetPixelMapuivReply = MkGetPixelMapuivReply{n_GetPixelMapuivReply
                                                 :: Word32,
                                                 datum_GetPixelMapuivReply :: Word32,
                                                 data_GetPixelMapuivReply :: [Word32]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPixelMapuivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetPixelMapuivReply n datum data_)
 
data GetPixelMapusv = MkGetPixelMapusv{context_tag_GetPixelMapusv
                                       :: CONTEXT_TAG,
                                       map_GetPixelMapusv :: Word32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPixelMapusv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 127
               let size__
                     = 4 + size (context_tag_GetPixelMapusv x) +
                         size (map_GetPixelMapusv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetPixelMapusv x)
               serialize (map_GetPixelMapusv x)
               putSkip (requiredPadding size__)
 
data GetPixelMapusvReply = MkGetPixelMapusvReply{n_GetPixelMapusvReply
                                                 :: Word32,
                                                 datum_GetPixelMapusvReply :: Word16,
                                                 data_GetPixelMapusvReply :: [Word16]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPixelMapusvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 16
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetPixelMapusvReply n datum data_)
 
data GetPolygonStipple = MkGetPolygonStipple{context_tag_GetPolygonStipple
                                             :: CONTEXT_TAG,
                                             lsb_first_GetPolygonStipple :: Bool}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPolygonStipple where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 128
               let size__
                     = 4 + size (context_tag_GetPolygonStipple x) +
                         size (lsb_first_GetPolygonStipple x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetPolygonStipple x)
               serialize (lsb_first_GetPolygonStipple x)
               putSkip (requiredPadding size__)
 
data GetPolygonStippleReply = MkGetPolygonStippleReply{data_GetPolygonStippleReply
                                                       :: [Word8]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPolygonStippleReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkGetPolygonStippleReply data_)
 
data GetString = MkGetString{context_tag_GetString :: CONTEXT_TAG,
                             name_GetString :: Word32}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetString where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 129
               let size__
                     = 4 + size (context_tag_GetString x) + size (name_GetString x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetString x)
               serialize (name_GetString x)
               putSkip (requiredPadding size__)
 
data GetStringReply = MkGetStringReply{n_GetStringReply :: Word32,
                                       string_GetStringReply :: [CChar]}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetStringReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               skip 16
               string <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetStringReply n string)
 
data GetTexEnvfv = MkGetTexEnvfv{context_tag_GetTexEnvfv ::
                                 CONTEXT_TAG,
                                 target_GetTexEnvfv :: Word32, pname_GetTexEnvfv :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexEnvfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 130
               let size__
                     = 4 + size (context_tag_GetTexEnvfv x) +
                         size (target_GetTexEnvfv x)
                         + size (pname_GetTexEnvfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexEnvfv x)
               serialize (target_GetTexEnvfv x)
               serialize (pname_GetTexEnvfv x)
               putSkip (requiredPadding size__)
 
data GetTexEnvfvReply = MkGetTexEnvfvReply{n_GetTexEnvfvReply ::
                                           Word32,
                                           datum_GetTexEnvfvReply :: FLOAT32,
                                           data_GetTexEnvfvReply :: [FLOAT32]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexEnvfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexEnvfvReply n datum data_)
 
data GetTexEnviv = MkGetTexEnviv{context_tag_GetTexEnviv ::
                                 CONTEXT_TAG,
                                 target_GetTexEnviv :: Word32, pname_GetTexEnviv :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexEnviv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 131
               let size__
                     = 4 + size (context_tag_GetTexEnviv x) +
                         size (target_GetTexEnviv x)
                         + size (pname_GetTexEnviv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexEnviv x)
               serialize (target_GetTexEnviv x)
               serialize (pname_GetTexEnviv x)
               putSkip (requiredPadding size__)
 
data GetTexEnvivReply = MkGetTexEnvivReply{n_GetTexEnvivReply ::
                                           Word32,
                                           datum_GetTexEnvivReply :: Int32,
                                           data_GetTexEnvivReply :: [Int32]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexEnvivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexEnvivReply n datum data_)
 
data GetTexGendv = MkGetTexGendv{context_tag_GetTexGendv ::
                                 CONTEXT_TAG,
                                 coord_GetTexGendv :: Word32, pname_GetTexGendv :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexGendv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 132
               let size__
                     = 4 + size (context_tag_GetTexGendv x) + size (coord_GetTexGendv x)
                         + size (pname_GetTexGendv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexGendv x)
               serialize (coord_GetTexGendv x)
               serialize (pname_GetTexGendv x)
               putSkip (requiredPadding size__)
 
data GetTexGendvReply = MkGetTexGendvReply{n_GetTexGendvReply ::
                                           Word32,
                                           datum_GetTexGendvReply :: FLOAT64,
                                           data_GetTexGendvReply :: [FLOAT64]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexGendvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 8
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexGendvReply n datum data_)
 
data GetTexGenfv = MkGetTexGenfv{context_tag_GetTexGenfv ::
                                 CONTEXT_TAG,
                                 coord_GetTexGenfv :: Word32, pname_GetTexGenfv :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexGenfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 133
               let size__
                     = 4 + size (context_tag_GetTexGenfv x) + size (coord_GetTexGenfv x)
                         + size (pname_GetTexGenfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexGenfv x)
               serialize (coord_GetTexGenfv x)
               serialize (pname_GetTexGenfv x)
               putSkip (requiredPadding size__)
 
data GetTexGenfvReply = MkGetTexGenfvReply{n_GetTexGenfvReply ::
                                           Word32,
                                           datum_GetTexGenfvReply :: FLOAT32,
                                           data_GetTexGenfvReply :: [FLOAT32]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexGenfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexGenfvReply n datum data_)
 
data GetTexGeniv = MkGetTexGeniv{context_tag_GetTexGeniv ::
                                 CONTEXT_TAG,
                                 coord_GetTexGeniv :: Word32, pname_GetTexGeniv :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexGeniv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 134
               let size__
                     = 4 + size (context_tag_GetTexGeniv x) + size (coord_GetTexGeniv x)
                         + size (pname_GetTexGeniv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexGeniv x)
               serialize (coord_GetTexGeniv x)
               serialize (pname_GetTexGeniv x)
               putSkip (requiredPadding size__)
 
data GetTexGenivReply = MkGetTexGenivReply{n_GetTexGenivReply ::
                                           Word32,
                                           datum_GetTexGenivReply :: Int32,
                                           data_GetTexGenivReply :: [Int32]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexGenivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexGenivReply n datum data_)
 
data GetTexImage = MkGetTexImage{context_tag_GetTexImage ::
                                 CONTEXT_TAG,
                                 target_GetTexImage :: Word32, level_GetTexImage :: Int32,
                                 format_GetTexImage :: Word32, type_GetTexImage :: Word32,
                                 swap_bytes_GetTexImage :: Bool}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexImage where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 135
               let size__
                     = 4 + size (context_tag_GetTexImage x) +
                         size (target_GetTexImage x)
                         + size (level_GetTexImage x)
                         + size (format_GetTexImage x)
                         + size (type_GetTexImage x)
                         + size (swap_bytes_GetTexImage x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexImage x)
               serialize (target_GetTexImage x)
               serialize (level_GetTexImage x)
               serialize (format_GetTexImage x)
               serialize (type_GetTexImage x)
               serialize (swap_bytes_GetTexImage x)
               putSkip (requiredPadding size__)
 
data GetTexImageReply = MkGetTexImageReply{width_GetTexImageReply
                                           :: Int32,
                                           height_GetTexImageReply :: Int32,
                                           depth_GetTexImageReply :: Int32,
                                           data_GetTexImageReply :: [Word8]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexImageReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 8
               width <- deserialize
               height <- deserialize
               depth <- deserialize
               skip 4
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkGetTexImageReply width height depth data_)
 
data GetTexParameterfv = MkGetTexParameterfv{context_tag_GetTexParameterfv
                                             :: CONTEXT_TAG,
                                             target_GetTexParameterfv :: Word32,
                                             pname_GetTexParameterfv :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexParameterfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 136
               let size__
                     = 4 + size (context_tag_GetTexParameterfv x) +
                         size (target_GetTexParameterfv x)
                         + size (pname_GetTexParameterfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexParameterfv x)
               serialize (target_GetTexParameterfv x)
               serialize (pname_GetTexParameterfv x)
               putSkip (requiredPadding size__)
 
data GetTexParameterfvReply = MkGetTexParameterfvReply{n_GetTexParameterfvReply
                                                       :: Word32,
                                                       datum_GetTexParameterfvReply :: FLOAT32,
                                                       data_GetTexParameterfvReply :: [FLOAT32]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexParameterfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexParameterfvReply n datum data_)
 
data GetTexParameteriv = MkGetTexParameteriv{context_tag_GetTexParameteriv
                                             :: CONTEXT_TAG,
                                             target_GetTexParameteriv :: Word32,
                                             pname_GetTexParameteriv :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexParameteriv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 137
               let size__
                     = 4 + size (context_tag_GetTexParameteriv x) +
                         size (target_GetTexParameteriv x)
                         + size (pname_GetTexParameteriv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexParameteriv x)
               serialize (target_GetTexParameteriv x)
               serialize (pname_GetTexParameteriv x)
               putSkip (requiredPadding size__)
 
data GetTexParameterivReply = MkGetTexParameterivReply{n_GetTexParameterivReply
                                                       :: Word32,
                                                       datum_GetTexParameterivReply :: Int32,
                                                       data_GetTexParameterivReply :: [Int32]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexParameterivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexParameterivReply n datum data_)
 
data GetTexLevelParameterfv = MkGetTexLevelParameterfv{context_tag_GetTexLevelParameterfv
                                                       :: CONTEXT_TAG,
                                                       target_GetTexLevelParameterfv :: Word32,
                                                       level_GetTexLevelParameterfv :: Int32,
                                                       pname_GetTexLevelParameterfv :: Word32}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexLevelParameterfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 138
               let size__
                     = 4 + size (context_tag_GetTexLevelParameterfv x) +
                         size (target_GetTexLevelParameterfv x)
                         + size (level_GetTexLevelParameterfv x)
                         + size (pname_GetTexLevelParameterfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexLevelParameterfv x)
               serialize (target_GetTexLevelParameterfv x)
               serialize (level_GetTexLevelParameterfv x)
               serialize (pname_GetTexLevelParameterfv x)
               putSkip (requiredPadding size__)
 
data GetTexLevelParameterfvReply = MkGetTexLevelParameterfvReply{n_GetTexLevelParameterfvReply
                                                                 :: Word32,
                                                                 datum_GetTexLevelParameterfvReply
                                                                 :: FLOAT32,
                                                                 data_GetTexLevelParameterfvReply ::
                                                                 [FLOAT32]}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexLevelParameterfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexLevelParameterfvReply n datum data_)
 
data GetTexLevelParameteriv = MkGetTexLevelParameteriv{context_tag_GetTexLevelParameteriv
                                                       :: CONTEXT_TAG,
                                                       target_GetTexLevelParameteriv :: Word32,
                                                       level_GetTexLevelParameteriv :: Int32,
                                                       pname_GetTexLevelParameteriv :: Word32}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTexLevelParameteriv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 139
               let size__
                     = 4 + size (context_tag_GetTexLevelParameteriv x) +
                         size (target_GetTexLevelParameteriv x)
                         + size (level_GetTexLevelParameteriv x)
                         + size (pname_GetTexLevelParameteriv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetTexLevelParameteriv x)
               serialize (target_GetTexLevelParameteriv x)
               serialize (level_GetTexLevelParameteriv x)
               serialize (pname_GetTexLevelParameteriv x)
               putSkip (requiredPadding size__)
 
data GetTexLevelParameterivReply = MkGetTexLevelParameterivReply{n_GetTexLevelParameterivReply
                                                                 :: Word32,
                                                                 datum_GetTexLevelParameterivReply
                                                                 :: Int32,
                                                                 data_GetTexLevelParameterivReply ::
                                                                 [Int32]}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTexLevelParameterivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetTexLevelParameterivReply n datum data_)
 
data IsList = MkIsList{context_tag_IsList :: CONTEXT_TAG,
                       list_IsList :: Word32}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest IsList where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 141
               let size__ = 4 + size (context_tag_IsList x) + size (list_IsList x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_IsList x)
               serialize (list_IsList x)
               putSkip (requiredPadding size__)
 
data IsListReply = MkIsListReply{ret_val_IsListReply :: BOOL32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize IsListReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               ret_val <- deserialize
               let _ = isCard32 length
               return (MkIsListReply ret_val)
 
data Flush = MkFlush{context_tag_Flush :: CONTEXT_TAG}
           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Flush where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 142
               let size__ = 4 + size (context_tag_Flush x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_Flush x)
               putSkip (requiredPadding size__)
 
data AreTexturesResident = MkAreTexturesResident{context_tag_AreTexturesResident
                                                 :: CONTEXT_TAG,
                                                 n_AreTexturesResident :: Int32,
                                                 textures_AreTexturesResident :: [Word32]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest AreTexturesResident where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 143
               let size__
                     = 4 + size (context_tag_AreTexturesResident x) +
                         size (n_AreTexturesResident x)
                         + sum (map size (textures_AreTexturesResident x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_AreTexturesResident x)
               serialize (n_AreTexturesResident x)
               serializeList (textures_AreTexturesResident x)
               putSkip (requiredPadding size__)
 
data AreTexturesResidentReply = MkAreTexturesResidentReply{ret_val_AreTexturesResidentReply
                                                           :: BOOL32,
                                                           data_AreTexturesResidentReply :: [Bool]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize AreTexturesResidentReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               ret_val <- deserialize
               skip 20
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkAreTexturesResidentReply ret_val data_)
 
data DeleteTextures = MkDeleteTextures{context_tag_DeleteTextures
                                       :: CONTEXT_TAG,
                                       n_DeleteTextures :: Int32,
                                       textures_DeleteTextures :: [Word32]}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DeleteTextures where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 144
               let size__
                     = 4 + size (context_tag_DeleteTextures x) +
                         size (n_DeleteTextures x)
                         + sum (map size (textures_DeleteTextures x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_DeleteTextures x)
               serialize (n_DeleteTextures x)
               serializeList (textures_DeleteTextures x)
               putSkip (requiredPadding size__)
 
data GenTextures = MkGenTextures{context_tag_GenTextures ::
                                 CONTEXT_TAG,
                                 n_GenTextures :: Int32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GenTextures where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 145
               let size__
                     = 4 + size (context_tag_GenTextures x) + size (n_GenTextures x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GenTextures x)
               serialize (n_GenTextures x)
               putSkip (requiredPadding size__)
 
data GenTexturesReply = MkGenTexturesReply{data_GenTexturesReply ::
                                           [Word32]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GenTexturesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               data_ <- deserializeList (fromIntegral length)
               let _ = isCard32 length
               return (MkGenTexturesReply data_)
 
data IsTexture = MkIsTexture{context_tag_IsTexture :: CONTEXT_TAG,
                             texture_IsTexture :: Word32}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest IsTexture where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 146
               let size__
                     = 4 + size (context_tag_IsTexture x) + size (texture_IsTexture x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_IsTexture x)
               serialize (texture_IsTexture x)
               putSkip (requiredPadding size__)
 
data IsTextureReply = MkIsTextureReply{ret_val_IsTextureReply ::
                                       BOOL32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize IsTextureReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               ret_val <- deserialize
               let _ = isCard32 length
               return (MkIsTextureReply ret_val)
 
data GetColorTable = MkGetColorTable{context_tag_GetColorTable ::
                                     CONTEXT_TAG,
                                     target_GetColorTable :: Word32, format_GetColorTable :: Word32,
                                     type_GetColorTable :: Word32, swap_bytes_GetColorTable :: Bool}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetColorTable where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 147
               let size__
                     = 4 + size (context_tag_GetColorTable x) +
                         size (target_GetColorTable x)
                         + size (format_GetColorTable x)
                         + size (type_GetColorTable x)
                         + size (swap_bytes_GetColorTable x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetColorTable x)
               serialize (target_GetColorTable x)
               serialize (format_GetColorTable x)
               serialize (type_GetColorTable x)
               serialize (swap_bytes_GetColorTable x)
               putSkip (requiredPadding size__)
 
data GetColorTableReply = MkGetColorTableReply{width_GetColorTableReply
                                               :: Int32,
                                               data_GetColorTableReply :: [Word8]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetColorTableReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 8
               width <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkGetColorTableReply width data_)
 
data GetColorTableParameterfv = MkGetColorTableParameterfv{context_tag_GetColorTableParameterfv
                                                           :: CONTEXT_TAG,
                                                           target_GetColorTableParameterfv ::
                                                           Word32,
                                                           pname_GetColorTableParameterfv :: Word32}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetColorTableParameterfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 148
               let size__
                     = 4 + size (context_tag_GetColorTableParameterfv x) +
                         size (target_GetColorTableParameterfv x)
                         + size (pname_GetColorTableParameterfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetColorTableParameterfv x)
               serialize (target_GetColorTableParameterfv x)
               serialize (pname_GetColorTableParameterfv x)
               putSkip (requiredPadding size__)
 
data GetColorTableParameterfvReply = MkGetColorTableParameterfvReply{n_GetColorTableParameterfvReply
                                                                     :: Word32,
                                                                     datum_GetColorTableParameterfvReply
                                                                     :: FLOAT32,
                                                                     data_GetColorTableParameterfvReply
                                                                     :: [FLOAT32]}
                                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetColorTableParameterfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetColorTableParameterfvReply n datum data_)
 
data GetColorTableParameteriv = MkGetColorTableParameteriv{context_tag_GetColorTableParameteriv
                                                           :: CONTEXT_TAG,
                                                           target_GetColorTableParameteriv ::
                                                           Word32,
                                                           pname_GetColorTableParameteriv :: Word32}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetColorTableParameteriv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 149
               let size__
                     = 4 + size (context_tag_GetColorTableParameteriv x) +
                         size (target_GetColorTableParameteriv x)
                         + size (pname_GetColorTableParameteriv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetColorTableParameteriv x)
               serialize (target_GetColorTableParameteriv x)
               serialize (pname_GetColorTableParameteriv x)
               putSkip (requiredPadding size__)
 
data GetColorTableParameterivReply = MkGetColorTableParameterivReply{n_GetColorTableParameterivReply
                                                                     :: Word32,
                                                                     datum_GetColorTableParameterivReply
                                                                     :: Int32,
                                                                     data_GetColorTableParameterivReply
                                                                     :: [Int32]}
                                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetColorTableParameterivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetColorTableParameterivReply n datum data_)
 
data GetConvolutionFilter = MkGetConvolutionFilter{context_tag_GetConvolutionFilter
                                                   :: CONTEXT_TAG,
                                                   target_GetConvolutionFilter :: Word32,
                                                   format_GetConvolutionFilter :: Word32,
                                                   type_GetConvolutionFilter :: Word32,
                                                   swap_bytes_GetConvolutionFilter :: Bool}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetConvolutionFilter where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 150
               let size__
                     = 4 + size (context_tag_GetConvolutionFilter x) +
                         size (target_GetConvolutionFilter x)
                         + size (format_GetConvolutionFilter x)
                         + size (type_GetConvolutionFilter x)
                         + size (swap_bytes_GetConvolutionFilter x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetConvolutionFilter x)
               serialize (target_GetConvolutionFilter x)
               serialize (format_GetConvolutionFilter x)
               serialize (type_GetConvolutionFilter x)
               serialize (swap_bytes_GetConvolutionFilter x)
               putSkip (requiredPadding size__)
 
data GetConvolutionFilterReply = MkGetConvolutionFilterReply{width_GetConvolutionFilterReply
                                                             :: Int32,
                                                             height_GetConvolutionFilterReply ::
                                                             Int32,
                                                             data_GetConvolutionFilterReply ::
                                                             [Word8]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetConvolutionFilterReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 8
               width <- deserialize
               height <- deserialize
               skip 8
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkGetConvolutionFilterReply width height data_)
 
data GetConvolutionParameterfv = MkGetConvolutionParameterfv{context_tag_GetConvolutionParameterfv
                                                             :: CONTEXT_TAG,
                                                             target_GetConvolutionParameterfv ::
                                                             Word32,
                                                             pname_GetConvolutionParameterfv ::
                                                             Word32}
                               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetConvolutionParameterfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 151
               let size__
                     = 4 + size (context_tag_GetConvolutionParameterfv x) +
                         size (target_GetConvolutionParameterfv x)
                         + size (pname_GetConvolutionParameterfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetConvolutionParameterfv x)
               serialize (target_GetConvolutionParameterfv x)
               serialize (pname_GetConvolutionParameterfv x)
               putSkip (requiredPadding size__)
 
data GetConvolutionParameterfvReply = MkGetConvolutionParameterfvReply{n_GetConvolutionParameterfvReply
                                                                       :: Word32,
                                                                       datum_GetConvolutionParameterfvReply
                                                                       :: FLOAT32,
                                                                       data_GetConvolutionParameterfvReply
                                                                       :: [FLOAT32]}
                                    deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetConvolutionParameterfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetConvolutionParameterfvReply n datum data_)
 
data GetConvolutionParameteriv = MkGetConvolutionParameteriv{context_tag_GetConvolutionParameteriv
                                                             :: CONTEXT_TAG,
                                                             target_GetConvolutionParameteriv ::
                                                             Word32,
                                                             pname_GetConvolutionParameteriv ::
                                                             Word32}
                               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetConvolutionParameteriv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 152
               let size__
                     = 4 + size (context_tag_GetConvolutionParameteriv x) +
                         size (target_GetConvolutionParameteriv x)
                         + size (pname_GetConvolutionParameteriv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetConvolutionParameteriv x)
               serialize (target_GetConvolutionParameteriv x)
               serialize (pname_GetConvolutionParameteriv x)
               putSkip (requiredPadding size__)
 
data GetConvolutionParameterivReply = MkGetConvolutionParameterivReply{n_GetConvolutionParameterivReply
                                                                       :: Word32,
                                                                       datum_GetConvolutionParameterivReply
                                                                       :: Int32,
                                                                       data_GetConvolutionParameterivReply
                                                                       :: [Int32]}
                                    deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetConvolutionParameterivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetConvolutionParameterivReply n datum data_)
 
data GetSeparableFilter = MkGetSeparableFilter{context_tag_GetSeparableFilter
                                               :: CONTEXT_TAG,
                                               target_GetSeparableFilter :: Word32,
                                               format_GetSeparableFilter :: Word32,
                                               type_GetSeparableFilter :: Word32,
                                               swap_bytes_GetSeparableFilter :: Bool}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetSeparableFilter where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 153
               let size__
                     = 4 + size (context_tag_GetSeparableFilter x) +
                         size (target_GetSeparableFilter x)
                         + size (format_GetSeparableFilter x)
                         + size (type_GetSeparableFilter x)
                         + size (swap_bytes_GetSeparableFilter x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetSeparableFilter x)
               serialize (target_GetSeparableFilter x)
               serialize (format_GetSeparableFilter x)
               serialize (type_GetSeparableFilter x)
               serialize (swap_bytes_GetSeparableFilter x)
               putSkip (requiredPadding size__)
 
data GetSeparableFilterReply = MkGetSeparableFilterReply{row_w_GetSeparableFilterReply
                                                         :: Int32,
                                                         col_h_GetSeparableFilterReply :: Int32,
                                                         rows_and_cols_GetSeparableFilterReply ::
                                                         [Word8]}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetSeparableFilterReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 8
               row_w <- deserialize
               col_h <- deserialize
               skip 8
               rows_and_cols <- deserializeList
                                  (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkGetSeparableFilterReply row_w col_h rows_and_cols)
 
data GetHistogram = MkGetHistogram{context_tag_GetHistogram ::
                                   CONTEXT_TAG,
                                   target_GetHistogram :: Word32, format_GetHistogram :: Word32,
                                   type_GetHistogram :: Word32, swap_bytes_GetHistogram :: Bool,
                                   reset_GetHistogram :: Bool}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetHistogram where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 154
               let size__
                     = 4 + size (context_tag_GetHistogram x) +
                         size (target_GetHistogram x)
                         + size (format_GetHistogram x)
                         + size (type_GetHistogram x)
                         + size (swap_bytes_GetHistogram x)
                         + size (reset_GetHistogram x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetHistogram x)
               serialize (target_GetHistogram x)
               serialize (format_GetHistogram x)
               serialize (type_GetHistogram x)
               serialize (swap_bytes_GetHistogram x)
               serialize (reset_GetHistogram x)
               putSkip (requiredPadding size__)
 
data GetHistogramReply = MkGetHistogramReply{width_GetHistogramReply
                                             :: Int32,
                                             data_GetHistogramReply :: [Word8]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetHistogramReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 8
               width <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkGetHistogramReply width data_)
 
data GetHistogramParameterfv = MkGetHistogramParameterfv{context_tag_GetHistogramParameterfv
                                                         :: CONTEXT_TAG,
                                                         target_GetHistogramParameterfv :: Word32,
                                                         pname_GetHistogramParameterfv :: Word32}
                             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetHistogramParameterfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 155
               let size__
                     = 4 + size (context_tag_GetHistogramParameterfv x) +
                         size (target_GetHistogramParameterfv x)
                         + size (pname_GetHistogramParameterfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetHistogramParameterfv x)
               serialize (target_GetHistogramParameterfv x)
               serialize (pname_GetHistogramParameterfv x)
               putSkip (requiredPadding size__)
 
data GetHistogramParameterfvReply = MkGetHistogramParameterfvReply{n_GetHistogramParameterfvReply
                                                                   :: Word32,
                                                                   datum_GetHistogramParameterfvReply
                                                                   :: FLOAT32,
                                                                   data_GetHistogramParameterfvReply
                                                                   :: [FLOAT32]}
                                  deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetHistogramParameterfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetHistogramParameterfvReply n datum data_)
 
data GetHistogramParameteriv = MkGetHistogramParameteriv{context_tag_GetHistogramParameteriv
                                                         :: CONTEXT_TAG,
                                                         target_GetHistogramParameteriv :: Word32,
                                                         pname_GetHistogramParameteriv :: Word32}
                             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetHistogramParameteriv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 156
               let size__
                     = 4 + size (context_tag_GetHistogramParameteriv x) +
                         size (target_GetHistogramParameteriv x)
                         + size (pname_GetHistogramParameteriv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetHistogramParameteriv x)
               serialize (target_GetHistogramParameteriv x)
               serialize (pname_GetHistogramParameteriv x)
               putSkip (requiredPadding size__)
 
data GetHistogramParameterivReply = MkGetHistogramParameterivReply{n_GetHistogramParameterivReply
                                                                   :: Word32,
                                                                   datum_GetHistogramParameterivReply
                                                                   :: Int32,
                                                                   data_GetHistogramParameterivReply
                                                                   :: [Int32]}
                                  deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetHistogramParameterivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetHistogramParameterivReply n datum data_)
 
data GetMinmax = MkGetMinmax{context_tag_GetMinmax :: CONTEXT_TAG,
                             target_GetMinmax :: Word32, format_GetMinmax :: Word32,
                             type_GetMinmax :: Word32, swap_bytes_GetMinmax :: Bool,
                             reset_GetMinmax :: Bool}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetMinmax where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 157
               let size__
                     = 4 + size (context_tag_GetMinmax x) + size (target_GetMinmax x) +
                         size (format_GetMinmax x)
                         + size (type_GetMinmax x)
                         + size (swap_bytes_GetMinmax x)
                         + size (reset_GetMinmax x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetMinmax x)
               serialize (target_GetMinmax x)
               serialize (format_GetMinmax x)
               serialize (type_GetMinmax x)
               serialize (swap_bytes_GetMinmax x)
               serialize (reset_GetMinmax x)
               putSkip (requiredPadding size__)
 
data GetMinmaxReply = MkGetMinmaxReply{data_GetMinmaxReply ::
                                       [Word8]}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetMinmaxReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkGetMinmaxReply data_)
 
data GetMinmaxParameterfv = MkGetMinmaxParameterfv{context_tag_GetMinmaxParameterfv
                                                   :: CONTEXT_TAG,
                                                   target_GetMinmaxParameterfv :: Word32,
                                                   pname_GetMinmaxParameterfv :: Word32}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetMinmaxParameterfv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 158
               let size__
                     = 4 + size (context_tag_GetMinmaxParameterfv x) +
                         size (target_GetMinmaxParameterfv x)
                         + size (pname_GetMinmaxParameterfv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetMinmaxParameterfv x)
               serialize (target_GetMinmaxParameterfv x)
               serialize (pname_GetMinmaxParameterfv x)
               putSkip (requiredPadding size__)
 
data GetMinmaxParameterfvReply = MkGetMinmaxParameterfvReply{n_GetMinmaxParameterfvReply
                                                             :: Word32,
                                                             datum_GetMinmaxParameterfvReply ::
                                                             FLOAT32,
                                                             data_GetMinmaxParameterfvReply ::
                                                             [FLOAT32]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetMinmaxParameterfvReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetMinmaxParameterfvReply n datum data_)
 
data GetMinmaxParameteriv = MkGetMinmaxParameteriv{context_tag_GetMinmaxParameteriv
                                                   :: CONTEXT_TAG,
                                                   target_GetMinmaxParameteriv :: Word32,
                                                   pname_GetMinmaxParameteriv :: Word32}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetMinmaxParameteriv where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 159
               let size__
                     = 4 + size (context_tag_GetMinmaxParameteriv x) +
                         size (target_GetMinmaxParameteriv x)
                         + size (pname_GetMinmaxParameteriv x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetMinmaxParameteriv x)
               serialize (target_GetMinmaxParameteriv x)
               serialize (pname_GetMinmaxParameteriv x)
               putSkip (requiredPadding size__)
 
data GetMinmaxParameterivReply = MkGetMinmaxParameterivReply{n_GetMinmaxParameterivReply
                                                             :: Word32,
                                                             datum_GetMinmaxParameterivReply ::
                                                             Int32,
                                                             data_GetMinmaxParameterivReply ::
                                                             [Int32]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetMinmaxParameterivReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetMinmaxParameterivReply n datum data_)
 
data GetCompressedTexImageARB = MkGetCompressedTexImageARB{context_tag_GetCompressedTexImageARB
                                                           :: CONTEXT_TAG,
                                                           target_GetCompressedTexImageARB ::
                                                           Word32,
                                                           level_GetCompressedTexImageARB :: Int32}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetCompressedTexImageARB where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 160
               let size__
                     = 4 + size (context_tag_GetCompressedTexImageARB x) +
                         size (target_GetCompressedTexImageARB x)
                         + size (level_GetCompressedTexImageARB x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetCompressedTexImageARB x)
               serialize (target_GetCompressedTexImageARB x)
               serialize (level_GetCompressedTexImageARB x)
               putSkip (requiredPadding size__)
 
data GetCompressedTexImageARBReply = MkGetCompressedTexImageARBReply{size_GetCompressedTexImageARBReply
                                                                     :: Int32,
                                                                     data_GetCompressedTexImageARBReply
                                                                     :: [Word8]}
                                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetCompressedTexImageARBReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 8
               size <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral (fromIntegral (length * 4)))
               let _ = isCard32 length
               return (MkGetCompressedTexImageARBReply size data_)
 
data DeleteQueriesARB = MkDeleteQueriesARB{context_tag_DeleteQueriesARB
                                           :: CONTEXT_TAG,
                                           n_DeleteQueriesARB :: Int32,
                                           ids_DeleteQueriesARB :: [Word32]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DeleteQueriesARB where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 161
               let size__
                     = 4 + size (context_tag_DeleteQueriesARB x) +
                         size (n_DeleteQueriesARB x)
                         + sum (map size (ids_DeleteQueriesARB x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_DeleteQueriesARB x)
               serialize (n_DeleteQueriesARB x)
               serializeList (ids_DeleteQueriesARB x)
               putSkip (requiredPadding size__)
 
data GenQueriesARB = MkGenQueriesARB{context_tag_GenQueriesARB ::
                                     CONTEXT_TAG,
                                     n_GenQueriesARB :: Int32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GenQueriesARB where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 162
               let size__
                     = 4 + size (context_tag_GenQueriesARB x) + size (n_GenQueriesARB x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GenQueriesARB x)
               serialize (n_GenQueriesARB x)
               putSkip (requiredPadding size__)
 
data GenQueriesARBReply = MkGenQueriesARBReply{data_GenQueriesARBReply
                                               :: [Word32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GenQueriesARBReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               data_ <- deserializeList (fromIntegral length)
               let _ = isCard32 length
               return (MkGenQueriesARBReply data_)
 
data IsQueryARB = MkIsQueryARB{context_tag_IsQueryARB ::
                               CONTEXT_TAG,
                               id_IsQueryARB :: Word32}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest IsQueryARB where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 163
               let size__
                     = 4 + size (context_tag_IsQueryARB x) + size (id_IsQueryARB x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_IsQueryARB x)
               serialize (id_IsQueryARB x)
               putSkip (requiredPadding size__)
 
data IsQueryARBReply = MkIsQueryARBReply{ret_val_IsQueryARBReply ::
                                         BOOL32}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize IsQueryARBReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               ret_val <- deserialize
               let _ = isCard32 length
               return (MkIsQueryARBReply ret_val)
 
data GetQueryivARB = MkGetQueryivARB{context_tag_GetQueryivARB ::
                                     CONTEXT_TAG,
                                     target_GetQueryivARB :: Word32, pname_GetQueryivARB :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetQueryivARB where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 164
               let size__
                     = 4 + size (context_tag_GetQueryivARB x) +
                         size (target_GetQueryivARB x)
                         + size (pname_GetQueryivARB x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetQueryivARB x)
               serialize (target_GetQueryivARB x)
               serialize (pname_GetQueryivARB x)
               putSkip (requiredPadding size__)
 
data GetQueryivARBReply = MkGetQueryivARBReply{n_GetQueryivARBReply
                                               :: Word32,
                                               datum_GetQueryivARBReply :: Int32,
                                               data_GetQueryivARBReply :: [Int32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetQueryivARBReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetQueryivARBReply n datum data_)
 
data GetQueryObjectivARB = MkGetQueryObjectivARB{context_tag_GetQueryObjectivARB
                                                 :: CONTEXT_TAG,
                                                 id_GetQueryObjectivARB :: Word32,
                                                 pname_GetQueryObjectivARB :: Word32}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetQueryObjectivARB where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 165
               let size__
                     = 4 + size (context_tag_GetQueryObjectivARB x) +
                         size (id_GetQueryObjectivARB x)
                         + size (pname_GetQueryObjectivARB x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetQueryObjectivARB x)
               serialize (id_GetQueryObjectivARB x)
               serialize (pname_GetQueryObjectivARB x)
               putSkip (requiredPadding size__)
 
data GetQueryObjectivARBReply = MkGetQueryObjectivARBReply{n_GetQueryObjectivARBReply
                                                           :: Word32,
                                                           datum_GetQueryObjectivARBReply :: Int32,
                                                           data_GetQueryObjectivARBReply :: [Int32]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetQueryObjectivARBReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetQueryObjectivARBReply n datum data_)
 
data GetQueryObjectuivARB = MkGetQueryObjectuivARB{context_tag_GetQueryObjectuivARB
                                                   :: CONTEXT_TAG,
                                                   id_GetQueryObjectuivARB :: Word32,
                                                   pname_GetQueryObjectuivARB :: Word32}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetQueryObjectuivARB where
        extensionId _ = "GLX"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 166
               let size__
                     = 4 + size (context_tag_GetQueryObjectuivARB x) +
                         size (id_GetQueryObjectuivARB x)
                         + size (pname_GetQueryObjectuivARB x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_tag_GetQueryObjectuivARB x)
               serialize (id_GetQueryObjectuivARB x)
               serialize (pname_GetQueryObjectuivARB x)
               putSkip (requiredPadding size__)
 
data GetQueryObjectuivARBReply = MkGetQueryObjectuivARBReply{n_GetQueryObjectuivARBReply
                                                             :: Word32,
                                                             datum_GetQueryObjectuivARBReply ::
                                                             Word32,
                                                             data_GetQueryObjectuivARBReply ::
                                                             [Word32]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetQueryObjectuivARBReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 4
               n <- deserialize
               datum <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral n)
               let _ = isCard32 length
               return (MkGetQueryObjectuivARBReply n datum data_)