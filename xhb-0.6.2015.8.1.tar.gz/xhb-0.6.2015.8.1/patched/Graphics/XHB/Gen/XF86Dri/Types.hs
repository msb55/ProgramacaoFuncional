module Graphics.XHB.Gen.XF86Dri.Types
       (deserializeError, deserializeEvent, DrmClipRect(..),
        QueryVersion(..), QueryVersionReply(..),
        QueryDirectRenderingCapable(..),
        QueryDirectRenderingCapableReply(..), OpenConnection(..),
        OpenConnectionReply(..), CloseConnection(..),
        GetClientDriverName(..), GetClientDriverNameReply(..),
        CreateContext(..), CreateContextReply(..), DestroyContext(..),
        CreateDrawable(..), CreateDrawableReply(..), DestroyDrawable(..),
        GetDrawableInfo(..), GetDrawableInfoReply(..), GetDeviceInfo(..),
        GetDeviceInfoReply(..), AuthConnection(..),
        AuthConnectionReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data DrmClipRect = MkDrmClipRect{x1_DrmClipRect :: Int16,
                                 y1_DrmClipRect :: Int16, x2_DrmClipRect :: Int16,
                                 x3_DrmClipRect :: Int16}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DrmClipRect where
        serialize x
          = do serialize (x1_DrmClipRect x)
               serialize (y1_DrmClipRect x)
               serialize (x2_DrmClipRect x)
               serialize (x3_DrmClipRect x)
        size x
          = size (x1_DrmClipRect x) + size (y1_DrmClipRect x) +
              size (x2_DrmClipRect x)
              + size (x3_DrmClipRect x)
 
instance Deserialize DrmClipRect where
        deserialize
          = do x1 <- deserialize
               y1 <- deserialize
               x2 <- deserialize
               x3 <- deserialize
               return (MkDrmClipRect x1 y1 x2 x3)
 
data QueryVersion = MkQueryVersion{}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{dri_major_version_QueryVersionReply
                                             :: Word16,
                                             dri_minor_version_QueryVersionReply :: Word16,
                                             dri_minor_patch_QueryVersionReply :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               dri_major_version <- deserialize
               dri_minor_version <- deserialize
               dri_minor_patch <- deserialize
               let _ = isCard32 length
               return
                 (MkQueryVersionReply dri_major_version dri_minor_version
                    dri_minor_patch)
 
data QueryDirectRenderingCapable = MkQueryDirectRenderingCapable{screen_QueryDirectRenderingCapable
                                                                 :: Word32}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryDirectRenderingCapable where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4 + size (screen_QueryDirectRenderingCapable x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_QueryDirectRenderingCapable x)
               putSkip (requiredPadding size__)
 
data QueryDirectRenderingCapableReply = MkQueryDirectRenderingCapableReply{is_capable_QueryDirectRenderingCapableReply
                                                                           :: Bool}
                                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryDirectRenderingCapableReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               is_capable <- deserialize
               let _ = isCard32 length
               return (MkQueryDirectRenderingCapableReply is_capable)
 
data OpenConnection = MkOpenConnection{screen_OpenConnection ::
                                       Word32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest OpenConnection where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4 + size (screen_OpenConnection x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_OpenConnection x)
               putSkip (requiredPadding size__)
 
data OpenConnectionReply = MkOpenConnectionReply{sarea_handle_low_OpenConnectionReply
                                                 :: Word32,
                                                 sarea_handle_high_OpenConnectionReply :: Word32,
                                                 bus_id_len_OpenConnectionReply :: Word32,
                                                 bus_id_OpenConnectionReply :: [CChar]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize OpenConnectionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               sarea_handle_low <- deserialize
               sarea_handle_high <- deserialize
               bus_id_len <- deserialize
               skip 12
               bus_id <- deserializeList (fromIntegral bus_id_len)
               let _ = isCard32 length
               return
                 (MkOpenConnectionReply sarea_handle_low sarea_handle_high
                    bus_id_len
                    bus_id)
 
data CloseConnection = MkCloseConnection{screen_CloseConnection ::
                                         Word32}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CloseConnection where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__ = 4 + size (screen_CloseConnection x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_CloseConnection x)
               putSkip (requiredPadding size__)
 
data GetClientDriverName = MkGetClientDriverName{screen_GetClientDriverName
                                                 :: Word32}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetClientDriverName where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4 + size (screen_GetClientDriverName x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_GetClientDriverName x)
               putSkip (requiredPadding size__)
 
data GetClientDriverNameReply = MkGetClientDriverNameReply{client_driver_major_version_GetClientDriverNameReply
                                                           :: Word32,
                                                           client_driver_minor_version_GetClientDriverNameReply
                                                           :: Word32,
                                                           client_driver_patch_version_GetClientDriverNameReply
                                                           :: Word32,
                                                           client_driver_name_len_GetClientDriverNameReply
                                                           :: Word32,
                                                           client_driver_name_GetClientDriverNameReply
                                                           :: [CChar]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetClientDriverNameReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               client_driver_major_version <- deserialize
               client_driver_minor_version <- deserialize
               client_driver_patch_version <- deserialize
               client_driver_name_len <- deserialize
               skip 8
               client_driver_name <- deserializeList
                                       (fromIntegral client_driver_name_len)
               let _ = isCard32 length
               return
                 (MkGetClientDriverNameReply client_driver_major_version
                    client_driver_minor_version
                    client_driver_patch_version
                    client_driver_name_len
                    client_driver_name)
 
data CreateContext = MkCreateContext{screen_CreateContext ::
                                     Word32,
                                     visual_CreateContext :: Word32,
                                     context_CreateContext :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateContext where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (screen_CreateContext x) + size (visual_CreateContext x)
                         + size (context_CreateContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_CreateContext x)
               serialize (visual_CreateContext x)
               serialize (context_CreateContext x)
               putSkip (requiredPadding size__)
 
data CreateContextReply = MkCreateContextReply{hw_context_CreateContextReply
                                               :: Word32}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize CreateContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               hw_context <- deserialize
               let _ = isCard32 length
               return (MkCreateContextReply hw_context)
 
data DestroyContext = MkDestroyContext{screen_DestroyContext ::
                                       Word32,
                                       context_DestroyContext :: Word32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyContext where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__
                     = 4 + size (screen_DestroyContext x) +
                         size (context_DestroyContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_DestroyContext x)
               serialize (context_DestroyContext x)
               putSkip (requiredPadding size__)
 
data CreateDrawable = MkCreateDrawable{screen_CreateDrawable ::
                                       Word32,
                                       drawable_CreateDrawable :: Word32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateDrawable where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__
                     = 4 + size (screen_CreateDrawable x) +
                         size (drawable_CreateDrawable x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_CreateDrawable x)
               serialize (drawable_CreateDrawable x)
               putSkip (requiredPadding size__)
 
data CreateDrawableReply = MkCreateDrawableReply{hw_drawable_handle_CreateDrawableReply
                                                 :: Word32}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize CreateDrawableReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               hw_drawable_handle <- deserialize
               let _ = isCard32 length
               return (MkCreateDrawableReply hw_drawable_handle)
 
data DestroyDrawable = MkDestroyDrawable{screen_DestroyDrawable ::
                                         Word32,
                                         drawable_DestroyDrawable :: Word32}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyDrawable where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__
                     = 4 + size (screen_DestroyDrawable x) +
                         size (drawable_DestroyDrawable x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_DestroyDrawable x)
               serialize (drawable_DestroyDrawable x)
               putSkip (requiredPadding size__)
 
data GetDrawableInfo = MkGetDrawableInfo{screen_GetDrawableInfo ::
                                         Word32,
                                         drawable_GetDrawableInfo :: Word32}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDrawableInfo where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 9
               let size__
                     = 4 + size (screen_GetDrawableInfo x) +
                         size (drawable_GetDrawableInfo x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_GetDrawableInfo x)
               serialize (drawable_GetDrawableInfo x)
               putSkip (requiredPadding size__)
 
data GetDrawableInfoReply = MkGetDrawableInfoReply{drawable_table_index_GetDrawableInfoReply
                                                   :: Word32,
                                                   drawable_table_stamp_GetDrawableInfoReply ::
                                                   Word32,
                                                   drawable_origin_X_GetDrawableInfoReply :: Int16,
                                                   drawable_origin_Y_GetDrawableInfoReply :: Int16,
                                                   drawable_size_W_GetDrawableInfoReply :: Int16,
                                                   drawable_size_H_GetDrawableInfoReply :: Int16,
                                                   num_clip_rects_GetDrawableInfoReply :: Word32,
                                                   clip_rects_GetDrawableInfoReply :: [DrmClipRect]}
                          deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDrawableInfoReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               drawable_table_index <- deserialize
               drawable_table_stamp <- deserialize
               drawable_origin_X <- deserialize
               drawable_origin_Y <- deserialize
               drawable_size_W <- deserialize
               drawable_size_H <- deserialize
               num_clip_rects <- deserialize
               skip 4
               clip_rects <- deserializeList (fromIntegral num_clip_rects)
               let _ = isCard32 length
               return
                 (MkGetDrawableInfoReply drawable_table_index drawable_table_stamp
                    drawable_origin_X
                    drawable_origin_Y
                    drawable_size_W
                    drawable_size_H
                    num_clip_rects
                    clip_rects)
 
data GetDeviceInfo = MkGetDeviceInfo{screen_GetDeviceInfo ::
                                     Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceInfo where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 10
               let size__ = 4 + size (screen_GetDeviceInfo x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_GetDeviceInfo x)
               putSkip (requiredPadding size__)
 
data GetDeviceInfoReply = MkGetDeviceInfoReply{framebuffer_handle_low_GetDeviceInfoReply
                                               :: Word32,
                                               framebuffer_handle_high_GetDeviceInfoReply :: Word32,
                                               framebuffer_origin_offset_GetDeviceInfoReply ::
                                               Word32,
                                               framebuffer_size_GetDeviceInfoReply :: Word32,
                                               framebuffer_stride_GetDeviceInfoReply :: Word32,
                                               device_private_size_GetDeviceInfoReply :: Word32,
                                               device_private_GetDeviceInfoReply :: [Word32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceInfoReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               framebuffer_handle_low <- deserialize
               framebuffer_handle_high <- deserialize
               framebuffer_origin_offset <- deserialize
               framebuffer_size <- deserialize
               framebuffer_stride <- deserialize
               device_private_size <- deserialize
               device_private <- deserializeList
                                   (fromIntegral device_private_size)
               let _ = isCard32 length
               return
                 (MkGetDeviceInfoReply framebuffer_handle_low
                    framebuffer_handle_high
                    framebuffer_origin_offset
                    framebuffer_size
                    framebuffer_stride
                    device_private_size
                    device_private)
 
data AuthConnection = MkAuthConnection{screen_AuthConnection ::
                                       Word32,
                                       magic_AuthConnection :: Word32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest AuthConnection where
        extensionId _ = "XFree86-DRI"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 11
               let size__
                     = 4 + size (screen_AuthConnection x) +
                         size (magic_AuthConnection x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_AuthConnection x)
               serialize (magic_AuthConnection x)
               putSkip (requiredPadding size__)
 
data AuthConnectionReply = MkAuthConnectionReply{authenticated_AuthConnectionReply
                                                 :: Word32}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize AuthConnectionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               authenticated <- deserialize
               let _ = isCard32 length
               return (MkAuthConnectionReply authenticated)