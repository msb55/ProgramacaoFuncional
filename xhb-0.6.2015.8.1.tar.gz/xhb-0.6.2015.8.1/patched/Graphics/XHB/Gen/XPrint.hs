module Graphics.XHB.Gen.XPrint
       (extension, printQueryVersion, printGetPrinterList,
        printRehashPrinterList, createContext, printSetContext,
        printGetContext, printDestroyContext, printGetScreenOfContext,
        printStartJob, printEndJob, printStartDoc, printEndDoc,
        printPutDocumentData, printGetDocumentData, printStartPage,
        printEndPage, printSelectInput, printInputSelected,
        printGetAttributes, printGetOneAttributes, printSetAttributes,
        printGetPageDimensions, printQueryScreens, printSetImageResolution,
        printGetImageResolution, module Graphics.XHB.Gen.XPrint.Types)
       where
import Graphics.XHB.Gen.XPrint.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "XpExtension"
 
printQueryVersion ::
                    Graphics.XHB.Connection.Types.Connection ->
                      IO (Receipt PrintQueryVersionReply)
printQueryVersion c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkPrintQueryVersion
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printGetPrinterList ::
                      Graphics.XHB.Connection.Types.Connection ->
                        PrintGetPrinterList -> IO (Receipt PrintGetPrinterListReply)
printGetPrinterList c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printRehashPrinterList ::
                         Graphics.XHB.Connection.Types.Connection -> IO ()
printRehashPrinterList c
  = do let req = MkPrintRehashPrinterList
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createContext ::
                Graphics.XHB.Connection.Types.Connection -> CreateContext -> IO ()
createContext c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printSetContext ::
                  Graphics.XHB.Connection.Types.Connection -> Word32 -> IO ()
printSetContext c context
  = do let req = MkPrintSetContext context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printGetContext ::
                  Graphics.XHB.Connection.Types.Connection -> IO (Receipt Word32)
printGetContext c
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (context_PrintGetContextReply `fmap` deserialize))
       let req = MkPrintGetContext
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printDestroyContext ::
                      Graphics.XHB.Connection.Types.Connection -> Word32 -> IO ()
printDestroyContext c context
  = do let req = MkPrintDestroyContext context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printGetScreenOfContext ::
                          Graphics.XHB.Connection.Types.Connection -> IO (Receipt WINDOW)
printGetScreenOfContext c
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (root_PrintGetScreenOfContextReply `fmap` deserialize))
       let req = MkPrintGetScreenOfContext
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printStartJob ::
                Graphics.XHB.Connection.Types.Connection -> Word8 -> IO ()
printStartJob c output_mode
  = do let req = MkPrintStartJob output_mode
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printEndJob ::
              Graphics.XHB.Connection.Types.Connection -> Bool -> IO ()
printEndJob c cancel
  = do let req = MkPrintEndJob cancel
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printStartDoc ::
                Graphics.XHB.Connection.Types.Connection -> Word8 -> IO ()
printStartDoc c driver_mode
  = do let req = MkPrintStartDoc driver_mode
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printEndDoc ::
              Graphics.XHB.Connection.Types.Connection -> Bool -> IO ()
printEndDoc c cancel
  = do let req = MkPrintEndDoc cancel
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printPutDocumentData ::
                       Graphics.XHB.Connection.Types.Connection ->
                         PrintPutDocumentData -> IO ()
printPutDocumentData c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printGetDocumentData ::
                       Graphics.XHB.Connection.Types.Connection ->
                         PCONTEXT -> Word32 -> IO (Receipt PrintGetDocumentDataReply)
printGetDocumentData c context max_bytes
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkPrintGetDocumentData context max_bytes
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printStartPage ::
                 Graphics.XHB.Connection.Types.Connection -> WINDOW -> IO ()
printStartPage c window
  = do let req = MkPrintStartPage window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printEndPage ::
               Graphics.XHB.Connection.Types.Connection -> Bool -> IO ()
printEndPage c cancel
  = do let req = MkPrintEndPage cancel
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printSelectInput ::
                   Graphics.XHB.Connection.Types.Connection ->
                     PCONTEXT -> ValueParam Word32 -> IO ()
printSelectInput c context event
  = do let req = MkPrintSelectInput context event
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printInputSelected ::
                     Graphics.XHB.Connection.Types.Connection ->
                       PCONTEXT -> IO (Receipt PrintInputSelectedReply)
printInputSelected c context
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkPrintInputSelected context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printGetAttributes ::
                     Graphics.XHB.Connection.Types.Connection ->
                       PCONTEXT -> Word8 -> IO (Receipt PrintGetAttributesReply)
printGetAttributes c context pool
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkPrintGetAttributes context pool
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printGetOneAttributes ::
                        Graphics.XHB.Connection.Types.Connection ->
                          PrintGetOneAttributes -> IO (Receipt PrintGetOneAttributesReply)
printGetOneAttributes c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printSetAttributes ::
                     Graphics.XHB.Connection.Types.Connection ->
                       PrintSetAttributes -> IO ()
printSetAttributes c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
printGetPageDimensions ::
                         Graphics.XHB.Connection.Types.Connection ->
                           PCONTEXT -> IO (Receipt PrintGetPageDimensionsReply)
printGetPageDimensions c context
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkPrintGetPageDimensions context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printQueryScreens ::
                    Graphics.XHB.Connection.Types.Connection ->
                      IO (Receipt PrintQueryScreensReply)
printQueryScreens c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkPrintQueryScreens
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printSetImageResolution ::
                          Graphics.XHB.Connection.Types.Connection ->
                            PCONTEXT -> Word16 -> IO (Receipt PrintSetImageResolutionReply)
printSetImageResolution c context image_resolution
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkPrintSetImageResolution context image_resolution
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
printGetImageResolution ::
                          Graphics.XHB.Connection.Types.Connection ->
                            PCONTEXT -> IO (Receipt Word16)
printGetImageResolution c context
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet
                                   (image_resolution_PrintGetImageResolutionReply `fmap`
                                      deserialize))
       let req = MkPrintGetImageResolution context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt