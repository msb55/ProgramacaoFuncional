module Graphics.XHB.Gen.Damage.Types
       (deserializeError, deserializeEvent, DAMAGE, ReportLevel(..),
        QueryVersion(..), QueryVersionReply(..), Create(..), Destroy(..),
        Subtract(..), Add(..), NotifyEvent(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
import Graphics.XHB.Gen.XFixes.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.XFixes.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get NotifyEvent))
deserializeEvent _ = Nothing
 
newtype DAMAGE = MkDAMAGE Xid
                 deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
data ReportLevel = ReportLevelRawRectangles
                 | ReportLevelDeltaRectangles
                 | ReportLevelBoundingBox
                 | ReportLevelNonEmpty
                 deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum ReportLevel where
        toValue ReportLevelRawRectangles{} = 0
        toValue ReportLevelDeltaRectangles{} = 1
        toValue ReportLevelBoundingBox{} = 2
        toValue ReportLevelNonEmpty{} = 3
        fromValue 0 = ReportLevelRawRectangles
        fromValue 1 = ReportLevelDeltaRectangles
        fromValue 2 = ReportLevelBoundingBox
        fromValue 3 = ReportLevelNonEmpty
 
data QueryVersion = MkQueryVersion{client_major_version_QueryVersion
                                   :: Word32,
                                   client_minor_version_QueryVersion :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "DAMAGE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_version_QueryVersion x) +
                         size (client_minor_version_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_version_QueryVersion x)
               serialize (client_minor_version_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_version_QueryVersionReply
                                             :: Word32,
                                             minor_version_QueryVersionReply :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               skip 16
               let _ = isCard32 length
               return (MkQueryVersionReply major_version minor_version)
 
data Create = MkCreate{damage_Create :: DAMAGE,
                       drawable_Create :: DRAWABLE, level_Create :: ReportLevel}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Create where
        extensionId _ = "DAMAGE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (damage_Create x) + size (drawable_Create x) +
                         size (undefined :: Word8)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (damage_Create x)
               serialize (drawable_Create x)
               serialize (toValue (level_Create x) :: Word8)
               putSkip 3
               putSkip (requiredPadding size__)
 
data Destroy = MkDestroy{damage_Destroy :: DAMAGE}
             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Destroy where
        extensionId _ = "DAMAGE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4 + size (damage_Destroy x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (damage_Destroy x)
               putSkip (requiredPadding size__)
 
data Subtract = MkSubtract{damage_Subtract :: DAMAGE,
                           repair_Subtract :: REGION, parts_Subtract :: REGION}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Subtract where
        extensionId _ = "DAMAGE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (damage_Subtract x) + size (repair_Subtract x) +
                         size (parts_Subtract x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (damage_Subtract x)
               serialize (repair_Subtract x)
               serialize (parts_Subtract x)
               putSkip (requiredPadding size__)
 
data Add = MkAdd{drawable_Add :: DRAWABLE, region_Add :: REGION}
         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Add where
        extensionId _ = "DAMAGE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4 + size (drawable_Add x) + size (region_Add x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_Add x)
               serialize (region_Add x)
               putSkip (requiredPadding size__)
 
data NotifyEvent = MkNotifyEvent{level_NotifyEvent :: ReportLevel,
                                 drawable_NotifyEvent :: DRAWABLE, damage_NotifyEvent :: DAMAGE,
                                 timestamp_NotifyEvent :: TIMESTAMP, area_NotifyEvent :: RECTANGLE,
                                 geometry_NotifyEvent :: RECTANGLE}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event NotifyEvent
 
instance Deserialize NotifyEvent where
        deserialize
          = do skip 1
               level <- liftM fromValue (deserialize :: Get Word8)
               skip 2
               drawable <- deserialize
               damage <- deserialize
               timestamp <- deserialize
               area <- deserialize
               geometry <- deserialize
               return
                 (MkNotifyEvent level drawable damage timestamp area geometry)