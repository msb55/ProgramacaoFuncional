module Graphics.XHB.Gen.Composite.Types
       (deserializeError, deserializeEvent, Redirect(..),
        QueryVersion(..), QueryVersionReply(..), RedirectWindow(..),
        RedirectSubwindows(..), UnredirectWindow(..),
        UnredirectSubwindows(..), CreateRegionFromBorderClip(..),
        NameWindowPixmap(..), GetOverlayWindow(..),
        GetOverlayWindowReply(..), ReleaseOverlayWindow(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
import Graphics.XHB.Gen.XFixes.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.XFixes.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data Redirect = RedirectAutomatic
              | RedirectManual
              deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Redirect where
        toValue RedirectAutomatic{} = 0
        toValue RedirectManual{} = 1
        fromValue 0 = RedirectAutomatic
        fromValue 1 = RedirectManual
 
data QueryVersion = MkQueryVersion{client_major_version_QueryVersion
                                   :: Word32,
                                   client_minor_version_QueryVersion :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_version_QueryVersion x) +
                         size (client_minor_version_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_version_QueryVersion x)
               serialize (client_minor_version_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_version_QueryVersionReply
                                             :: Word32,
                                             minor_version_QueryVersionReply :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               skip 16
               let _ = isCard32 length
               return (MkQueryVersionReply major_version minor_version)
 
data RedirectWindow = MkRedirectWindow{window_RedirectWindow ::
                                       WINDOW,
                                       update_RedirectWindow :: Redirect}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest RedirectWindow where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (window_RedirectWindow x) + size (undefined :: Word8) +
                         3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_RedirectWindow x)
               serialize (toValue (update_RedirectWindow x) :: Word8)
               putSkip 3
               putSkip (requiredPadding size__)
 
data RedirectSubwindows = MkRedirectSubwindows{window_RedirectSubwindows
                                               :: WINDOW,
                                               update_RedirectSubwindows :: Redirect}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest RedirectSubwindows where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (window_RedirectSubwindows x) +
                         size (undefined :: Word8)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_RedirectSubwindows x)
               serialize (toValue (update_RedirectSubwindows x) :: Word8)
               putSkip 3
               putSkip (requiredPadding size__)
 
data UnredirectWindow = MkUnredirectWindow{window_UnredirectWindow
                                           :: WINDOW,
                                           update_UnredirectWindow :: Redirect}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest UnredirectWindow where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (window_UnredirectWindow x) + size (undefined :: Word8)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_UnredirectWindow x)
               serialize (toValue (update_UnredirectWindow x) :: Word8)
               putSkip 3
               putSkip (requiredPadding size__)
 
data UnredirectSubwindows = MkUnredirectSubwindows{window_UnredirectSubwindows
                                                   :: WINDOW,
                                                   update_UnredirectSubwindows :: Redirect}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest UnredirectSubwindows where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__
                     = 4 + size (window_UnredirectSubwindows x) +
                         size (undefined :: Word8)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_UnredirectSubwindows x)
               serialize (toValue (update_UnredirectSubwindows x) :: Word8)
               putSkip 3
               putSkip (requiredPadding size__)
 
data CreateRegionFromBorderClip = MkCreateRegionFromBorderClip{region_CreateRegionFromBorderClip
                                                               :: REGION,
                                                               window_CreateRegionFromBorderClip ::
                                                               WINDOW}
                                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateRegionFromBorderClip where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (region_CreateRegionFromBorderClip x) +
                         size (window_CreateRegionFromBorderClip x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_CreateRegionFromBorderClip x)
               serialize (window_CreateRegionFromBorderClip x)
               putSkip (requiredPadding size__)
 
data NameWindowPixmap = MkNameWindowPixmap{window_NameWindowPixmap
                                           :: WINDOW,
                                           pixmap_NameWindowPixmap :: PIXMAP}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest NameWindowPixmap where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__
                     = 4 + size (window_NameWindowPixmap x) +
                         size (pixmap_NameWindowPixmap x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_NameWindowPixmap x)
               serialize (pixmap_NameWindowPixmap x)
               putSkip (requiredPadding size__)
 
data GetOverlayWindow = MkGetOverlayWindow{window_GetOverlayWindow
                                           :: WINDOW}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetOverlayWindow where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4 + size (window_GetOverlayWindow x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetOverlayWindow x)
               putSkip (requiredPadding size__)
 
data GetOverlayWindowReply = MkGetOverlayWindowReply{overlay_win_GetOverlayWindowReply
                                                     :: WINDOW}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetOverlayWindowReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               overlay_win <- deserialize
               skip 20
               let _ = isCard32 length
               return (MkGetOverlayWindowReply overlay_win)
 
data ReleaseOverlayWindow = MkReleaseOverlayWindow{window_ReleaseOverlayWindow
                                                   :: WINDOW}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ReleaseOverlayWindow where
        extensionId _ = "Composite"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__ = 4 + size (window_ReleaseOverlayWindow x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_ReleaseOverlayWindow x)
               putSkip (requiredPadding size__)