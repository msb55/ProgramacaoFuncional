module Graphics.XHB.Gen.DPMS.Types
       (deserializeError, deserializeEvent, GetVersion(..),
        GetVersionReply(..), Capable(..), CapableReply(..),
        GetTimeouts(..), GetTimeoutsReply(..), SetTimeouts(..), Enable(..),
        Disable(..), DPMSMode(..), ForceLevel(..), Info(..), InfoReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data GetVersion = MkGetVersion{client_major_version_GetVersion ::
                               Word16,
                               client_minor_version_GetVersion :: Word16}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetVersion where
        extensionId _ = "DPMS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_version_GetVersion x) +
                         size (client_minor_version_GetVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_version_GetVersion x)
               serialize (client_minor_version_GetVersion x)
               putSkip (requiredPadding size__)
 
data GetVersionReply = MkGetVersionReply{server_major_version_GetVersionReply
                                         :: Word16,
                                         server_minor_version_GetVersionReply :: Word16}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               server_major_version <- deserialize
               server_minor_version <- deserialize
               let _ = isCard32 length
               return
                 (MkGetVersionReply server_major_version server_minor_version)
 
data Capable = MkCapable{}
             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Capable where
        extensionId _ = "DPMS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data CapableReply = MkCapableReply{capable_CapableReply :: Bool}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize CapableReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               capable <- deserialize
               skip 23
               let _ = isCard32 length
               return (MkCapableReply capable)
 
data GetTimeouts = MkGetTimeouts{}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetTimeouts where
        extensionId _ = "DPMS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetTimeoutsReply = MkGetTimeoutsReply{standby_timeout_GetTimeoutsReply
                                           :: Word16,
                                           suspend_timeout_GetTimeoutsReply :: Word16,
                                           off_timeout_GetTimeoutsReply :: Word16}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetTimeoutsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               standby_timeout <- deserialize
               suspend_timeout <- deserialize
               off_timeout <- deserialize
               skip 18
               let _ = isCard32 length
               return
                 (MkGetTimeoutsReply standby_timeout suspend_timeout off_timeout)
 
data SetTimeouts = MkSetTimeouts{standby_timeout_SetTimeouts ::
                                 Word16,
                                 suspend_timeout_SetTimeouts :: Word16,
                                 off_timeout_SetTimeouts :: Word16}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetTimeouts where
        extensionId _ = "DPMS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (standby_timeout_SetTimeouts x) +
                         size (suspend_timeout_SetTimeouts x)
                         + size (off_timeout_SetTimeouts x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (standby_timeout_SetTimeouts x)
               serialize (suspend_timeout_SetTimeouts x)
               serialize (off_timeout_SetTimeouts x)
               putSkip (requiredPadding size__)
 
data Enable = MkEnable{}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Enable where
        extensionId _ = "DPMS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data Disable = MkDisable{}
             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Disable where
        extensionId _ = "DPMS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data DPMSMode = DPMSModeOn
              | DPMSModeStandby
              | DPMSModeSuspend
              | DPMSModeOff
              deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum DPMSMode where
        toValue DPMSModeOn{} = 0
        toValue DPMSModeStandby{} = 1
        toValue DPMSModeSuspend{} = 2
        toValue DPMSModeOff{} = 3
        fromValue 0 = DPMSModeOn
        fromValue 1 = DPMSModeStandby
        fromValue 2 = DPMSModeSuspend
        fromValue 3 = DPMSModeOff
 
data ForceLevel = MkForceLevel{power_level_ForceLevel :: DPMSMode}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ForceLevel where
        extensionId _ = "DPMS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__ = 4 + size (undefined :: Word16)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (power_level_ForceLevel x) :: Word16)
               putSkip (requiredPadding size__)
 
data Info = MkInfo{}
          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Info where
        extensionId _ = "DPMS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data InfoReply = MkInfoReply{power_level_InfoReply :: DPMSMode,
                             state_InfoReply :: Bool}
               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize InfoReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               power_level <- liftM fromValue (deserialize :: Get Word16)
               state <- deserialize
               skip 21
               let _ = isCard32 length
               return (MkInfoReply power_level state)