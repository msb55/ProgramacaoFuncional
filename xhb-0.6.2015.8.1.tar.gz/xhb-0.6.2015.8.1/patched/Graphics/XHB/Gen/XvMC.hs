module Graphics.XHB.Gen.XvMC
       (extension, queryVersion, listSurfaceTypes, createContext,
        destroyContext, createSurface, destroySurface, createSubpicture,
        destroySubpicture, listSubpictureTypes,
        module Graphics.XHB.Gen.XvMC.Types)
       where
import Graphics.XHB.Gen.XvMC.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xv.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xv.Types
 
extension :: ExtensionId
extension = "XVideo-MotionCompensation"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 IO (Receipt QueryVersionReply)
queryVersion c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
listSurfaceTypes ::
                   Graphics.XHB.Connection.Types.Connection ->
                     PORT -> IO (Receipt ListSurfaceTypesReply)
listSurfaceTypes c port_id
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkListSurfaceTypes port_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createContext ::
                Graphics.XHB.Connection.Types.Connection ->
                  CreateContext -> IO (Receipt CreateContextReply)
createContext c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
destroyContext ::
                 Graphics.XHB.Connection.Types.Connection -> CONTEXT -> IO ()
destroyContext c context_id
  = do let req = MkDestroyContext context_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createSurface ::
                Graphics.XHB.Connection.Types.Connection ->
                  SURFACE -> CONTEXT -> IO (Receipt [Word32])
createSurface c surface_id context_id
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (priv_data_CreateSurfaceReply `fmap` deserialize))
       let req = MkCreateSurface surface_id context_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
destroySurface ::
                 Graphics.XHB.Connection.Types.Connection -> SURFACE -> IO ()
destroySurface c surface_id
  = do let req = MkDestroySurface surface_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createSubpicture ::
                   Graphics.XHB.Connection.Types.Connection ->
                     CreateSubpicture -> IO (Receipt CreateSubpictureReply)
createSubpicture c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
destroySubpicture ::
                    Graphics.XHB.Connection.Types.Connection -> SUBPICTURE -> IO ()
destroySubpicture c subpicture_id
  = do let req = MkDestroySubpicture subpicture_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
listSubpictureTypes ::
                      Graphics.XHB.Connection.Types.Connection ->
                        PORT -> SURFACE -> IO (Receipt ListSubpictureTypesReply)
listSubpictureTypes c port_id surface_id
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkListSubpictureTypes port_id surface_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt