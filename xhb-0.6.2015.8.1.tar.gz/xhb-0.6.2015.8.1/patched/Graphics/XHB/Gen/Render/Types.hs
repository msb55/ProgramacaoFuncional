module Graphics.XHB.Gen.Render.Types
       (deserializeError, deserializeEvent, PictType(..), Picture(..),
        PictOp(..), PolyEdge(..), PolyMode(..), CP(..), SubPixel(..),
        Repeat(..), GLYPH, GLYPHSET, PICTURE, PICTFORMAT, FIXED,
        DIRECTFORMAT(..), PICTFORMINFO(..), PICTVISUAL(..), PICTDEPTH(..),
        PICTSCREEN(..), INDEXVALUE(..), COLOR(..), POINTFIX(..),
        LINEFIX(..), TRIANGLE(..), TRAPEZOID(..), GLYPHINFO(..),
        QueryVersion(..), QueryVersionReply(..), QueryPictFormats(..),
        QueryPictFormatsReply(..), QueryPictIndexValues(..),
        QueryPictIndexValuesReply(..), CreatePicture(..),
        ChangePicture(..), SetPictureClipRectangles(..), FreePicture(..),
        Composite(..), Trapezoids(..), Triangles(..), TriStrip(..),
        TriFan(..), CreateGlyphSet(..), ReferenceGlyphSet(..),
        FreeGlyphSet(..), AddGlyphs(..), FreeGlyphs(..),
        CompositeGlyphs8(..), CompositeGlyphs16(..), CompositeGlyphs32(..),
        FillRectangles(..), CreateCursor(..), TRANSFORM(..),
        SetPictureTransform(..), QueryFilters(..), QueryFiltersReply(..),
        SetPictureFilter(..), ANIMCURSORELT(..), CreateAnimCursor(..),
        SPANFIX(..), TRAP(..), AddTraps(..), CreateSolidFill(..),
        CreateLinearGradient(..), CreateRadialGradient(..),
        CreateConicalGradient(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (CreateCursor(..), deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data PictType = PictTypeIndexed
              | PictTypeDirect
              deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum PictType where
        toValue PictTypeIndexed{} = 0
        toValue PictTypeDirect{} = 1
        fromValue 0 = PictTypeIndexed
        fromValue 1 = PictTypeDirect
 
data Picture = PictureNone
             deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Picture where
        toValue PictureNone{} = 0
        fromValue 0 = PictureNone
 
data PictOp = PictOpClear
            | PictOpSrc
            | PictOpDst
            | PictOpOver
            | PictOpOverReverse
            | PictOpIn
            | PictOpInReverse
            | PictOpOut
            | PictOpOutReverse
            | PictOpAtop
            | PictOpAtopReverse
            | PictOpXor
            | PictOpAdd
            | PictOpSaturate
            | PictOpDisjointClear
            | PictOpDisjointSrc
            | PictOpDisjointDst
            | PictOpDisjointOver
            | PictOpDisjointOverReverse
            | PictOpDisjointIn
            | PictOpDisjointInReverse
            | PictOpDisjointOut
            | PictOpDisjointOutReverse
            | PictOpDisjointAtop
            | PictOpDisjointAtopReverse
            | PictOpDisjointXor
            | PictOpConjointClear
            | PictOpConjointSrc
            | PictOpConjointDst
            | PictOpConjointOver
            | PictOpConjointOverReverse
            | PictOpConjointIn
            | PictOpConjointInReverse
            | PictOpConjointOut
            | PictOpConjointOutReverse
            | PictOpConjointAtop
            | PictOpConjointAtopReverse
            | PictOpConjointXor
            deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum PictOp where
        toValue PictOpClear{} = 0
        toValue PictOpSrc{} = 1
        toValue PictOpDst{} = 2
        toValue PictOpOver{} = 3
        toValue PictOpOverReverse{} = 4
        toValue PictOpIn{} = 5
        toValue PictOpInReverse{} = 6
        toValue PictOpOut{} = 7
        toValue PictOpOutReverse{} = 8
        toValue PictOpAtop{} = 9
        toValue PictOpAtopReverse{} = 10
        toValue PictOpXor{} = 11
        toValue PictOpAdd{} = 12
        toValue PictOpSaturate{} = 13
        toValue PictOpDisjointClear{} = 16
        toValue PictOpDisjointSrc{} = 17
        toValue PictOpDisjointDst{} = 18
        toValue PictOpDisjointOver{} = 19
        toValue PictOpDisjointOverReverse{} = 20
        toValue PictOpDisjointIn{} = 21
        toValue PictOpDisjointInReverse{} = 22
        toValue PictOpDisjointOut{} = 23
        toValue PictOpDisjointOutReverse{} = 24
        toValue PictOpDisjointAtop{} = 25
        toValue PictOpDisjointAtopReverse{} = 26
        toValue PictOpDisjointXor{} = 27
        toValue PictOpConjointClear{} = 32
        toValue PictOpConjointSrc{} = 33
        toValue PictOpConjointDst{} = 34
        toValue PictOpConjointOver{} = 35
        toValue PictOpConjointOverReverse{} = 36
        toValue PictOpConjointIn{} = 37
        toValue PictOpConjointInReverse{} = 38
        toValue PictOpConjointOut{} = 39
        toValue PictOpConjointOutReverse{} = 40
        toValue PictOpConjointAtop{} = 41
        toValue PictOpConjointAtopReverse{} = 42
        toValue PictOpConjointXor{} = 43
        fromValue 0 = PictOpClear
        fromValue 1 = PictOpSrc
        fromValue 2 = PictOpDst
        fromValue 3 = PictOpOver
        fromValue 4 = PictOpOverReverse
        fromValue 5 = PictOpIn
        fromValue 6 = PictOpInReverse
        fromValue 7 = PictOpOut
        fromValue 8 = PictOpOutReverse
        fromValue 9 = PictOpAtop
        fromValue 10 = PictOpAtopReverse
        fromValue 11 = PictOpXor
        fromValue 12 = PictOpAdd
        fromValue 13 = PictOpSaturate
        fromValue 16 = PictOpDisjointClear
        fromValue 17 = PictOpDisjointSrc
        fromValue 18 = PictOpDisjointDst
        fromValue 19 = PictOpDisjointOver
        fromValue 20 = PictOpDisjointOverReverse
        fromValue 21 = PictOpDisjointIn
        fromValue 22 = PictOpDisjointInReverse
        fromValue 23 = PictOpDisjointOut
        fromValue 24 = PictOpDisjointOutReverse
        fromValue 25 = PictOpDisjointAtop
        fromValue 26 = PictOpDisjointAtopReverse
        fromValue 27 = PictOpDisjointXor
        fromValue 32 = PictOpConjointClear
        fromValue 33 = PictOpConjointSrc
        fromValue 34 = PictOpConjointDst
        fromValue 35 = PictOpConjointOver
        fromValue 36 = PictOpConjointOverReverse
        fromValue 37 = PictOpConjointIn
        fromValue 38 = PictOpConjointInReverse
        fromValue 39 = PictOpConjointOut
        fromValue 40 = PictOpConjointOutReverse
        fromValue 41 = PictOpConjointAtop
        fromValue 42 = PictOpConjointAtopReverse
        fromValue 43 = PictOpConjointXor
 
data PolyEdge = PolyEdgeSharp
              | PolyEdgeSmooth
              deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum PolyEdge where
        toValue PolyEdgeSharp{} = 0
        toValue PolyEdgeSmooth{} = 1
        fromValue 0 = PolyEdgeSharp
        fromValue 1 = PolyEdgeSmooth
 
data PolyMode = PolyModePrecise
              | PolyModeImprecise
              deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum PolyMode where
        toValue PolyModePrecise{} = 0
        toValue PolyModeImprecise{} = 1
        fromValue 0 = PolyModePrecise
        fromValue 1 = PolyModeImprecise
 
data CP = CPRepeat
        | CPAlphaMap
        | CPAlphaXOrigin
        | CPAlphaYOrigin
        | CPClipXOrigin
        | CPClipYOrigin
        | CPClipMask
        | CPGraphicsExposure
        | CPSubwindowMode
        | CPPolyEdge
        | CPPolyMode
        | CPDither
        | CPComponentAlpha
        deriving (Show, Eq, Ord, Enum, Typeable)
 
instance BitEnum CP where
        toBit CPRepeat{} = 0
        toBit CPAlphaMap{} = 1
        toBit CPAlphaXOrigin{} = 2
        toBit CPAlphaYOrigin{} = 3
        toBit CPClipXOrigin{} = 4
        toBit CPClipYOrigin{} = 5
        toBit CPClipMask{} = 6
        toBit CPGraphicsExposure{} = 7
        toBit CPSubwindowMode{} = 8
        toBit CPPolyEdge{} = 9
        toBit CPPolyMode{} = 10
        toBit CPDither{} = 11
        toBit CPComponentAlpha{} = 12
        fromBit 0 = CPRepeat
        fromBit 1 = CPAlphaMap
        fromBit 2 = CPAlphaXOrigin
        fromBit 3 = CPAlphaYOrigin
        fromBit 4 = CPClipXOrigin
        fromBit 5 = CPClipYOrigin
        fromBit 6 = CPClipMask
        fromBit 7 = CPGraphicsExposure
        fromBit 8 = CPSubwindowMode
        fromBit 9 = CPPolyEdge
        fromBit 10 = CPPolyMode
        fromBit 11 = CPDither
        fromBit 12 = CPComponentAlpha
 
data SubPixel = SubPixelUnknown
              | SubPixelHorizontalRGB
              | SubPixelHorizontalBGR
              | SubPixelVerticalRGB
              | SubPixelVerticalBGR
              | SubPixelNone
              deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum SubPixel where
        toValue SubPixelUnknown{} = 0
        toValue SubPixelHorizontalRGB{} = 1
        toValue SubPixelHorizontalBGR{} = 2
        toValue SubPixelVerticalRGB{} = 3
        toValue SubPixelVerticalBGR{} = 4
        toValue SubPixelNone{} = 5
        fromValue 0 = SubPixelUnknown
        fromValue 1 = SubPixelHorizontalRGB
        fromValue 2 = SubPixelHorizontalBGR
        fromValue 3 = SubPixelVerticalRGB
        fromValue 4 = SubPixelVerticalBGR
        fromValue 5 = SubPixelNone
 
data Repeat = RepeatNone
            | RepeatNormal
            | RepeatPad
            | RepeatReflect
            deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Repeat where
        toValue RepeatNone{} = 0
        toValue RepeatNormal{} = 1
        toValue RepeatPad{} = 2
        toValue RepeatReflect{} = 3
        fromValue 0 = RepeatNone
        fromValue 1 = RepeatNormal
        fromValue 2 = RepeatPad
        fromValue 3 = RepeatReflect
 
type GLYPH = Word32
 
newtype GLYPHSET = MkGLYPHSET Xid
                   deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype PICTURE = MkPICTURE Xid
                  deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
newtype PICTFORMAT = MkPICTFORMAT Xid
                     deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
type FIXED = Int32
 
data DIRECTFORMAT = MkDIRECTFORMAT{red_shift_DIRECTFORMAT ::
                                   Word16,
                                   red_mask_DIRECTFORMAT :: Word16,
                                   green_shift_DIRECTFORMAT :: Word16,
                                   green_mask_DIRECTFORMAT :: Word16,
                                   blue_shift_DIRECTFORMAT :: Word16,
                                   blue_mask_DIRECTFORMAT :: Word16,
                                   alpha_shift_DIRECTFORMAT :: Word16,
                                   alpha_mask_DIRECTFORMAT :: Word16}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DIRECTFORMAT where
        serialize x
          = do serialize (red_shift_DIRECTFORMAT x)
               serialize (red_mask_DIRECTFORMAT x)
               serialize (green_shift_DIRECTFORMAT x)
               serialize (green_mask_DIRECTFORMAT x)
               serialize (blue_shift_DIRECTFORMAT x)
               serialize (blue_mask_DIRECTFORMAT x)
               serialize (alpha_shift_DIRECTFORMAT x)
               serialize (alpha_mask_DIRECTFORMAT x)
        size x
          = size (red_shift_DIRECTFORMAT x) + size (red_mask_DIRECTFORMAT x)
              + size (green_shift_DIRECTFORMAT x)
              + size (green_mask_DIRECTFORMAT x)
              + size (blue_shift_DIRECTFORMAT x)
              + size (blue_mask_DIRECTFORMAT x)
              + size (alpha_shift_DIRECTFORMAT x)
              + size (alpha_mask_DIRECTFORMAT x)
 
instance Deserialize DIRECTFORMAT where
        deserialize
          = do red_shift <- deserialize
               red_mask <- deserialize
               green_shift <- deserialize
               green_mask <- deserialize
               blue_shift <- deserialize
               blue_mask <- deserialize
               alpha_shift <- deserialize
               alpha_mask <- deserialize
               return
                 (MkDIRECTFORMAT red_shift red_mask green_shift green_mask
                    blue_shift
                    blue_mask
                    alpha_shift
                    alpha_mask)
 
data PICTFORMINFO = MkPICTFORMINFO{id_PICTFORMINFO :: PICTFORMAT,
                                   type_PICTFORMINFO :: PictType, depth_PICTFORMINFO :: Word8,
                                   direct_PICTFORMINFO :: DIRECTFORMAT,
                                   colormap_PICTFORMINFO :: COLORMAP}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Serialize PICTFORMINFO where
        serialize x
          = do serialize (id_PICTFORMINFO x)
               serialize (toValue (type_PICTFORMINFO x) :: Word8)
               serialize (depth_PICTFORMINFO x)
               putSkip 2
               serialize (direct_PICTFORMINFO x)
               serialize (colormap_PICTFORMINFO x)
        size x
          = size (id_PICTFORMINFO x) + size (undefined :: Word8) +
              size (depth_PICTFORMINFO x)
              + 2
              + size (direct_PICTFORMINFO x)
              + size (colormap_PICTFORMINFO x)
 
instance Deserialize PICTFORMINFO where
        deserialize
          = do id <- deserialize
               type_ <- liftM fromValue (deserialize :: Get Word8)
               depth <- deserialize
               skip 2
               direct <- deserialize
               colormap <- deserialize
               return (MkPICTFORMINFO id type_ depth direct colormap)
 
data PICTVISUAL = MkPICTVISUAL{visual_PICTVISUAL :: VISUALID,
                               format_PICTVISUAL :: PICTFORMAT}
                deriving (Show, Typeable, Eq, Ord)
 
instance Serialize PICTVISUAL where
        serialize x
          = do serialize (visual_PICTVISUAL x)
               serialize (format_PICTVISUAL x)
        size x = size (visual_PICTVISUAL x) + size (format_PICTVISUAL x)
 
instance Deserialize PICTVISUAL where
        deserialize
          = do visual <- deserialize
               format <- deserialize
               return (MkPICTVISUAL visual format)
 
data PICTDEPTH = MkPICTDEPTH{depth_PICTDEPTH :: Word8,
                             num_visuals_PICTDEPTH :: Word16, visuals_PICTDEPTH :: [PICTVISUAL]}
               deriving (Show, Typeable, Eq, Ord)
 
instance Serialize PICTDEPTH where
        serialize x
          = do serialize (depth_PICTDEPTH x)
               putSkip 1
               serialize (num_visuals_PICTDEPTH x)
               putSkip 4
               serializeList (visuals_PICTDEPTH x)
        size x
          = size (depth_PICTDEPTH x) + 1 + size (num_visuals_PICTDEPTH x) + 4
              + sum (map size (visuals_PICTDEPTH x))
 
instance Deserialize PICTDEPTH where
        deserialize
          = do depth <- deserialize
               skip 1
               num_visuals <- deserialize
               skip 4
               visuals <- deserializeList (fromIntegral num_visuals)
               return (MkPICTDEPTH depth num_visuals visuals)
 
data PICTSCREEN = MkPICTSCREEN{num_depths_PICTSCREEN :: Word32,
                               fallback_PICTSCREEN :: PICTFORMAT,
                               depths_PICTSCREEN :: [PICTDEPTH]}
                deriving (Show, Typeable, Eq, Ord)
 
instance Serialize PICTSCREEN where
        serialize x
          = do serialize (num_depths_PICTSCREEN x)
               serialize (fallback_PICTSCREEN x)
               serializeList (depths_PICTSCREEN x)
        size x
          = size (num_depths_PICTSCREEN x) + size (fallback_PICTSCREEN x) +
              sum (map size (depths_PICTSCREEN x))
 
instance Deserialize PICTSCREEN where
        deserialize
          = do num_depths <- deserialize
               fallback <- deserialize
               depths <- deserializeList (fromIntegral num_depths)
               return (MkPICTSCREEN num_depths fallback depths)
 
data INDEXVALUE = MkINDEXVALUE{pixel_INDEXVALUE :: Word32,
                               red_INDEXVALUE :: Word16, green_INDEXVALUE :: Word16,
                               blue_INDEXVALUE :: Word16, alpha_INDEXVALUE :: Word16}
                deriving (Show, Typeable, Eq, Ord)
 
instance Serialize INDEXVALUE where
        serialize x
          = do serialize (pixel_INDEXVALUE x)
               serialize (red_INDEXVALUE x)
               serialize (green_INDEXVALUE x)
               serialize (blue_INDEXVALUE x)
               serialize (alpha_INDEXVALUE x)
        size x
          = size (pixel_INDEXVALUE x) + size (red_INDEXVALUE x) +
              size (green_INDEXVALUE x)
              + size (blue_INDEXVALUE x)
              + size (alpha_INDEXVALUE x)
 
instance Deserialize INDEXVALUE where
        deserialize
          = do pixel <- deserialize
               red <- deserialize
               green <- deserialize
               blue <- deserialize
               alpha <- deserialize
               return (MkINDEXVALUE pixel red green blue alpha)
 
data COLOR = MkCOLOR{red_COLOR :: Word16, green_COLOR :: Word16,
                     blue_COLOR :: Word16, alpha_COLOR :: Word16}
           deriving (Show, Typeable, Eq, Ord)
 
instance Serialize COLOR where
        serialize x
          = do serialize (red_COLOR x)
               serialize (green_COLOR x)
               serialize (blue_COLOR x)
               serialize (alpha_COLOR x)
        size x
          = size (red_COLOR x) + size (green_COLOR x) + size (blue_COLOR x) +
              size (alpha_COLOR x)
 
instance Deserialize COLOR where
        deserialize
          = do red <- deserialize
               green <- deserialize
               blue <- deserialize
               alpha <- deserialize
               return (MkCOLOR red green blue alpha)
 
data POINTFIX = MkPOINTFIX{x_POINTFIX :: FIXED,
                           y_POINTFIX :: FIXED}
              deriving (Show, Typeable, Eq, Ord)
 
instance Serialize POINTFIX where
        serialize x
          = do serialize (x_POINTFIX x)
               serialize (y_POINTFIX x)
        size x = size (x_POINTFIX x) + size (y_POINTFIX x)
 
instance Deserialize POINTFIX where
        deserialize
          = do x <- deserialize
               y <- deserialize
               return (MkPOINTFIX x y)
 
data LINEFIX = MkLINEFIX{p1_LINEFIX :: POINTFIX,
                         p2_LINEFIX :: POINTFIX}
             deriving (Show, Typeable, Eq, Ord)
 
instance Serialize LINEFIX where
        serialize x
          = do serialize (p1_LINEFIX x)
               serialize (p2_LINEFIX x)
        size x = size (p1_LINEFIX x) + size (p2_LINEFIX x)
 
instance Deserialize LINEFIX where
        deserialize
          = do p1 <- deserialize
               p2 <- deserialize
               return (MkLINEFIX p1 p2)
 
data TRIANGLE = MkTRIANGLE{p1_TRIANGLE :: POINTFIX,
                           p2_TRIANGLE :: POINTFIX, p3_TRIANGLE :: POINTFIX}
              deriving (Show, Typeable, Eq, Ord)
 
instance Serialize TRIANGLE where
        serialize x
          = do serialize (p1_TRIANGLE x)
               serialize (p2_TRIANGLE x)
               serialize (p3_TRIANGLE x)
        size x
          = size (p1_TRIANGLE x) + size (p2_TRIANGLE x) +
              size (p3_TRIANGLE x)
 
instance Deserialize TRIANGLE where
        deserialize
          = do p1 <- deserialize
               p2 <- deserialize
               p3 <- deserialize
               return (MkTRIANGLE p1 p2 p3)
 
data TRAPEZOID = MkTRAPEZOID{top_TRAPEZOID :: FIXED,
                             bottom_TRAPEZOID :: FIXED, left_TRAPEZOID :: LINEFIX,
                             right_TRAPEZOID :: LINEFIX}
               deriving (Show, Typeable, Eq, Ord)
 
instance Serialize TRAPEZOID where
        serialize x
          = do serialize (top_TRAPEZOID x)
               serialize (bottom_TRAPEZOID x)
               serialize (left_TRAPEZOID x)
               serialize (right_TRAPEZOID x)
        size x
          = size (top_TRAPEZOID x) + size (bottom_TRAPEZOID x) +
              size (left_TRAPEZOID x)
              + size (right_TRAPEZOID x)
 
instance Deserialize TRAPEZOID where
        deserialize
          = do top <- deserialize
               bottom <- deserialize
               left <- deserialize
               right <- deserialize
               return (MkTRAPEZOID top bottom left right)
 
data GLYPHINFO = MkGLYPHINFO{width_GLYPHINFO :: Word16,
                             height_GLYPHINFO :: Word16, x_GLYPHINFO :: Int16,
                             y_GLYPHINFO :: Int16, x_off_GLYPHINFO :: Int16,
                             y_off_GLYPHINFO :: Int16}
               deriving (Show, Typeable, Eq, Ord)
 
instance Serialize GLYPHINFO where
        serialize x
          = do serialize (width_GLYPHINFO x)
               serialize (height_GLYPHINFO x)
               serialize (x_GLYPHINFO x)
               serialize (y_GLYPHINFO x)
               serialize (x_off_GLYPHINFO x)
               serialize (y_off_GLYPHINFO x)
        size x
          = size (width_GLYPHINFO x) + size (height_GLYPHINFO x) +
              size (x_GLYPHINFO x)
              + size (y_GLYPHINFO x)
              + size (x_off_GLYPHINFO x)
              + size (y_off_GLYPHINFO x)
 
instance Deserialize GLYPHINFO where
        deserialize
          = do width <- deserialize
               height <- deserialize
               x <- deserialize
               y <- deserialize
               x_off <- deserialize
               y_off <- deserialize
               return (MkGLYPHINFO width height x y x_off y_off)
 
data QueryVersion = MkQueryVersion{client_major_version_QueryVersion
                                   :: Word32,
                                   client_minor_version_QueryVersion :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_version_QueryVersion x) +
                         size (client_minor_version_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_version_QueryVersion x)
               serialize (client_minor_version_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_version_QueryVersionReply
                                             :: Word32,
                                             minor_version_QueryVersionReply :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               skip 16
               let _ = isCard32 length
               return (MkQueryVersionReply major_version minor_version)
 
data QueryPictFormats = MkQueryPictFormats{}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryPictFormats where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data QueryPictFormatsReply = MkQueryPictFormatsReply{num_formats_QueryPictFormatsReply
                                                     :: Word32,
                                                     num_screens_QueryPictFormatsReply :: Word32,
                                                     num_depths_QueryPictFormatsReply :: Word32,
                                                     num_visuals_QueryPictFormatsReply :: Word32,
                                                     num_subpixel_QueryPictFormatsReply :: Word32,
                                                     formats_QueryPictFormatsReply ::
                                                     [PICTFORMINFO],
                                                     screens_QueryPictFormatsReply :: [PICTSCREEN],
                                                     subpixels_QueryPictFormatsReply :: [SubPixel]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryPictFormatsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_formats <- deserialize
               num_screens <- deserialize
               num_depths <- deserialize
               num_visuals <- deserialize
               num_subpixel <- deserialize
               skip 4
               formats <- deserializeList (fromIntegral num_formats)
               screens <- deserializeList (fromIntegral num_screens)
               subpixels <- liftM (liftM fromValue)
                              (deserializeList (fromIntegral num_subpixel) :: Get [Word32])
               let _ = isCard32 length
               return
                 (MkQueryPictFormatsReply num_formats num_screens num_depths
                    num_visuals
                    num_subpixel
                    formats
                    screens
                    subpixels)
 
data QueryPictIndexValues = MkQueryPictIndexValues{format_QueryPictIndexValues
                                                   :: PICTFORMAT}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryPictIndexValues where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4 + size (format_QueryPictIndexValues x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (format_QueryPictIndexValues x)
               putSkip (requiredPadding size__)
 
data QueryPictIndexValuesReply = MkQueryPictIndexValuesReply{num_values_QueryPictIndexValuesReply
                                                             :: Word32,
                                                             values_QueryPictIndexValuesReply ::
                                                             [INDEXVALUE]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryPictIndexValuesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_values <- deserialize
               skip 20
               values <- deserializeList (fromIntegral num_values)
               let _ = isCard32 length
               return (MkQueryPictIndexValuesReply num_values values)
 
data CreatePicture = MkCreatePicture{pid_CreatePicture :: PICTURE,
                                     drawable_CreatePicture :: DRAWABLE,
                                     format_CreatePicture :: PICTFORMAT,
                                     value_CreatePicture :: ValueParam Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreatePicture where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__
                     = 4 + size (pid_CreatePicture x) + size (drawable_CreatePicture x)
                         + size (format_CreatePicture x)
                         + size (value_CreatePicture x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (pid_CreatePicture x)
               serialize (drawable_CreatePicture x)
               serialize (format_CreatePicture x)
               serialize (value_CreatePicture x)
               putSkip (requiredPadding size__)
 
data ChangePicture = MkChangePicture{picture_ChangePicture ::
                                     PICTURE,
                                     value_ChangePicture :: ValueParam Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangePicture where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (picture_ChangePicture x) + size (value_ChangePicture x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_ChangePicture x)
               serialize (value_ChangePicture x)
               putSkip (requiredPadding size__)
 
data SetPictureClipRectangles = MkSetPictureClipRectangles{picture_SetPictureClipRectangles
                                                           :: PICTURE,
                                                           clip_x_origin_SetPictureClipRectangles ::
                                                           Int16,
                                                           clip_y_origin_SetPictureClipRectangles ::
                                                           Int16,
                                                           rectangles_SetPictureClipRectangles ::
                                                           [RECTANGLE]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetPictureClipRectangles where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__
                     = 4 + size (picture_SetPictureClipRectangles x) +
                         size (clip_x_origin_SetPictureClipRectangles x)
                         + size (clip_y_origin_SetPictureClipRectangles x)
                         + sum (map size (rectangles_SetPictureClipRectangles x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_SetPictureClipRectangles x)
               serialize (clip_x_origin_SetPictureClipRectangles x)
               serialize (clip_y_origin_SetPictureClipRectangles x)
               serializeList (rectangles_SetPictureClipRectangles x)
               putSkip (requiredPadding size__)
 
data FreePicture = MkFreePicture{picture_FreePicture :: PICTURE}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest FreePicture where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4 + size (picture_FreePicture x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_FreePicture x)
               putSkip (requiredPadding size__)
 
data Composite = MkComposite{op_Composite :: PictOp,
                             src_Composite :: PICTURE, mask_Composite :: PICTURE,
                             dst_Composite :: PICTURE, src_x_Composite :: Int16,
                             src_y_Composite :: Int16, mask_x_Composite :: Int16,
                             mask_y_Composite :: Int16, dst_x_Composite :: Int16,
                             dst_y_Composite :: Int16, width_Composite :: Word16,
                             height_Composite :: Word16}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Composite where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__
                     = 4 + size (undefined :: Word8) + 3 + size (src_Composite x) +
                         size (mask_Composite x)
                         + size (dst_Composite x)
                         + size (src_x_Composite x)
                         + size (src_y_Composite x)
                         + size (mask_x_Composite x)
                         + size (mask_y_Composite x)
                         + size (dst_x_Composite x)
                         + size (dst_y_Composite x)
                         + size (width_Composite x)
                         + size (height_Composite x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_Composite x) :: Word8)
               putSkip 3
               serialize (src_Composite x)
               serialize (mask_Composite x)
               serialize (dst_Composite x)
               serialize (src_x_Composite x)
               serialize (src_y_Composite x)
               serialize (mask_x_Composite x)
               serialize (mask_y_Composite x)
               serialize (dst_x_Composite x)
               serialize (dst_y_Composite x)
               serialize (width_Composite x)
               serialize (height_Composite x)
               putSkip (requiredPadding size__)
 
data Trapezoids = MkTrapezoids{op_Trapezoids :: PictOp,
                               src_Trapezoids :: PICTURE, dst_Trapezoids :: PICTURE,
                               mask_format_Trapezoids :: PICTFORMAT, src_x_Trapezoids :: Int16,
                               src_y_Trapezoids :: Int16, traps_Trapezoids :: [TRAPEZOID]}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Trapezoids where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 10
               let size__
                     = 4 + size (undefined :: Word8) + 3 + size (src_Trapezoids x) +
                         size (dst_Trapezoids x)
                         + size (mask_format_Trapezoids x)
                         + size (src_x_Trapezoids x)
                         + size (src_y_Trapezoids x)
                         + sum (map size (traps_Trapezoids x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_Trapezoids x) :: Word8)
               putSkip 3
               serialize (src_Trapezoids x)
               serialize (dst_Trapezoids x)
               serialize (mask_format_Trapezoids x)
               serialize (src_x_Trapezoids x)
               serialize (src_y_Trapezoids x)
               serializeList (traps_Trapezoids x)
               putSkip (requiredPadding size__)
 
data Triangles = MkTriangles{op_Triangles :: PictOp,
                             src_Triangles :: PICTURE, dst_Triangles :: PICTURE,
                             mask_format_Triangles :: PICTFORMAT, src_x_Triangles :: Int16,
                             src_y_Triangles :: Int16, triangles_Triangles :: [TRIANGLE]}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Triangles where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 11
               let size__
                     = 4 + size (undefined :: Word8) + 3 + size (src_Triangles x) +
                         size (dst_Triangles x)
                         + size (mask_format_Triangles x)
                         + size (src_x_Triangles x)
                         + size (src_y_Triangles x)
                         + sum (map size (triangles_Triangles x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_Triangles x) :: Word8)
               putSkip 3
               serialize (src_Triangles x)
               serialize (dst_Triangles x)
               serialize (mask_format_Triangles x)
               serialize (src_x_Triangles x)
               serialize (src_y_Triangles x)
               serializeList (triangles_Triangles x)
               putSkip (requiredPadding size__)
 
data TriStrip = MkTriStrip{op_TriStrip :: PictOp,
                           src_TriStrip :: PICTURE, dst_TriStrip :: PICTURE,
                           mask_format_TriStrip :: PICTFORMAT, src_x_TriStrip :: Int16,
                           src_y_TriStrip :: Int16, points_TriStrip :: [POINTFIX]}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest TriStrip where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 12
               let size__
                     = 4 + size (undefined :: Word8) + 3 + size (src_TriStrip x) +
                         size (dst_TriStrip x)
                         + size (mask_format_TriStrip x)
                         + size (src_x_TriStrip x)
                         + size (src_y_TriStrip x)
                         + sum (map size (points_TriStrip x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_TriStrip x) :: Word8)
               putSkip 3
               serialize (src_TriStrip x)
               serialize (dst_TriStrip x)
               serialize (mask_format_TriStrip x)
               serialize (src_x_TriStrip x)
               serialize (src_y_TriStrip x)
               serializeList (points_TriStrip x)
               putSkip (requiredPadding size__)
 
data TriFan = MkTriFan{op_TriFan :: PictOp, src_TriFan :: PICTURE,
                       dst_TriFan :: PICTURE, mask_format_TriFan :: PICTFORMAT,
                       src_x_TriFan :: Int16, src_y_TriFan :: Int16,
                       points_TriFan :: [POINTFIX]}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest TriFan where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 13
               let size__
                     = 4 + size (undefined :: Word8) + 3 + size (src_TriFan x) +
                         size (dst_TriFan x)
                         + size (mask_format_TriFan x)
                         + size (src_x_TriFan x)
                         + size (src_y_TriFan x)
                         + sum (map size (points_TriFan x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_TriFan x) :: Word8)
               putSkip 3
               serialize (src_TriFan x)
               serialize (dst_TriFan x)
               serialize (mask_format_TriFan x)
               serialize (src_x_TriFan x)
               serialize (src_y_TriFan x)
               serializeList (points_TriFan x)
               putSkip (requiredPadding size__)
 
data CreateGlyphSet = MkCreateGlyphSet{gsid_CreateGlyphSet ::
                                       GLYPHSET,
                                       format_CreateGlyphSet :: PICTFORMAT}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateGlyphSet where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 17
               let size__
                     = 4 + size (gsid_CreateGlyphSet x) + size (format_CreateGlyphSet x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (gsid_CreateGlyphSet x)
               serialize (format_CreateGlyphSet x)
               putSkip (requiredPadding size__)
 
data ReferenceGlyphSet = MkReferenceGlyphSet{gsid_ReferenceGlyphSet
                                             :: GLYPHSET,
                                             existing_ReferenceGlyphSet :: GLYPHSET}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ReferenceGlyphSet where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 18
               let size__
                     = 4 + size (gsid_ReferenceGlyphSet x) +
                         size (existing_ReferenceGlyphSet x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (gsid_ReferenceGlyphSet x)
               serialize (existing_ReferenceGlyphSet x)
               putSkip (requiredPadding size__)
 
data FreeGlyphSet = MkFreeGlyphSet{glyphset_FreeGlyphSet ::
                                   GLYPHSET}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest FreeGlyphSet where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 19
               let size__ = 4 + size (glyphset_FreeGlyphSet x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (glyphset_FreeGlyphSet x)
               putSkip (requiredPadding size__)
 
data AddGlyphs = MkAddGlyphs{glyphset_AddGlyphs :: GLYPHSET,
                             glyphs_len_AddGlyphs :: Word32, glyphids_AddGlyphs :: [Word32],
                             glyphs_AddGlyphs :: [GLYPHINFO], data_AddGlyphs :: [Word8]}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest AddGlyphs where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 20
               let size__
                     = 4 + size (glyphset_AddGlyphs x) + size (glyphs_len_AddGlyphs x) +
                         sum (map size (glyphids_AddGlyphs x))
                         + sum (map size (glyphs_AddGlyphs x))
                         + sum (map size (data_AddGlyphs x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (glyphset_AddGlyphs x)
               serialize (glyphs_len_AddGlyphs x)
               serializeList (glyphids_AddGlyphs x)
               serializeList (glyphs_AddGlyphs x)
               serializeList (data_AddGlyphs x)
               putSkip (requiredPadding size__)
 
data FreeGlyphs = MkFreeGlyphs{glyphset_FreeGlyphs :: GLYPHSET,
                               glyphs_FreeGlyphs :: [GLYPH]}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest FreeGlyphs where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 22
               let size__
                     = 4 + size (glyphset_FreeGlyphs x) +
                         sum (map size (glyphs_FreeGlyphs x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (glyphset_FreeGlyphs x)
               serializeList (glyphs_FreeGlyphs x)
               putSkip (requiredPadding size__)
 
data CompositeGlyphs8 = MkCompositeGlyphs8{op_CompositeGlyphs8 ::
                                           PictOp,
                                           src_CompositeGlyphs8 :: PICTURE,
                                           dst_CompositeGlyphs8 :: PICTURE,
                                           mask_format_CompositeGlyphs8 :: PICTFORMAT,
                                           glyphset_CompositeGlyphs8 :: GLYPHSET,
                                           src_x_CompositeGlyphs8 :: Int16,
                                           src_y_CompositeGlyphs8 :: Int16,
                                           glyphcmds_CompositeGlyphs8 :: [Word8]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CompositeGlyphs8 where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 23
               let size__
                     = 4 + size (undefined :: Word8) + 3 + size (src_CompositeGlyphs8 x)
                         + size (dst_CompositeGlyphs8 x)
                         + size (mask_format_CompositeGlyphs8 x)
                         + size (glyphset_CompositeGlyphs8 x)
                         + size (src_x_CompositeGlyphs8 x)
                         + size (src_y_CompositeGlyphs8 x)
                         + sum (map size (glyphcmds_CompositeGlyphs8 x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_CompositeGlyphs8 x) :: Word8)
               putSkip 3
               serialize (src_CompositeGlyphs8 x)
               serialize (dst_CompositeGlyphs8 x)
               serialize (mask_format_CompositeGlyphs8 x)
               serialize (glyphset_CompositeGlyphs8 x)
               serialize (src_x_CompositeGlyphs8 x)
               serialize (src_y_CompositeGlyphs8 x)
               serializeList (glyphcmds_CompositeGlyphs8 x)
               putSkip (requiredPadding size__)
 
data CompositeGlyphs16 = MkCompositeGlyphs16{op_CompositeGlyphs16
                                             :: PictOp,
                                             src_CompositeGlyphs16 :: PICTURE,
                                             dst_CompositeGlyphs16 :: PICTURE,
                                             mask_format_CompositeGlyphs16 :: PICTFORMAT,
                                             glyphset_CompositeGlyphs16 :: GLYPHSET,
                                             src_x_CompositeGlyphs16 :: Int16,
                                             src_y_CompositeGlyphs16 :: Int16,
                                             glyphcmds_CompositeGlyphs16 :: [Word8]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CompositeGlyphs16 where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 24
               let size__
                     = 4 + size (undefined :: Word8) + 3 +
                         size (src_CompositeGlyphs16 x)
                         + size (dst_CompositeGlyphs16 x)
                         + size (mask_format_CompositeGlyphs16 x)
                         + size (glyphset_CompositeGlyphs16 x)
                         + size (src_x_CompositeGlyphs16 x)
                         + size (src_y_CompositeGlyphs16 x)
                         + sum (map size (glyphcmds_CompositeGlyphs16 x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_CompositeGlyphs16 x) :: Word8)
               putSkip 3
               serialize (src_CompositeGlyphs16 x)
               serialize (dst_CompositeGlyphs16 x)
               serialize (mask_format_CompositeGlyphs16 x)
               serialize (glyphset_CompositeGlyphs16 x)
               serialize (src_x_CompositeGlyphs16 x)
               serialize (src_y_CompositeGlyphs16 x)
               serializeList (glyphcmds_CompositeGlyphs16 x)
               putSkip (requiredPadding size__)
 
data CompositeGlyphs32 = MkCompositeGlyphs32{op_CompositeGlyphs32
                                             :: PictOp,
                                             src_CompositeGlyphs32 :: PICTURE,
                                             dst_CompositeGlyphs32 :: PICTURE,
                                             mask_format_CompositeGlyphs32 :: PICTFORMAT,
                                             glyphset_CompositeGlyphs32 :: GLYPHSET,
                                             src_x_CompositeGlyphs32 :: Int16,
                                             src_y_CompositeGlyphs32 :: Int16,
                                             glyphcmds_CompositeGlyphs32 :: [Word8]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CompositeGlyphs32 where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 25
               let size__
                     = 4 + size (undefined :: Word8) + 3 +
                         size (src_CompositeGlyphs32 x)
                         + size (dst_CompositeGlyphs32 x)
                         + size (mask_format_CompositeGlyphs32 x)
                         + size (glyphset_CompositeGlyphs32 x)
                         + size (src_x_CompositeGlyphs32 x)
                         + size (src_y_CompositeGlyphs32 x)
                         + sum (map size (glyphcmds_CompositeGlyphs32 x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_CompositeGlyphs32 x) :: Word8)
               putSkip 3
               serialize (src_CompositeGlyphs32 x)
               serialize (dst_CompositeGlyphs32 x)
               serialize (mask_format_CompositeGlyphs32 x)
               serialize (glyphset_CompositeGlyphs32 x)
               serialize (src_x_CompositeGlyphs32 x)
               serialize (src_y_CompositeGlyphs32 x)
               serializeList (glyphcmds_CompositeGlyphs32 x)
               putSkip (requiredPadding size__)
 
data FillRectangles = MkFillRectangles{op_FillRectangles :: PictOp,
                                       dst_FillRectangles :: PICTURE, color_FillRectangles :: COLOR,
                                       rects_FillRectangles :: [RECTANGLE]}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest FillRectangles where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 26
               let size__
                     = 4 + size (undefined :: Word8) + 3 + size (dst_FillRectangles x) +
                         size (color_FillRectangles x)
                         + sum (map size (rects_FillRectangles x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (op_FillRectangles x) :: Word8)
               putSkip 3
               serialize (dst_FillRectangles x)
               serialize (color_FillRectangles x)
               serializeList (rects_FillRectangles x)
               putSkip (requiredPadding size__)
 
data CreateCursor = MkCreateCursor{cid_CreateCursor :: CURSOR,
                                   source_CreateCursor :: PICTURE, x_CreateCursor :: Word16,
                                   y_CreateCursor :: Word16}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateCursor where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 27
               let size__
                     = 4 + size (cid_CreateCursor x) + size (source_CreateCursor x) +
                         size (x_CreateCursor x)
                         + size (y_CreateCursor x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (cid_CreateCursor x)
               serialize (source_CreateCursor x)
               serialize (x_CreateCursor x)
               serialize (y_CreateCursor x)
               putSkip (requiredPadding size__)
 
data TRANSFORM = MkTRANSFORM{matrix11_TRANSFORM :: FIXED,
                             matrix12_TRANSFORM :: FIXED, matrix13_TRANSFORM :: FIXED,
                             matrix21_TRANSFORM :: FIXED, matrix22_TRANSFORM :: FIXED,
                             matrix23_TRANSFORM :: FIXED, matrix31_TRANSFORM :: FIXED,
                             matrix32_TRANSFORM :: FIXED, matrix33_TRANSFORM :: FIXED}
               deriving (Show, Typeable, Eq, Ord)
 
instance Serialize TRANSFORM where
        serialize x
          = do serialize (matrix11_TRANSFORM x)
               serialize (matrix12_TRANSFORM x)
               serialize (matrix13_TRANSFORM x)
               serialize (matrix21_TRANSFORM x)
               serialize (matrix22_TRANSFORM x)
               serialize (matrix23_TRANSFORM x)
               serialize (matrix31_TRANSFORM x)
               serialize (matrix32_TRANSFORM x)
               serialize (matrix33_TRANSFORM x)
        size x
          = size (matrix11_TRANSFORM x) + size (matrix12_TRANSFORM x) +
              size (matrix13_TRANSFORM x)
              + size (matrix21_TRANSFORM x)
              + size (matrix22_TRANSFORM x)
              + size (matrix23_TRANSFORM x)
              + size (matrix31_TRANSFORM x)
              + size (matrix32_TRANSFORM x)
              + size (matrix33_TRANSFORM x)
 
instance Deserialize TRANSFORM where
        deserialize
          = do matrix11 <- deserialize
               matrix12 <- deserialize
               matrix13 <- deserialize
               matrix21 <- deserialize
               matrix22 <- deserialize
               matrix23 <- deserialize
               matrix31 <- deserialize
               matrix32 <- deserialize
               matrix33 <- deserialize
               return
                 (MkTRANSFORM matrix11 matrix12 matrix13 matrix21 matrix22 matrix23
                    matrix31
                    matrix32
                    matrix33)
 
data SetPictureTransform = MkSetPictureTransform{picture_SetPictureTransform
                                                 :: PICTURE,
                                                 transform_SetPictureTransform :: TRANSFORM}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetPictureTransform where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 28
               let size__
                     = 4 + size (picture_SetPictureTransform x) +
                         size (transform_SetPictureTransform x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_SetPictureTransform x)
               serialize (transform_SetPictureTransform x)
               putSkip (requiredPadding size__)
 
data QueryFilters = MkQueryFilters{drawable_QueryFilters ::
                                   DRAWABLE}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryFilters where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 29
               let size__ = 4 + size (drawable_QueryFilters x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_QueryFilters x)
               putSkip (requiredPadding size__)
 
data QueryFiltersReply = MkQueryFiltersReply{num_aliases_QueryFiltersReply
                                             :: Word32,
                                             num_filters_QueryFiltersReply :: Word32,
                                             aliases_QueryFiltersReply :: [Word16],
                                             filters_QueryFiltersReply :: [STR]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryFiltersReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_aliases <- deserialize
               num_filters <- deserialize
               skip 16
               aliases <- deserializeList (fromIntegral num_aliases)
               filters <- deserializeList (fromIntegral num_filters)
               let _ = isCard32 length
               return
                 (MkQueryFiltersReply num_aliases num_filters aliases filters)
 
data SetPictureFilter = MkSetPictureFilter{picture_SetPictureFilter
                                           :: PICTURE,
                                           filter_len_SetPictureFilter :: Word16,
                                           filter_SetPictureFilter :: [CChar],
                                           values_SetPictureFilter :: [FIXED]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetPictureFilter where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 30
               let size__
                     = 4 + size (picture_SetPictureFilter x) +
                         size (filter_len_SetPictureFilter x)
                         + 2
                         + sum (map size (filter_SetPictureFilter x))
                         + sum (map size (values_SetPictureFilter x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_SetPictureFilter x)
               serialize (filter_len_SetPictureFilter x)
               putSkip 2
               serializeList (filter_SetPictureFilter x)
               serializeList (values_SetPictureFilter x)
               putSkip (requiredPadding size__)
 
data ANIMCURSORELT = MkANIMCURSORELT{cursor_ANIMCURSORELT ::
                                     CURSOR,
                                     delay_ANIMCURSORELT :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Serialize ANIMCURSORELT where
        serialize x
          = do serialize (cursor_ANIMCURSORELT x)
               serialize (delay_ANIMCURSORELT x)
        size x
          = size (cursor_ANIMCURSORELT x) + size (delay_ANIMCURSORELT x)
 
instance Deserialize ANIMCURSORELT where
        deserialize
          = do cursor <- deserialize
               delay <- deserialize
               return (MkANIMCURSORELT cursor delay)
 
data CreateAnimCursor = MkCreateAnimCursor{cid_CreateAnimCursor ::
                                           CURSOR,
                                           cursors_CreateAnimCursor :: [ANIMCURSORELT]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateAnimCursor where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 31
               let size__
                     = 4 + size (cid_CreateAnimCursor x) +
                         sum (map size (cursors_CreateAnimCursor x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (cid_CreateAnimCursor x)
               serializeList (cursors_CreateAnimCursor x)
               putSkip (requiredPadding size__)
 
data SPANFIX = MkSPANFIX{l_SPANFIX :: FIXED, r_SPANFIX :: FIXED,
                         y_SPANFIX :: FIXED}
             deriving (Show, Typeable, Eq, Ord)
 
instance Serialize SPANFIX where
        serialize x
          = do serialize (l_SPANFIX x)
               serialize (r_SPANFIX x)
               serialize (y_SPANFIX x)
        size x
          = size (l_SPANFIX x) + size (r_SPANFIX x) + size (y_SPANFIX x)
 
instance Deserialize SPANFIX where
        deserialize
          = do l <- deserialize
               r <- deserialize
               y <- deserialize
               return (MkSPANFIX l r y)
 
data TRAP = MkTRAP{top_TRAP :: SPANFIX, bot_TRAP :: SPANFIX}
          deriving (Show, Typeable, Eq, Ord)
 
instance Serialize TRAP where
        serialize x
          = do serialize (top_TRAP x)
               serialize (bot_TRAP x)
        size x = size (top_TRAP x) + size (bot_TRAP x)
 
instance Deserialize TRAP where
        deserialize
          = do top <- deserialize
               bot <- deserialize
               return (MkTRAP top bot)
 
data AddTraps = MkAddTraps{picture_AddTraps :: PICTURE,
                           x_off_AddTraps :: Int16, y_off_AddTraps :: Int16,
                           traps_AddTraps :: [TRAP]}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest AddTraps where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 32
               let size__
                     = 4 + size (picture_AddTraps x) + size (x_off_AddTraps x) +
                         size (y_off_AddTraps x)
                         + sum (map size (traps_AddTraps x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_AddTraps x)
               serialize (x_off_AddTraps x)
               serialize (y_off_AddTraps x)
               serializeList (traps_AddTraps x)
               putSkip (requiredPadding size__)
 
data CreateSolidFill = MkCreateSolidFill{picture_CreateSolidFill ::
                                         PICTURE,
                                         color_CreateSolidFill :: COLOR}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateSolidFill where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 33
               let size__
                     = 4 + size (picture_CreateSolidFill x) +
                         size (color_CreateSolidFill x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_CreateSolidFill x)
               serialize (color_CreateSolidFill x)
               putSkip (requiredPadding size__)
 
data CreateLinearGradient = MkCreateLinearGradient{picture_CreateLinearGradient
                                                   :: PICTURE,
                                                   p1_CreateLinearGradient :: POINTFIX,
                                                   p2_CreateLinearGradient :: POINTFIX,
                                                   num_stops_CreateLinearGradient :: Word32,
                                                   stops_CreateLinearGradient :: [FIXED],
                                                   colors_CreateLinearGradient :: [COLOR]}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateLinearGradient where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 34
               let size__
                     = 4 + size (picture_CreateLinearGradient x) +
                         size (p1_CreateLinearGradient x)
                         + size (p2_CreateLinearGradient x)
                         + size (num_stops_CreateLinearGradient x)
                         + sum (map size (stops_CreateLinearGradient x))
                         + sum (map size (colors_CreateLinearGradient x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_CreateLinearGradient x)
               serialize (p1_CreateLinearGradient x)
               serialize (p2_CreateLinearGradient x)
               serialize (num_stops_CreateLinearGradient x)
               serializeList (stops_CreateLinearGradient x)
               serializeList (colors_CreateLinearGradient x)
               putSkip (requiredPadding size__)
 
data CreateRadialGradient = MkCreateRadialGradient{picture_CreateRadialGradient
                                                   :: PICTURE,
                                                   inner_CreateRadialGradient :: POINTFIX,
                                                   outer_CreateRadialGradient :: POINTFIX,
                                                   inner_radius_CreateRadialGradient :: FIXED,
                                                   outer_radius_CreateRadialGradient :: FIXED,
                                                   num_stops_CreateRadialGradient :: Word32,
                                                   stops_CreateRadialGradient :: [FIXED],
                                                   colors_CreateRadialGradient :: [COLOR]}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateRadialGradient where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 35
               let size__
                     = 4 + size (picture_CreateRadialGradient x) +
                         size (inner_CreateRadialGradient x)
                         + size (outer_CreateRadialGradient x)
                         + size (inner_radius_CreateRadialGradient x)
                         + size (outer_radius_CreateRadialGradient x)
                         + size (num_stops_CreateRadialGradient x)
                         + sum (map size (stops_CreateRadialGradient x))
                         + sum (map size (colors_CreateRadialGradient x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_CreateRadialGradient x)
               serialize (inner_CreateRadialGradient x)
               serialize (outer_CreateRadialGradient x)
               serialize (inner_radius_CreateRadialGradient x)
               serialize (outer_radius_CreateRadialGradient x)
               serialize (num_stops_CreateRadialGradient x)
               serializeList (stops_CreateRadialGradient x)
               serializeList (colors_CreateRadialGradient x)
               putSkip (requiredPadding size__)
 
data CreateConicalGradient = MkCreateConicalGradient{picture_CreateConicalGradient
                                                     :: PICTURE,
                                                     center_CreateConicalGradient :: POINTFIX,
                                                     angle_CreateConicalGradient :: FIXED,
                                                     num_stops_CreateConicalGradient :: Word32,
                                                     stops_CreateConicalGradient :: [FIXED],
                                                     colors_CreateConicalGradient :: [COLOR]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateConicalGradient where
        extensionId _ = "RENDER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 36
               let size__
                     = 4 + size (picture_CreateConicalGradient x) +
                         size (center_CreateConicalGradient x)
                         + size (angle_CreateConicalGradient x)
                         + size (num_stops_CreateConicalGradient x)
                         + sum (map size (stops_CreateConicalGradient x))
                         + sum (map size (colors_CreateConicalGradient x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_CreateConicalGradient x)
               serialize (center_CreateConicalGradient x)
               serialize (angle_CreateConicalGradient x)
               serialize (num_stops_CreateConicalGradient x)
               serializeList (stops_CreateConicalGradient x)
               serializeList (colors_CreateConicalGradient x)
               putSkip (requiredPadding size__)