module Graphics.XHB.Gen.Res
       (extension, queryVersion, queryClients, queryClientResources,
        queryClientPixmapBytes, module Graphics.XHB.Gen.Res.Types)
       where
import Graphics.XHB.Gen.Res.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "X-Resource"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word8 -> Word8 -> IO (Receipt QueryVersionReply)
queryVersion c client_major client_minor
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion client_major client_minor
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryClients ::
               Graphics.XHB.Connection.Types.Connection ->
                 IO (Receipt QueryClientsReply)
queryClients c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryClients
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryClientResources ::
                       Graphics.XHB.Connection.Types.Connection ->
                         Word32 -> IO (Receipt QueryClientResourcesReply)
queryClientResources c xid
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryClientResources xid
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryClientPixmapBytes ::
                         Graphics.XHB.Connection.Types.Connection ->
                           Word32 -> IO (Receipt QueryClientPixmapBytesReply)
queryClientPixmapBytes c xid
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryClientPixmapBytes xid
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt