module Graphics.XHB.Gen.RandR
       (extension, queryVersion, setScreenConfig, selectInput,
        getScreenInfo, getScreenSizeRange, setScreenSize,
        getScreenResources, getOutputInfo, listOutputProperties,
        queryOutputProperty, configureOutputProperty, changeOutputProperty,
        deleteOutputProperty, getOutputProperty, createMode, destroyMode,
        addOutputMode, deleteOutputMode, getCrtcInfo, setCrtcConfig,
        getCrtcGammaSize, getCrtcGamma, setCrtcGamma,
        getScreenResourcesCurrent, setCrtcTransform, getCrtcTransform,
        getPanning, setPanning, setOutputPrimary, getOutputPrimary,
        module Graphics.XHB.Gen.RandR.Types)
       where
import Graphics.XHB.Gen.RandR.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
import Graphics.XHB.Gen.Render.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Render.Types
 
extension :: ExtensionId
extension = "RANDR"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word32 -> Word32 -> IO (Receipt QueryVersionReply)
queryVersion c major_version minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion major_version minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setScreenConfig ::
                  Graphics.XHB.Connection.Types.Connection ->
                    SetScreenConfig -> IO (Receipt SetScreenConfigReply)
setScreenConfig c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
selectInput ::
              Graphics.XHB.Connection.Types.Connection ->
                WINDOW -> [NotifyMask] -> IO ()
selectInput c window enable
  = do let req = MkSelectInput window enable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getScreenInfo ::
                Graphics.XHB.Connection.Types.Connection ->
                  WINDOW -> IO (Receipt GetScreenInfoReply)
getScreenInfo c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetScreenInfo window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getScreenSizeRange ::
                     Graphics.XHB.Connection.Types.Connection ->
                       WINDOW -> IO (Receipt GetScreenSizeRangeReply)
getScreenSizeRange c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetScreenSizeRange window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setScreenSize ::
                Graphics.XHB.Connection.Types.Connection -> SetScreenSize -> IO ()
setScreenSize c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getScreenResources ::
                     Graphics.XHB.Connection.Types.Connection ->
                       WINDOW -> IO (Receipt GetScreenResourcesReply)
getScreenResources c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetScreenResources window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getOutputInfo ::
                Graphics.XHB.Connection.Types.Connection ->
                  OUTPUT -> TIMESTAMP -> IO (Receipt GetOutputInfoReply)
getOutputInfo c output config_timestamp
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetOutputInfo output config_timestamp
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
listOutputProperties ::
                       Graphics.XHB.Connection.Types.Connection ->
                         OUTPUT -> IO (Receipt ListOutputPropertiesReply)
listOutputProperties c output
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkListOutputProperties output
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryOutputProperty ::
                      Graphics.XHB.Connection.Types.Connection ->
                        OUTPUT -> ATOM -> IO (Receipt QueryOutputPropertyReply)
queryOutputProperty c output property
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryOutputProperty output property
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
configureOutputProperty ::
                          Graphics.XHB.Connection.Types.Connection ->
                            ConfigureOutputProperty -> IO ()
configureOutputProperty c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
changeOutputProperty ::
                       Graphics.XHB.Connection.Types.Connection ->
                         ChangeOutputProperty -> IO ()
changeOutputProperty c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
deleteOutputProperty ::
                       Graphics.XHB.Connection.Types.Connection -> OUTPUT -> ATOM -> IO ()
deleteOutputProperty c output property
  = do let req = MkDeleteOutputProperty output property
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getOutputProperty ::
                    Graphics.XHB.Connection.Types.Connection ->
                      GetOutputProperty -> IO (Receipt GetOutputPropertyReply)
getOutputProperty c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createMode ::
             Graphics.XHB.Connection.Types.Connection ->
               CreateMode -> IO (Receipt MODE)
createMode c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (mode_CreateModeReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
destroyMode ::
              Graphics.XHB.Connection.Types.Connection -> MODE -> IO ()
destroyMode c mode
  = do let req = MkDestroyMode mode
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
addOutputMode ::
                Graphics.XHB.Connection.Types.Connection -> OUTPUT -> MODE -> IO ()
addOutputMode c output mode
  = do let req = MkAddOutputMode output mode
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
deleteOutputMode ::
                   Graphics.XHB.Connection.Types.Connection -> OUTPUT -> MODE -> IO ()
deleteOutputMode c output mode
  = do let req = MkDeleteOutputMode output mode
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getCrtcInfo ::
              Graphics.XHB.Connection.Types.Connection ->
                CRTC -> TIMESTAMP -> IO (Receipt GetCrtcInfoReply)
getCrtcInfo c crtc config_timestamp
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetCrtcInfo crtc config_timestamp
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setCrtcConfig ::
                Graphics.XHB.Connection.Types.Connection ->
                  SetCrtcConfig -> IO (Receipt SetCrtcConfigReply)
setCrtcConfig c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getCrtcGammaSize ::
                   Graphics.XHB.Connection.Types.Connection ->
                     CRTC -> IO (Receipt Word16)
getCrtcGammaSize c crtc
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (size_GetCrtcGammaSizeReply `fmap` deserialize))
       let req = MkGetCrtcGammaSize crtc
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getCrtcGamma ::
               Graphics.XHB.Connection.Types.Connection ->
                 CRTC -> IO (Receipt GetCrtcGammaReply)
getCrtcGamma c crtc
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetCrtcGamma crtc
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setCrtcGamma ::
               Graphics.XHB.Connection.Types.Connection -> SetCrtcGamma -> IO ()
setCrtcGamma c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getScreenResourcesCurrent ::
                            Graphics.XHB.Connection.Types.Connection ->
                              WINDOW -> IO (Receipt GetScreenResourcesCurrentReply)
getScreenResourcesCurrent c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetScreenResourcesCurrent window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setCrtcTransform ::
                   Graphics.XHB.Connection.Types.Connection ->
                     SetCrtcTransform -> IO ()
setCrtcTransform c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getCrtcTransform ::
                   Graphics.XHB.Connection.Types.Connection ->
                     CRTC -> IO (Receipt GetCrtcTransformReply)
getCrtcTransform c crtc
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetCrtcTransform crtc
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getPanning ::
             Graphics.XHB.Connection.Types.Connection ->
               CRTC -> IO (Receipt GetPanningReply)
getPanning c crtc
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetPanning crtc
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setPanning ::
             Graphics.XHB.Connection.Types.Connection ->
               SetPanning -> IO (Receipt SetPanningReply)
setPanning c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setOutputPrimary ::
                   Graphics.XHB.Connection.Types.Connection ->
                     WINDOW -> OUTPUT -> IO ()
setOutputPrimary c window output
  = do let req = MkSetOutputPrimary window output
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getOutputPrimary ::
                   Graphics.XHB.Connection.Types.Connection ->
                     WINDOW -> IO (Receipt OUTPUT)
getOutputPrimary c window
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (output_GetOutputPrimaryReply `fmap` deserialize))
       let req = MkGetOutputPrimary window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt