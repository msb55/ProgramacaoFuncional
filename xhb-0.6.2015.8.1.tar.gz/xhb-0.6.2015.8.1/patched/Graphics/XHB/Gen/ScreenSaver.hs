module Graphics.XHB.Gen.ScreenSaver
       (extension, queryVersion, queryInfo, selectInput, setAttributes,
        unsetAttributes, suspend,
        module Graphics.XHB.Gen.ScreenSaver.Types)
       where
import Graphics.XHB.Gen.ScreenSaver.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "MIT-SCREEN-SAVER"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word8 -> Word8 -> IO (Receipt QueryVersionReply)
queryVersion c client_major_version client_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion client_major_version client_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryInfo ::
            Graphics.XHB.Connection.Types.Connection ->
              DRAWABLE -> IO (Receipt QueryInfoReply)
queryInfo c drawable
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryInfo drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
selectInput ::
              Graphics.XHB.Connection.Types.Connection ->
                DRAWABLE -> Word32 -> IO ()
selectInput c drawable event_mask
  = do let req = MkSelectInput drawable event_mask
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setAttributes ::
                Graphics.XHB.Connection.Types.Connection -> SetAttributes -> IO ()
setAttributes c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
unsetAttributes ::
                  Graphics.XHB.Connection.Types.Connection -> DRAWABLE -> IO ()
unsetAttributes c drawable
  = do let req = MkUnsetAttributes drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
suspend ::
          Graphics.XHB.Connection.Types.Connection -> Bool -> IO ()
suspend c suspend
  = do let req = MkSuspend suspend
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk