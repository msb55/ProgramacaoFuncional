module Graphics.XHB.Gen.XFixes
       (extension, queryVersion, changeSaveSet, selectSelectionInput,
        selectCursorInput, getCursorImage, createRegion,
        createRegionFromBitmap, createRegionFromWindow, createRegionFromGC,
        createRegionFromPicture, destroyRegion, setRegion, copyRegion,
        unionRegion, intersectRegion, subtractRegion, invertRegion,
        translateRegion, regionExtents, fetchRegion, setGCClipRegion,
        setWindowShapeRegion, setPictureClipRegion, setCursorName,
        getCursorName, getCursorImageAndName, changeCursor,
        changeCursorByName, expandRegion, hideCursor, showCursor,
        module Graphics.XHB.Gen.XFixes.Types)
       where
import Graphics.XHB.Gen.XFixes.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (ChangeSaveSet(..), SelectionNotifyEvent(..),
               deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
import Graphics.XHB.Gen.Render.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Render.Types
import Graphics.XHB.Gen.Shape.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Shape.Types
 
extension :: ExtensionId
extension = "XFIXES"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word32 -> Word32 -> IO (Receipt QueryVersionReply)
queryVersion c client_major_version client_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion client_major_version client_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
changeSaveSet ::
                Graphics.XHB.Connection.Types.Connection -> ChangeSaveSet -> IO ()
changeSaveSet c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
selectSelectionInput ::
                       Graphics.XHB.Connection.Types.Connection ->
                         SelectSelectionInput -> IO ()
selectSelectionInput c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
selectCursorInput ::
                    Graphics.XHB.Connection.Types.Connection ->
                      WINDOW -> [CursorNotifyMask] -> IO ()
selectCursorInput c window event_mask
  = do let req = MkSelectCursorInput window event_mask
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getCursorImage ::
                 Graphics.XHB.Connection.Types.Connection ->
                   IO (Receipt GetCursorImageReply)
getCursorImage c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetCursorImage
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createRegion ::
               Graphics.XHB.Connection.Types.Connection ->
                 REGION -> [RECTANGLE] -> IO ()
createRegion c region rectangles
  = do let req = MkCreateRegion region rectangles
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createRegionFromBitmap ::
                         Graphics.XHB.Connection.Types.Connection ->
                           REGION -> PIXMAP -> IO ()
createRegionFromBitmap c region bitmap
  = do let req = MkCreateRegionFromBitmap region bitmap
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createRegionFromWindow ::
                         Graphics.XHB.Connection.Types.Connection ->
                           CreateRegionFromWindow -> IO ()
createRegionFromWindow c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createRegionFromGC ::
                     Graphics.XHB.Connection.Types.Connection ->
                       REGION -> GCONTEXT -> IO ()
createRegionFromGC c region gc
  = do let req = MkCreateRegionFromGC region gc
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createRegionFromPicture ::
                          Graphics.XHB.Connection.Types.Connection ->
                            REGION -> PICTURE -> IO ()
createRegionFromPicture c region picture
  = do let req = MkCreateRegionFromPicture region picture
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
destroyRegion ::
                Graphics.XHB.Connection.Types.Connection -> REGION -> IO ()
destroyRegion c region
  = do let req = MkDestroyRegion region
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setRegion ::
            Graphics.XHB.Connection.Types.Connection ->
              REGION -> [RECTANGLE] -> IO ()
setRegion c region rectangles
  = do let req = MkSetRegion region rectangles
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
copyRegion ::
             Graphics.XHB.Connection.Types.Connection ->
               REGION -> REGION -> IO ()
copyRegion c source destination
  = do let req = MkCopyRegion source destination
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
unionRegion ::
              Graphics.XHB.Connection.Types.Connection -> UnionRegion -> IO ()
unionRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
intersectRegion ::
                  Graphics.XHB.Connection.Types.Connection ->
                    IntersectRegion -> IO ()
intersectRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
subtractRegion ::
                 Graphics.XHB.Connection.Types.Connection -> SubtractRegion -> IO ()
subtractRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
invertRegion ::
               Graphics.XHB.Connection.Types.Connection -> InvertRegion -> IO ()
invertRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
translateRegion ::
                  Graphics.XHB.Connection.Types.Connection ->
                    TranslateRegion -> IO ()
translateRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
regionExtents ::
                Graphics.XHB.Connection.Types.Connection ->
                  REGION -> REGION -> IO ()
regionExtents c source destination
  = do let req = MkRegionExtents source destination
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
fetchRegion ::
              Graphics.XHB.Connection.Types.Connection ->
                REGION -> IO (Receipt FetchRegionReply)
fetchRegion c region
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkFetchRegion region
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setGCClipRegion ::
                  Graphics.XHB.Connection.Types.Connection ->
                    SetGCClipRegion -> IO ()
setGCClipRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setWindowShapeRegion ::
                       Graphics.XHB.Connection.Types.Connection ->
                         SetWindowShapeRegion -> IO ()
setWindowShapeRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setPictureClipRegion ::
                       Graphics.XHB.Connection.Types.Connection ->
                         SetPictureClipRegion -> IO ()
setPictureClipRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setCursorName ::
                Graphics.XHB.Connection.Types.Connection -> SetCursorName -> IO ()
setCursorName c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getCursorName ::
                Graphics.XHB.Connection.Types.Connection ->
                  CURSOR -> IO (Receipt GetCursorNameReply)
getCursorName c cursor
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetCursorName cursor
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getCursorImageAndName ::
                        Graphics.XHB.Connection.Types.Connection ->
                          IO (Receipt GetCursorImageAndNameReply)
getCursorImageAndName c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetCursorImageAndName
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
changeCursor ::
               Graphics.XHB.Connection.Types.Connection ->
                 CURSOR -> CURSOR -> IO ()
changeCursor c source destination
  = do let req = MkChangeCursor source destination
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
changeCursorByName ::
                     Graphics.XHB.Connection.Types.Connection ->
                       ChangeCursorByName -> IO ()
changeCursorByName c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
expandRegion ::
               Graphics.XHB.Connection.Types.Connection -> ExpandRegion -> IO ()
expandRegion c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
hideCursor ::
             Graphics.XHB.Connection.Types.Connection -> WINDOW -> IO ()
hideCursor c window
  = do let req = MkHideCursor window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
showCursor ::
             Graphics.XHB.Connection.Types.Connection -> WINDOW -> IO ()
showCursor c window
  = do let req = MkShowCursor window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk