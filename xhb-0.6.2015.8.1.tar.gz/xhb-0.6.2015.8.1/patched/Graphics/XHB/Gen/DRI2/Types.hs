module Graphics.XHB.Gen.DRI2.Types
       (deserializeError, deserializeEvent, Attachment(..),
        DriverType(..), DRI2Buffer(..), AttachFormat(..), QueryVersion(..),
        QueryVersionReply(..), Connect(..), ConnectReply(..),
        Authenticate(..), AuthenticateReply(..), CreateDrawable(..),
        DestroyDrawable(..), GetBuffers(..), GetBuffersReply(..),
        CopyRegion(..), CopyRegionReply(..), GetBuffersWithFormat(..),
        GetBuffersWithFormatReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data Attachment = AttachmentBufferFrontLeft
                | AttachmentBufferBackLeft
                | AttachmentBufferFrontRight
                | AttachmentBufferBackRight
                | AttachmentBufferDepth
                | AttachmentBufferStencil
                | AttachmentBufferAccum
                | AttachmentBufferFakeFrontLeft
                | AttachmentBufferFakeFrontRight
                | AttachmentBufferDepthStencil
                deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Attachment where
        toValue AttachmentBufferFrontLeft{} = 0
        toValue AttachmentBufferBackLeft{} = 1
        toValue AttachmentBufferFrontRight{} = 2
        toValue AttachmentBufferBackRight{} = 3
        toValue AttachmentBufferDepth{} = 4
        toValue AttachmentBufferStencil{} = 5
        toValue AttachmentBufferAccum{} = 6
        toValue AttachmentBufferFakeFrontLeft{} = 7
        toValue AttachmentBufferFakeFrontRight{} = 8
        toValue AttachmentBufferDepthStencil{} = 9
        fromValue 0 = AttachmentBufferFrontLeft
        fromValue 1 = AttachmentBufferBackLeft
        fromValue 2 = AttachmentBufferFrontRight
        fromValue 3 = AttachmentBufferBackRight
        fromValue 4 = AttachmentBufferDepth
        fromValue 5 = AttachmentBufferStencil
        fromValue 6 = AttachmentBufferAccum
        fromValue 7 = AttachmentBufferFakeFrontLeft
        fromValue 8 = AttachmentBufferFakeFrontRight
        fromValue 9 = AttachmentBufferDepthStencil
 
data DriverType = DriverTypeDRI
                deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum DriverType where
        toValue DriverTypeDRI{} = 0
        fromValue 0 = DriverTypeDRI
 
data DRI2Buffer = MkDRI2Buffer{attachment_DRI2Buffer :: Attachment,
                               name_DRI2Buffer :: Word32, pitch_DRI2Buffer :: Word32,
                               cpp_DRI2Buffer :: Word32, flags_DRI2Buffer :: Word32}
                deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DRI2Buffer where
        serialize x
          = do serialize (toValue (attachment_DRI2Buffer x) :: Word32)
               serialize (name_DRI2Buffer x)
               serialize (pitch_DRI2Buffer x)
               serialize (cpp_DRI2Buffer x)
               serialize (flags_DRI2Buffer x)
        size x
          = size (undefined :: Word32) + size (name_DRI2Buffer x) +
              size (pitch_DRI2Buffer x)
              + size (cpp_DRI2Buffer x)
              + size (flags_DRI2Buffer x)
 
instance Deserialize DRI2Buffer where
        deserialize
          = do attachment <- liftM fromValue (deserialize :: Get Word32)
               name <- deserialize
               pitch <- deserialize
               cpp <- deserialize
               flags <- deserialize
               return (MkDRI2Buffer attachment name pitch cpp flags)
 
data AttachFormat = MkAttachFormat{attachment_AttachFormat ::
                                   Attachment,
                                   format_AttachFormat :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Serialize AttachFormat where
        serialize x
          = do serialize (toValue (attachment_AttachFormat x) :: Word32)
               serialize (format_AttachFormat x)
        size x = size (undefined :: Word32) + size (format_AttachFormat x)
 
instance Deserialize AttachFormat where
        deserialize
          = do attachment <- liftM fromValue (deserialize :: Get Word32)
               format <- deserialize
               return (MkAttachFormat attachment format)
 
data QueryVersion = MkQueryVersion{major_version_QueryVersion ::
                                   Word32,
                                   minor_version_QueryVersion :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "DRI2"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (major_version_QueryVersion x) +
                         size (minor_version_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (major_version_QueryVersion x)
               serialize (minor_version_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_version_QueryVersionReply
                                             :: Word32,
                                             minor_version_QueryVersionReply :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               let _ = isCard32 length
               return (MkQueryVersionReply major_version minor_version)
 
data Connect = MkConnect{window_Connect :: WINDOW,
                         driver_type_Connect :: DriverType}
             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Connect where
        extensionId _ = "DRI2"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (window_Connect x) + size (undefined :: Word32)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_Connect x)
               serialize (toValue (driver_type_Connect x) :: Word32)
               putSkip (requiredPadding size__)
 
data ConnectReply = MkConnectReply{driver_name_length_ConnectReply
                                   :: Word32,
                                   device_name_length_ConnectReply :: Word32,
                                   driver_name_ConnectReply :: [CChar],
                                   device_name_ConnectReply :: [CChar]}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ConnectReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               driver_name_length <- deserialize
               device_name_length <- deserialize
               skip 16
               driver_name <- deserializeList (fromIntegral driver_name_length)
               device_name <- deserializeList (fromIntegral device_name_length)
               let _ = isCard32 length
               return
                 (MkConnectReply driver_name_length device_name_length driver_name
                    device_name)
 
data Authenticate = MkAuthenticate{window_Authenticate :: WINDOW,
                                   magic_Authenticate :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Authenticate where
        extensionId _ = "DRI2"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (window_Authenticate x) + size (magic_Authenticate x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_Authenticate x)
               serialize (magic_Authenticate x)
               putSkip (requiredPadding size__)
 
data AuthenticateReply = MkAuthenticateReply{authenticated_AuthenticateReply
                                             :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize AuthenticateReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               authenticated <- deserialize
               let _ = isCard32 length
               return (MkAuthenticateReply authenticated)
 
data CreateDrawable = MkCreateDrawable{drawable_CreateDrawable ::
                                       DRAWABLE}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateDrawable where
        extensionId _ = "DRI2"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__ = 4 + size (drawable_CreateDrawable x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_CreateDrawable x)
               putSkip (requiredPadding size__)
 
data DestroyDrawable = MkDestroyDrawable{drawable_DestroyDrawable
                                         :: DRAWABLE}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyDrawable where
        extensionId _ = "DRI2"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4 + size (drawable_DestroyDrawable x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_DestroyDrawable x)
               putSkip (requiredPadding size__)
 
data GetBuffers = MkGetBuffers{drawable_GetBuffers :: DRAWABLE,
                               count_GetBuffers :: Word32, attachments_GetBuffers :: [Word32]}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetBuffers where
        extensionId _ = "DRI2"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (drawable_GetBuffers x) + size (count_GetBuffers x) +
                         sum (map size (attachments_GetBuffers x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_GetBuffers x)
               serialize (count_GetBuffers x)
               serializeList (attachments_GetBuffers x)
               putSkip (requiredPadding size__)
 
data GetBuffersReply = MkGetBuffersReply{width_GetBuffersReply ::
                                         Word32,
                                         height_GetBuffersReply :: Word32,
                                         count_GetBuffersReply :: Word32,
                                         buffers_GetBuffersReply :: [DRI2Buffer]}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetBuffersReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               width <- deserialize
               height <- deserialize
               count <- deserialize
               skip 12
               buffers <- deserializeList (fromIntegral count)
               let _ = isCard32 length
               return (MkGetBuffersReply width height count buffers)
 
data CopyRegion = MkCopyRegion{drawable_CopyRegion :: DRAWABLE,
                               region_CopyRegion :: Word32, dest_CopyRegion :: Word32,
                               src_CopyRegion :: Word32}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CopyRegion where
        extensionId _ = "DRI2"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__
                     = 4 + size (drawable_CopyRegion x) + size (region_CopyRegion x) +
                         size (dest_CopyRegion x)
                         + size (src_CopyRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_CopyRegion x)
               serialize (region_CopyRegion x)
               serialize (dest_CopyRegion x)
               serialize (src_CopyRegion x)
               putSkip (requiredPadding size__)
 
data CopyRegionReply = MkCopyRegionReply{}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize CopyRegionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               let _ = isCard32 length
               return (MkCopyRegionReply)
 
data GetBuffersWithFormat = MkGetBuffersWithFormat{drawable_GetBuffersWithFormat
                                                   :: DRAWABLE,
                                                   count_GetBuffersWithFormat :: Word32,
                                                   attachments_GetBuffersWithFormat ::
                                                   [AttachFormat]}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetBuffersWithFormat where
        extensionId _ = "DRI2"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__
                     = 4 + size (drawable_GetBuffersWithFormat x) +
                         size (count_GetBuffersWithFormat x)
                         + sum (map size (attachments_GetBuffersWithFormat x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_GetBuffersWithFormat x)
               serialize (count_GetBuffersWithFormat x)
               serializeList (attachments_GetBuffersWithFormat x)
               putSkip (requiredPadding size__)
 
data GetBuffersWithFormatReply = MkGetBuffersWithFormatReply{width_GetBuffersWithFormatReply
                                                             :: Word32,
                                                             height_GetBuffersWithFormatReply ::
                                                             Word32,
                                                             count_GetBuffersWithFormatReply ::
                                                             Word32,
                                                             buffers_GetBuffersWithFormatReply ::
                                                             [DRI2Buffer]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetBuffersWithFormatReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               width <- deserialize
               height <- deserialize
               count <- deserialize
               skip 12
               buffers <- deserializeList (fromIntegral count)
               let _ = isCard32 length
               return (MkGetBuffersWithFormatReply width height count buffers)