module Graphics.XHB.Gen.Sync.Types
       (deserializeError, deserializeEvent, ALARM, ALARMSTATE(..),
        COUNTER, TESTTYPE(..), VALUETYPE(..), CA(..), INT64(..),
        SYSTEMCOUNTER(..), TRIGGER(..), WAITCONDITION(..),
        CounterError(..), AlarmError(..), Initialize(..),
        InitializeReply(..), ListSystemCounters(..),
        ListSystemCountersReply(..), CreateCounter(..), DestroyCounter(..),
        QueryCounter(..), QueryCounterReply(..), Await(..),
        ChangeCounter(..), SetCounter(..), CreateAlarm(..),
        ChangeAlarm(..), DestroyAlarm(..), QueryAlarm(..),
        QueryAlarmReply(..), SetPriority(..), GetPriority(..),
        GetPriorityReply(..), CounterNotifyEvent(..), AlarmNotifyEvent(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError 0
  = return (liftM toError (deserialize :: Get CounterError))
deserializeError 1
  = return (liftM toError (deserialize :: Get AlarmError))
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get CounterNotifyEvent))
deserializeEvent 1
  = return (liftM toEvent (deserialize :: Get AlarmNotifyEvent))
deserializeEvent _ = Nothing
 
newtype ALARM = MkALARM Xid
                deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
data ALARMSTATE = ALARMSTATEActive
                | ALARMSTATEInactive
                | ALARMSTATEDestroyed
                deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum ALARMSTATE where
        toValue ALARMSTATEActive{} = 0
        toValue ALARMSTATEInactive{} = 1
        toValue ALARMSTATEDestroyed{} = 2
        fromValue 0 = ALARMSTATEActive
        fromValue 1 = ALARMSTATEInactive
        fromValue 2 = ALARMSTATEDestroyed
 
newtype COUNTER = MkCOUNTER Xid
                  deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
data TESTTYPE = TESTTYPEPositiveTransition
              | TESTTYPENegativeTransition
              | TESTTYPEPositiveComparison
              | TESTTYPENegativeComparison
              deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum TESTTYPE where
        toValue TESTTYPEPositiveTransition{} = 0
        toValue TESTTYPENegativeTransition{} = 1
        toValue TESTTYPEPositiveComparison{} = 2
        toValue TESTTYPENegativeComparison{} = 3
        fromValue 0 = TESTTYPEPositiveTransition
        fromValue 1 = TESTTYPENegativeTransition
        fromValue 2 = TESTTYPEPositiveComparison
        fromValue 3 = TESTTYPENegativeComparison
 
data VALUETYPE = VALUETYPEAbsolute
               | VALUETYPERelative
               deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum VALUETYPE where
        toValue VALUETYPEAbsolute{} = 0
        toValue VALUETYPERelative{} = 1
        fromValue 0 = VALUETYPEAbsolute
        fromValue 1 = VALUETYPERelative
 
data CA = CACounter
        | CAValueType
        | CAValue
        | CATestType
        | CADelta
        | CAEvents
        deriving (Show, Eq, Ord, Enum, Typeable)
 
instance BitEnum CA where
        toBit CACounter{} = 0
        toBit CAValueType{} = 1
        toBit CAValue{} = 2
        toBit CATestType{} = 3
        toBit CADelta{} = 4
        toBit CAEvents{} = 5
        fromBit 0 = CACounter
        fromBit 1 = CAValueType
        fromBit 2 = CAValue
        fromBit 3 = CATestType
        fromBit 4 = CADelta
        fromBit 5 = CAEvents
 
data INT64 = MkINT64{hi_INT64 :: Int32, lo_INT64 :: Word32}
           deriving (Show, Typeable, Eq, Ord)
 
instance Serialize INT64 where
        serialize x
          = do serialize (hi_INT64 x)
               serialize (lo_INT64 x)
        size x = size (hi_INT64 x) + size (lo_INT64 x)
 
instance Deserialize INT64 where
        deserialize
          = do hi <- deserialize
               lo <- deserialize
               return (MkINT64 hi lo)
 
data SYSTEMCOUNTER = MkSYSTEMCOUNTER{counter_SYSTEMCOUNTER ::
                                     COUNTER,
                                     resolution_SYSTEMCOUNTER :: INT64,
                                     name_len_SYSTEMCOUNTER :: Word16,
                                     name_SYSTEMCOUNTER :: [CChar]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Serialize SYSTEMCOUNTER where
        serialize x
          = do serialize (counter_SYSTEMCOUNTER x)
               serialize (resolution_SYSTEMCOUNTER x)
               serialize (name_len_SYSTEMCOUNTER x)
               serializeList (name_SYSTEMCOUNTER x)
        size x
          = size (counter_SYSTEMCOUNTER x) +
              size (resolution_SYSTEMCOUNTER x)
              + size (name_len_SYSTEMCOUNTER x)
              + sum (map size (name_SYSTEMCOUNTER x))
 
instance Deserialize SYSTEMCOUNTER where
        deserialize
          = do counter <- deserialize
               resolution <- deserialize
               name_len <- deserialize
               name <- deserializeList (fromIntegral name_len)
               return (MkSYSTEMCOUNTER counter resolution name_len name)
 
data TRIGGER = MkTRIGGER{counter_TRIGGER :: COUNTER,
                         wait_type_TRIGGER :: VALUETYPE, wait_value_TRIGGER :: INT64,
                         test_type_TRIGGER :: TESTTYPE}
             deriving (Show, Typeable, Eq, Ord)
 
instance Serialize TRIGGER where
        serialize x
          = do serialize (counter_TRIGGER x)
               serialize (toValue (wait_type_TRIGGER x) :: Word32)
               serialize (wait_value_TRIGGER x)
               serialize (toValue (test_type_TRIGGER x) :: Word32)
        size x
          = size (counter_TRIGGER x) + size (undefined :: Word32) +
              size (wait_value_TRIGGER x)
              + size (undefined :: Word32)
 
instance Deserialize TRIGGER where
        deserialize
          = do counter <- deserialize
               wait_type <- liftM fromValue (deserialize :: Get Word32)
               wait_value <- deserialize
               test_type <- liftM fromValue (deserialize :: Get Word32)
               return (MkTRIGGER counter wait_type wait_value test_type)
 
data WAITCONDITION = MkWAITCONDITION{trigger_WAITCONDITION ::
                                     TRIGGER,
                                     event_threshold_WAITCONDITION :: INT64}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Serialize WAITCONDITION where
        serialize x
          = do serialize (trigger_WAITCONDITION x)
               serialize (event_threshold_WAITCONDITION x)
        size x
          = size (trigger_WAITCONDITION x) +
              size (event_threshold_WAITCONDITION x)
 
instance Deserialize WAITCONDITION where
        deserialize
          = do trigger <- deserialize
               event_threshold <- deserialize
               return (MkWAITCONDITION trigger event_threshold)
 
data CounterError = MkCounterError{bad_counter_CounterError ::
                                   Word32,
                                   minor_opcode_CounterError :: Word16,
                                   major_opcode_CounterError :: Word8}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error CounterError
 
instance Deserialize CounterError where
        deserialize
          = do skip 4
               bad_counter <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               return (MkCounterError bad_counter minor_opcode major_opcode)
 
data AlarmError = MkAlarmError{bad_alarm_AlarmError :: Word32,
                               minor_opcode_AlarmError :: Word16,
                               major_opcode_AlarmError :: Word8}
                deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error AlarmError
 
instance Deserialize AlarmError where
        deserialize
          = do skip 4
               bad_alarm <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               return (MkAlarmError bad_alarm minor_opcode major_opcode)
 
data Initialize = MkInitialize{desired_major_version_Initialize ::
                               Word8,
                               desired_minor_version_Initialize :: Word8}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Initialize where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (desired_major_version_Initialize x) +
                         size (desired_minor_version_Initialize x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (desired_major_version_Initialize x)
               serialize (desired_minor_version_Initialize x)
               putSkip (requiredPadding size__)
 
data InitializeReply = MkInitializeReply{major_version_InitializeReply
                                         :: Word8,
                                         minor_version_InitializeReply :: Word8}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize InitializeReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               skip 22
               let _ = isCard32 length
               return (MkInitializeReply major_version minor_version)
 
data ListSystemCounters = MkListSystemCounters{}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ListSystemCounters where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data ListSystemCountersReply = MkListSystemCountersReply{counters_len_ListSystemCountersReply
                                                         :: Word32,
                                                         counters_ListSystemCountersReply ::
                                                         [SYSTEMCOUNTER]}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ListSystemCountersReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               counters_len <- deserialize
               skip 20
               counters <- deserializeList (fromIntegral counters_len)
               let _ = isCard32 length
               return (MkListSystemCountersReply counters_len counters)
 
data CreateCounter = MkCreateCounter{id_CreateCounter :: COUNTER,
                                     initial_value_CreateCounter :: INT64}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateCounter where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (id_CreateCounter x) +
                         size (initial_value_CreateCounter x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (id_CreateCounter x)
               serialize (initial_value_CreateCounter x)
               putSkip (requiredPadding size__)
 
data DestroyCounter = MkDestroyCounter{counter_DestroyCounter ::
                                       COUNTER}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyCounter where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__ = 4 + size (counter_DestroyCounter x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (counter_DestroyCounter x)
               putSkip (requiredPadding size__)
 
data QueryCounter = MkQueryCounter{counter_QueryCounter :: COUNTER}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryCounter where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__ = 4 + size (counter_QueryCounter x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (counter_QueryCounter x)
               putSkip (requiredPadding size__)
 
data QueryCounterReply = MkQueryCounterReply{counter_value_QueryCounterReply
                                             :: INT64}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryCounterReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               counter_value <- deserialize
               let _ = isCard32 length
               return (MkQueryCounterReply counter_value)
 
data Await = MkAwait{wait_list_Await :: [WAITCONDITION]}
           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Await where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4 + sum (map size (wait_list_Await x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serializeList (wait_list_Await x)
               putSkip (requiredPadding size__)
 
data ChangeCounter = MkChangeCounter{counter_ChangeCounter ::
                                     COUNTER,
                                     amount_ChangeCounter :: INT64}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeCounter where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__
                     = 4 + size (counter_ChangeCounter x) +
                         size (amount_ChangeCounter x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (counter_ChangeCounter x)
               serialize (amount_ChangeCounter x)
               putSkip (requiredPadding size__)
 
data SetCounter = MkSetCounter{counter_SetCounter :: COUNTER,
                               value_SetCounter :: INT64}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetCounter where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (counter_SetCounter x) + size (value_SetCounter x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (counter_SetCounter x)
               serialize (value_SetCounter x)
               putSkip (requiredPadding size__)
 
data CreateAlarm = MkCreateAlarm{id_CreateAlarm :: ALARM,
                                 value_CreateAlarm :: ValueParam Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateAlarm where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__
                     = 4 + size (id_CreateAlarm x) + size (value_CreateAlarm x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (id_CreateAlarm x)
               serialize (value_CreateAlarm x)
               putSkip (requiredPadding size__)
 
data ChangeAlarm = MkChangeAlarm{id_ChangeAlarm :: ALARM,
                                 value_ChangeAlarm :: ValueParam Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeAlarm where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 9
               let size__
                     = 4 + size (id_ChangeAlarm x) + size (value_ChangeAlarm x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (id_ChangeAlarm x)
               serialize (value_ChangeAlarm x)
               putSkip (requiredPadding size__)
 
data DestroyAlarm = MkDestroyAlarm{alarm_DestroyAlarm :: ALARM}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyAlarm where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 11
               let size__ = 4 + size (alarm_DestroyAlarm x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (alarm_DestroyAlarm x)
               putSkip (requiredPadding size__)
 
data QueryAlarm = MkQueryAlarm{alarm_QueryAlarm :: ALARM}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryAlarm where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 10
               let size__ = 4 + size (alarm_QueryAlarm x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (alarm_QueryAlarm x)
               putSkip (requiredPadding size__)
 
data QueryAlarmReply = MkQueryAlarmReply{trigger_QueryAlarmReply ::
                                         TRIGGER,
                                         delta_QueryAlarmReply :: INT64,
                                         events_QueryAlarmReply :: Bool,
                                         state_QueryAlarmReply :: ALARMSTATE}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryAlarmReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               trigger <- deserialize
               delta <- deserialize
               events <- deserialize
               state <- liftM fromValue (deserialize :: Get Word8)
               skip 2
               let _ = isCard32 length
               return (MkQueryAlarmReply trigger delta events state)
 
data SetPriority = MkSetPriority{id_SetPriority :: Word32,
                                 priority_SetPriority :: Int32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetPriority where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 12
               let size__
                     = 4 + size (id_SetPriority x) + size (priority_SetPriority x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (id_SetPriority x)
               serialize (priority_SetPriority x)
               putSkip (requiredPadding size__)
 
data GetPriority = MkGetPriority{id_GetPriority :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPriority where
        extensionId _ = "SYNC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 13
               let size__ = 4 + size (id_GetPriority x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (id_GetPriority x)
               putSkip (requiredPadding size__)
 
data GetPriorityReply = MkGetPriorityReply{priority_GetPriorityReply
                                           :: Int32}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPriorityReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               priority <- deserialize
               let _ = isCard32 length
               return (MkGetPriorityReply priority)
 
data CounterNotifyEvent = MkCounterNotifyEvent{kind_CounterNotifyEvent
                                               :: Word8,
                                               counter_CounterNotifyEvent :: COUNTER,
                                               wait_value_CounterNotifyEvent :: INT64,
                                               counter_value_CounterNotifyEvent :: INT64,
                                               timestamp_CounterNotifyEvent :: TIMESTAMP,
                                               count_CounterNotifyEvent :: Word16,
                                               destroyed_CounterNotifyEvent :: Bool}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event CounterNotifyEvent
 
instance Deserialize CounterNotifyEvent where
        deserialize
          = do skip 1
               kind <- deserialize
               skip 2
               counter <- deserialize
               wait_value <- deserialize
               counter_value <- deserialize
               timestamp <- deserialize
               count <- deserialize
               destroyed <- deserialize
               skip 1
               return
                 (MkCounterNotifyEvent kind counter wait_value counter_value
                    timestamp
                    count
                    destroyed)
 
data AlarmNotifyEvent = MkAlarmNotifyEvent{kind_AlarmNotifyEvent ::
                                           Word8,
                                           alarm_AlarmNotifyEvent :: ALARM,
                                           counter_value_AlarmNotifyEvent :: INT64,
                                           alarm_value_AlarmNotifyEvent :: INT64,
                                           timestamp_AlarmNotifyEvent :: TIMESTAMP,
                                           state_AlarmNotifyEvent :: ALARMSTATE}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event AlarmNotifyEvent
 
instance Deserialize AlarmNotifyEvent where
        deserialize
          = do skip 1
               kind <- deserialize
               skip 2
               alarm <- deserialize
               counter_value <- deserialize
               alarm_value <- deserialize
               timestamp <- deserialize
               state <- liftM fromValue (deserialize :: Get Word8)
               skip 3
               return
                 (MkAlarmNotifyEvent kind alarm counter_value alarm_value timestamp
                    state)