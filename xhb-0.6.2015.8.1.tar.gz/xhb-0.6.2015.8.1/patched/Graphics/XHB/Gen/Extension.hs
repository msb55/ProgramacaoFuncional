module Graphics.XHB.Gen.Extension where
import Graphics.XHB.Shared
import Data.Binary.Get
import Data.Word
import qualified Graphics.XHB.Gen.BigRequests.Types
import qualified Graphics.XHB.Gen.Composite.Types
import qualified Graphics.XHB.Gen.Damage.Types
import qualified Graphics.XHB.Gen.DPMS.Types
import qualified Graphics.XHB.Gen.DRI2.Types
import qualified Graphics.XHB.Gen.Glx.Types
import qualified Graphics.XHB.Gen.RandR.Types
import qualified Graphics.XHB.Gen.Record.Types
import qualified Graphics.XHB.Gen.Render.Types
import qualified Graphics.XHB.Gen.Res.Types
import qualified Graphics.XHB.Gen.ScreenSaver.Types
import qualified Graphics.XHB.Gen.Shape.Types
import qualified Graphics.XHB.Gen.Shm.Types
import qualified Graphics.XHB.Gen.Sync.Types
import qualified Graphics.XHB.Gen.XCMisc.Types
import qualified Graphics.XHB.Gen.Xevie.Types
import qualified Graphics.XHB.Gen.XF86Dri.Types
import qualified Graphics.XHB.Gen.XFixes.Types
import qualified Graphics.XHB.Gen.Xinerama.Types
import qualified Graphics.XHB.Gen.Input.Types
import qualified Graphics.XHB.Gen.XPrint.Types
import qualified Graphics.XHB.Gen.SELinux.Types
import qualified Graphics.XHB.Gen.Test.Types
import qualified Graphics.XHB.Gen.XvMC.Types
import qualified Graphics.XHB.Gen.Xv.Types
 
errorDispatch :: ExtensionId -> Word8 -> Maybe (Get SomeError)
errorDispatch "BIG-REQUESTS"
  = Graphics.XHB.Gen.BigRequests.Types.deserializeError
errorDispatch "Composite"
  = Graphics.XHB.Gen.Composite.Types.deserializeError
errorDispatch "DAMAGE"
  = Graphics.XHB.Gen.Damage.Types.deserializeError
errorDispatch "DPMS" = Graphics.XHB.Gen.DPMS.Types.deserializeError
errorDispatch "DRI2" = Graphics.XHB.Gen.DRI2.Types.deserializeError
errorDispatch "GLX" = Graphics.XHB.Gen.Glx.Types.deserializeError
errorDispatch "RANDR"
  = Graphics.XHB.Gen.RandR.Types.deserializeError
errorDispatch "RECORD"
  = Graphics.XHB.Gen.Record.Types.deserializeError
errorDispatch "RENDER"
  = Graphics.XHB.Gen.Render.Types.deserializeError
errorDispatch "X-Resource"
  = Graphics.XHB.Gen.Res.Types.deserializeError
errorDispatch "MIT-SCREEN-SAVER"
  = Graphics.XHB.Gen.ScreenSaver.Types.deserializeError
errorDispatch "SHAPE"
  = Graphics.XHB.Gen.Shape.Types.deserializeError
errorDispatch "MIT-SHM"
  = Graphics.XHB.Gen.Shm.Types.deserializeError
errorDispatch "SYNC" = Graphics.XHB.Gen.Sync.Types.deserializeError
errorDispatch "XC-MISC"
  = Graphics.XHB.Gen.XCMisc.Types.deserializeError
errorDispatch "XEVIE"
  = Graphics.XHB.Gen.Xevie.Types.deserializeError
errorDispatch "XFree86-DRI"
  = Graphics.XHB.Gen.XF86Dri.Types.deserializeError
errorDispatch "XFIXES"
  = Graphics.XHB.Gen.XFixes.Types.deserializeError
errorDispatch "XINERAMA"
  = Graphics.XHB.Gen.Xinerama.Types.deserializeError
errorDispatch "XInputExtension"
  = Graphics.XHB.Gen.Input.Types.deserializeError
errorDispatch "XpExtension"
  = Graphics.XHB.Gen.XPrint.Types.deserializeError
errorDispatch "SELinux"
  = Graphics.XHB.Gen.SELinux.Types.deserializeError
errorDispatch "XTEST"
  = Graphics.XHB.Gen.Test.Types.deserializeError
errorDispatch "XVideo-MotionCompensation"
  = Graphics.XHB.Gen.XvMC.Types.deserializeError
errorDispatch "XVideo" = Graphics.XHB.Gen.Xv.Types.deserializeError
errorDispatch _ = const (Nothing)
 
eventDispatch :: ExtensionId -> Word8 -> Maybe (Get SomeEvent)
eventDispatch "BIG-REQUESTS"
  = Graphics.XHB.Gen.BigRequests.Types.deserializeEvent
eventDispatch "Composite"
  = Graphics.XHB.Gen.Composite.Types.deserializeEvent
eventDispatch "DAMAGE"
  = Graphics.XHB.Gen.Damage.Types.deserializeEvent
eventDispatch "DPMS" = Graphics.XHB.Gen.DPMS.Types.deserializeEvent
eventDispatch "DRI2" = Graphics.XHB.Gen.DRI2.Types.deserializeEvent
eventDispatch "GLX" = Graphics.XHB.Gen.Glx.Types.deserializeEvent
eventDispatch "RANDR"
  = Graphics.XHB.Gen.RandR.Types.deserializeEvent
eventDispatch "RECORD"
  = Graphics.XHB.Gen.Record.Types.deserializeEvent
eventDispatch "RENDER"
  = Graphics.XHB.Gen.Render.Types.deserializeEvent
eventDispatch "X-Resource"
  = Graphics.XHB.Gen.Res.Types.deserializeEvent
eventDispatch "MIT-SCREEN-SAVER"
  = Graphics.XHB.Gen.ScreenSaver.Types.deserializeEvent
eventDispatch "SHAPE"
  = Graphics.XHB.Gen.Shape.Types.deserializeEvent
eventDispatch "MIT-SHM"
  = Graphics.XHB.Gen.Shm.Types.deserializeEvent
eventDispatch "SYNC" = Graphics.XHB.Gen.Sync.Types.deserializeEvent
eventDispatch "XC-MISC"
  = Graphics.XHB.Gen.XCMisc.Types.deserializeEvent
eventDispatch "XEVIE"
  = Graphics.XHB.Gen.Xevie.Types.deserializeEvent
eventDispatch "XFree86-DRI"
  = Graphics.XHB.Gen.XF86Dri.Types.deserializeEvent
eventDispatch "XFIXES"
  = Graphics.XHB.Gen.XFixes.Types.deserializeEvent
eventDispatch "XINERAMA"
  = Graphics.XHB.Gen.Xinerama.Types.deserializeEvent
eventDispatch "XInputExtension"
  = Graphics.XHB.Gen.Input.Types.deserializeEvent
eventDispatch "XpExtension"
  = Graphics.XHB.Gen.XPrint.Types.deserializeEvent
eventDispatch "SELinux"
  = Graphics.XHB.Gen.SELinux.Types.deserializeEvent
eventDispatch "XTEST"
  = Graphics.XHB.Gen.Test.Types.deserializeEvent
eventDispatch "XVideo-MotionCompensation"
  = Graphics.XHB.Gen.XvMC.Types.deserializeEvent
eventDispatch "XVideo" = Graphics.XHB.Gen.Xv.Types.deserializeEvent
eventDispatch _ = const (Nothing)