module Graphics.XHB.Gen.DRI2
       (extension, queryVersion, connect, authenticate, createDrawable,
        destroyDrawable, getBuffers, copyRegion, getBuffersWithFormat,
        module Graphics.XHB.Gen.DRI2.Types)
       where
import Graphics.XHB.Gen.DRI2.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "DRI2"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word32 -> Word32 -> IO (Receipt QueryVersionReply)
queryVersion c major_version minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion major_version minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
connect ::
          Graphics.XHB.Connection.Types.Connection ->
            WINDOW -> DriverType -> IO (Receipt ConnectReply)
connect c window driver_type
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkConnect window driver_type
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
authenticate ::
               Graphics.XHB.Connection.Types.Connection ->
                 WINDOW -> Word32 -> IO (Receipt Word32)
authenticate c window magic
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (authenticated_AuthenticateReply `fmap` deserialize))
       let req = MkAuthenticate window magic
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createDrawable ::
                 Graphics.XHB.Connection.Types.Connection -> DRAWABLE -> IO ()
createDrawable c drawable
  = do let req = MkCreateDrawable drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
destroyDrawable ::
                  Graphics.XHB.Connection.Types.Connection -> DRAWABLE -> IO ()
destroyDrawable c drawable
  = do let req = MkDestroyDrawable drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getBuffers ::
             Graphics.XHB.Connection.Types.Connection ->
               GetBuffers -> IO (Receipt GetBuffersReply)
getBuffers c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
copyRegion ::
             Graphics.XHB.Connection.Types.Connection ->
               CopyRegion -> IO (Receipt CopyRegionReply)
copyRegion c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getBuffersWithFormat ::
                       Graphics.XHB.Connection.Types.Connection ->
                         GetBuffersWithFormat -> IO (Receipt GetBuffersWithFormatReply)
getBuffersWithFormat c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt