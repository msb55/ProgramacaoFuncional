module Graphics.XHB.Gen.SELinux.Types
       (deserializeError, deserializeEvent, QueryVersion(..),
        QueryVersionReply(..), SetDeviceCreateContext(..),
        GetDeviceCreateContext(..), GetDeviceCreateContextReply(..),
        SetDeviceContext(..), GetDeviceContext(..),
        GetDeviceContextReply(..), SetWindowCreateContext(..),
        GetWindowCreateContext(..), GetWindowCreateContextReply(..),
        GetWindowContext(..), GetWindowContextReply(..), ListItem(..),
        SetPropertyCreateContext(..), GetPropertyCreateContext(..),
        GetPropertyCreateContextReply(..), SetPropertyUseContext(..),
        GetPropertyUseContext(..), GetPropertyUseContextReply(..),
        GetPropertyContext(..), GetPropertyContextReply(..),
        GetPropertyDataContext(..), GetPropertyDataContextReply(..),
        ListProperties(..), ListPropertiesReply(..),
        SetSelectionCreateContext(..), GetSelectionCreateContext(..),
        GetSelectionCreateContextReply(..), SetSelectionUseContext(..),
        GetSelectionUseContext(..), GetSelectionUseContextReply(..),
        GetSelectionContext(..), GetSelectionContextReply(..),
        GetSelectionDataContext(..), GetSelectionDataContextReply(..),
        ListSelections(..), ListSelectionsReply(..), GetClientContext(..),
        GetClientContextReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (ListProperties(..), ListPropertiesReply(..),
               deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data QueryVersion = MkQueryVersion{client_major_QueryVersion ::
                                   Word8,
                                   client_minor_QueryVersion :: Word8}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_QueryVersion x) +
                         size (client_minor_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_QueryVersion x)
               serialize (client_minor_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{server_major_QueryVersionReply
                                             :: Word16,
                                             server_minor_QueryVersionReply :: Word16}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               server_major <- deserialize
               server_minor <- deserialize
               let _ = isCard32 length
               return (MkQueryVersionReply server_major server_minor)
 
data SetDeviceCreateContext = MkSetDeviceCreateContext{context_len_SetDeviceCreateContext
                                                       :: Word32,
                                                       context_SetDeviceCreateContext :: [CChar]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetDeviceCreateContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (context_len_SetDeviceCreateContext x) +
                         sum (map size (context_SetDeviceCreateContext x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_len_SetDeviceCreateContext x)
               serializeList (context_SetDeviceCreateContext x)
               putSkip (requiredPadding size__)
 
data GetDeviceCreateContext = MkGetDeviceCreateContext{}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceCreateContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetDeviceCreateContextReply = MkGetDeviceCreateContextReply{context_len_GetDeviceCreateContextReply
                                                                 :: Word32,
                                                                 context_GetDeviceCreateContextReply
                                                                 :: [CChar]}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceCreateContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetDeviceCreateContextReply context_len context)
 
data SetDeviceContext = MkSetDeviceContext{device_SetDeviceContext
                                           :: Word32,
                                           context_len_SetDeviceContext :: Word32,
                                           context_SetDeviceContext :: [CChar]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetDeviceContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (device_SetDeviceContext x) +
                         size (context_len_SetDeviceContext x)
                         + sum (map size (context_SetDeviceContext x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_SetDeviceContext x)
               serialize (context_len_SetDeviceContext x)
               serializeList (context_SetDeviceContext x)
               putSkip (requiredPadding size__)
 
data GetDeviceContext = MkGetDeviceContext{device_GetDeviceContext
                                           :: Word32}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4 + size (device_GetDeviceContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_GetDeviceContext x)
               putSkip (requiredPadding size__)
 
data GetDeviceContextReply = MkGetDeviceContextReply{context_len_GetDeviceContextReply
                                                     :: Word32,
                                                     context_GetDeviceContextReply :: [CChar]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetDeviceContextReply context_len context)
 
data SetWindowCreateContext = MkSetWindowCreateContext{context_len_SetWindowCreateContext
                                                       :: Word32,
                                                       context_SetWindowCreateContext :: [CChar]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetWindowCreateContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (context_len_SetWindowCreateContext x) +
                         sum (map size (context_SetWindowCreateContext x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_len_SetWindowCreateContext x)
               serializeList (context_SetWindowCreateContext x)
               putSkip (requiredPadding size__)
 
data GetWindowCreateContext = MkGetWindowCreateContext{}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetWindowCreateContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetWindowCreateContextReply = MkGetWindowCreateContextReply{context_len_GetWindowCreateContextReply
                                                                 :: Word32,
                                                                 context_GetWindowCreateContextReply
                                                                 :: [CChar]}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetWindowCreateContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetWindowCreateContextReply context_len context)
 
data GetWindowContext = MkGetWindowContext{window_GetWindowContext
                                           :: WINDOW}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetWindowContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4 + size (window_GetWindowContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetWindowContext x)
               putSkip (requiredPadding size__)
 
data GetWindowContextReply = MkGetWindowContextReply{context_len_GetWindowContextReply
                                                     :: Word32,
                                                     context_GetWindowContextReply :: [CChar]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetWindowContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetWindowContextReply context_len context)
 
data ListItem = MkListItem{name_ListItem :: ATOM,
                           object_context_len_ListItem :: Word32,
                           data_context_len_ListItem :: Word32,
                           object_context_ListItem :: [CChar],
                           data_context_ListItem :: [CChar]}
              deriving (Show, Typeable, Eq, Ord)
 
instance Serialize ListItem where
        serialize x
          = do serialize (name_ListItem x)
               serialize (object_context_len_ListItem x)
               serialize (data_context_len_ListItem x)
               serializeList (object_context_ListItem x)
               serializeList (data_context_ListItem x)
        size x
          = size (name_ListItem x) + size (object_context_len_ListItem x) +
              size (data_context_len_ListItem x)
              + sum (map size (object_context_ListItem x))
              + sum (map size (data_context_ListItem x))
 
instance Deserialize ListItem where
        deserialize
          = do name <- deserialize
               object_context_len <- deserialize
               data_context_len <- deserialize
               object_context <- deserializeList (fromIntegral object_context_len)
               data_context <- deserializeList (fromIntegral data_context_len)
               return
                 (MkListItem name object_context_len data_context_len object_context
                    data_context)
 
data SetPropertyCreateContext = MkSetPropertyCreateContext{context_len_SetPropertyCreateContext
                                                           :: Word32,
                                                           context_SetPropertyCreateContext ::
                                                           [CChar]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetPropertyCreateContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__
                     = 4 + size (context_len_SetPropertyCreateContext x) +
                         sum (map size (context_SetPropertyCreateContext x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_len_SetPropertyCreateContext x)
               serializeList (context_SetPropertyCreateContext x)
               putSkip (requiredPadding size__)
 
data GetPropertyCreateContext = MkGetPropertyCreateContext{}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPropertyCreateContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 9
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetPropertyCreateContextReply = MkGetPropertyCreateContextReply{context_len_GetPropertyCreateContextReply
                                                                     :: Word32,
                                                                     context_GetPropertyCreateContextReply
                                                                     :: [CChar]}
                                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPropertyCreateContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetPropertyCreateContextReply context_len context)
 
data SetPropertyUseContext = MkSetPropertyUseContext{context_len_SetPropertyUseContext
                                                     :: Word32,
                                                     context_SetPropertyUseContext :: [CChar]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetPropertyUseContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 10
               let size__
                     = 4 + size (context_len_SetPropertyUseContext x) +
                         sum (map size (context_SetPropertyUseContext x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_len_SetPropertyUseContext x)
               serializeList (context_SetPropertyUseContext x)
               putSkip (requiredPadding size__)
 
data GetPropertyUseContext = MkGetPropertyUseContext{}
                           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPropertyUseContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 11
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetPropertyUseContextReply = MkGetPropertyUseContextReply{context_len_GetPropertyUseContextReply
                                                               :: Word32,
                                                               context_GetPropertyUseContextReply ::
                                                               [CChar]}
                                deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPropertyUseContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetPropertyUseContextReply context_len context)
 
data GetPropertyContext = MkGetPropertyContext{window_GetPropertyContext
                                               :: WINDOW,
                                               property_GetPropertyContext :: ATOM}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPropertyContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 12
               let size__
                     = 4 + size (window_GetPropertyContext x) +
                         size (property_GetPropertyContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetPropertyContext x)
               serialize (property_GetPropertyContext x)
               putSkip (requiredPadding size__)
 
data GetPropertyContextReply = MkGetPropertyContextReply{context_len_GetPropertyContextReply
                                                         :: Word32,
                                                         context_GetPropertyContextReply :: [CChar]}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPropertyContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetPropertyContextReply context_len context)
 
data GetPropertyDataContext = MkGetPropertyDataContext{window_GetPropertyDataContext
                                                       :: WINDOW,
                                                       property_GetPropertyDataContext :: ATOM}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetPropertyDataContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 13
               let size__
                     = 4 + size (window_GetPropertyDataContext x) +
                         size (property_GetPropertyDataContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetPropertyDataContext x)
               serialize (property_GetPropertyDataContext x)
               putSkip (requiredPadding size__)
 
data GetPropertyDataContextReply = MkGetPropertyDataContextReply{context_len_GetPropertyDataContextReply
                                                                 :: Word32,
                                                                 context_GetPropertyDataContextReply
                                                                 :: [CChar]}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetPropertyDataContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetPropertyDataContextReply context_len context)
 
data ListProperties = MkListProperties{window_ListProperties ::
                                       WINDOW}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ListProperties where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 14
               let size__ = 4 + size (window_ListProperties x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_ListProperties x)
               putSkip (requiredPadding size__)
 
data ListPropertiesReply = MkListPropertiesReply{properties_len_ListPropertiesReply
                                                 :: Word32,
                                                 properties_ListPropertiesReply :: [ListItem]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ListPropertiesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               properties_len <- deserialize
               skip 20
               properties <- deserializeList (fromIntegral properties_len)
               let _ = isCard32 length
               return (MkListPropertiesReply properties_len properties)
 
data SetSelectionCreateContext = MkSetSelectionCreateContext{context_len_SetSelectionCreateContext
                                                             :: Word32,
                                                             context_SetSelectionCreateContext ::
                                                             [CChar]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetSelectionCreateContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 15
               let size__
                     = 4 + size (context_len_SetSelectionCreateContext x) +
                         sum (map size (context_SetSelectionCreateContext x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_len_SetSelectionCreateContext x)
               serializeList (context_SetSelectionCreateContext x)
               putSkip (requiredPadding size__)
 
data GetSelectionCreateContext = MkGetSelectionCreateContext{}
                               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetSelectionCreateContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 16
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetSelectionCreateContextReply = MkGetSelectionCreateContextReply{context_len_GetSelectionCreateContextReply
                                                                       :: Word32,
                                                                       context_GetSelectionCreateContextReply
                                                                       :: [CChar]}
                                    deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetSelectionCreateContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetSelectionCreateContextReply context_len context)
 
data SetSelectionUseContext = MkSetSelectionUseContext{context_len_SetSelectionUseContext
                                                       :: Word32,
                                                       context_SetSelectionUseContext :: [CChar]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetSelectionUseContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 17
               let size__
                     = 4 + size (context_len_SetSelectionUseContext x) +
                         sum (map size (context_SetSelectionUseContext x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_len_SetSelectionUseContext x)
               serializeList (context_SetSelectionUseContext x)
               putSkip (requiredPadding size__)
 
data GetSelectionUseContext = MkGetSelectionUseContext{}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetSelectionUseContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 18
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetSelectionUseContextReply = MkGetSelectionUseContextReply{context_len_GetSelectionUseContextReply
                                                                 :: Word32,
                                                                 context_GetSelectionUseContextReply
                                                                 :: [CChar]}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetSelectionUseContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetSelectionUseContextReply context_len context)
 
data GetSelectionContext = MkGetSelectionContext{selection_GetSelectionContext
                                                 :: ATOM}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetSelectionContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 19
               let size__ = 4 + size (selection_GetSelectionContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (selection_GetSelectionContext x)
               putSkip (requiredPadding size__)
 
data GetSelectionContextReply = MkGetSelectionContextReply{context_len_GetSelectionContextReply
                                                           :: Word32,
                                                           context_GetSelectionContextReply ::
                                                           [CChar]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetSelectionContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetSelectionContextReply context_len context)
 
data GetSelectionDataContext = MkGetSelectionDataContext{selection_GetSelectionDataContext
                                                         :: ATOM}
                             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetSelectionDataContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 20
               let size__ = 4 + size (selection_GetSelectionDataContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (selection_GetSelectionDataContext x)
               putSkip (requiredPadding size__)
 
data GetSelectionDataContextReply = MkGetSelectionDataContextReply{context_len_GetSelectionDataContextReply
                                                                   :: Word32,
                                                                   context_GetSelectionDataContextReply
                                                                   :: [CChar]}
                                  deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetSelectionDataContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetSelectionDataContextReply context_len context)
 
data ListSelections = MkListSelections{}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ListSelections where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 21
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data ListSelectionsReply = MkListSelectionsReply{selections_len_ListSelectionsReply
                                                 :: Word32,
                                                 selections_ListSelectionsReply :: [ListItem]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ListSelectionsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               selections_len <- deserialize
               skip 20
               selections <- deserializeList (fromIntegral selections_len)
               let _ = isCard32 length
               return (MkListSelectionsReply selections_len selections)
 
data GetClientContext = MkGetClientContext{resource_GetClientContext
                                           :: Word32}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetClientContext where
        extensionId _ = "SELinux"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 22
               let size__ = 4 + size (resource_GetClientContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (resource_GetClientContext x)
               putSkip (requiredPadding size__)
 
data GetClientContextReply = MkGetClientContextReply{context_len_GetClientContextReply
                                                     :: Word32,
                                                     context_GetClientContextReply :: [CChar]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetClientContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context_len <- deserialize
               skip 20
               context <- deserializeList (fromIntegral context_len)
               let _ = isCard32 length
               return (MkGetClientContextReply context_len context)