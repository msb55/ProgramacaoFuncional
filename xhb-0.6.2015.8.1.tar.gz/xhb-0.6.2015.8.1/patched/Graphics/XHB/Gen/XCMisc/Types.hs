module Graphics.XHB.Gen.XCMisc.Types
       (deserializeError, deserializeEvent, GetVersion(..),
        GetVersionReply(..), GetXIDRange(..), GetXIDRangeReply(..),
        GetXIDList(..), GetXIDListReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data GetVersion = MkGetVersion{client_major_version_GetVersion ::
                               Word16,
                               client_minor_version_GetVersion :: Word16}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetVersion where
        extensionId _ = "XC-MISC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_version_GetVersion x) +
                         size (client_minor_version_GetVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_version_GetVersion x)
               serialize (client_minor_version_GetVersion x)
               putSkip (requiredPadding size__)
 
data GetVersionReply = MkGetVersionReply{server_major_version_GetVersionReply
                                         :: Word16,
                                         server_minor_version_GetVersionReply :: Word16}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               server_major_version <- deserialize
               server_minor_version <- deserialize
               let _ = isCard32 length
               return
                 (MkGetVersionReply server_major_version server_minor_version)
 
data GetXIDRange = MkGetXIDRange{}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetXIDRange where
        extensionId _ = "XC-MISC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetXIDRangeReply = MkGetXIDRangeReply{start_id_GetXIDRangeReply
                                           :: Word32,
                                           count_GetXIDRangeReply :: Word32}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetXIDRangeReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               start_id <- deserialize
               count <- deserialize
               let _ = isCard32 length
               return (MkGetXIDRangeReply start_id count)
 
data GetXIDList = MkGetXIDList{count_GetXIDList :: Word32}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetXIDList where
        extensionId _ = "XC-MISC"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4 + size (count_GetXIDList x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (count_GetXIDList x)
               putSkip (requiredPadding size__)
 
data GetXIDListReply = MkGetXIDListReply{ids_len_GetXIDListReply ::
                                         Word32,
                                         ids_GetXIDListReply :: [Word32]}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetXIDListReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               ids_len <- deserialize
               skip 20
               ids <- deserializeList (fromIntegral ids_len)
               let _ = isCard32 length
               return (MkGetXIDListReply ids_len ids)