module Graphics.XHB.Gen.Input.Types
       (deserializeError, deserializeEvent, KeyCode, EventClass,
        ValuatorMode(..), PropagateMode(..), GetExtensionVersion(..),
        GetExtensionVersionReply(..), DeviceUse(..), DeviceInfo(..),
        ListInputDevices(..), ListInputDevicesReply(..), InputClass(..),
        InputInfo(..), KeyInfo(..), ButtonInfo(..), AxisInfo(..),
        ValuatorInfo(..), InputClassInfo(..), OpenDevice(..),
        OpenDeviceReply(..), CloseDevice(..), SetDeviceMode(..),
        SetDeviceModeReply(..), SelectExtensionEvent(..),
        GetSelectedExtensionEvents(..),
        GetSelectedExtensionEventsReply(..),
        ChangeDeviceDontPropagateList(..), GetDeviceDontPropagateList(..),
        GetDeviceDontPropagateListReply(..), GetDeviceMotionEvents(..),
        GetDeviceMotionEventsReply(..), DeviceTimeCoord(..),
        ChangeKeyboardDevice(..), ChangeKeyboardDeviceReply(..),
        ChangePointerDevice(..), ChangePointerDeviceReply(..),
        GrabDevice(..), GrabDeviceReply(..), UngrabDevice(..),
        GrabDeviceKey(..), UngrabDeviceKey(..), GrabDeviceButton(..),
        UngrabDeviceButton(..), DeviceInputMode(..), AllowDeviceEvents(..),
        GetDeviceFocus(..), GetDeviceFocusReply(..), SetDeviceFocus(..),
        GetFeedbackControl(..), GetFeedbackControlReply(..),
        FeedbackClass(..), FeedbackState(..), KbdFeedbackState(..),
        PtrFeedbackState(..), IntegerFeedbackState(..),
        StringFeedbackState(..), BellFeedbackState(..),
        LedFeedbackState(..), FeedbackCtl(..), KbdFeedbackCtl(..),
        PtrFeedbackCtl(..), IntegerFeedbackCtl(..), StringFeedbackCtl(..),
        BellFeedbackCtl(..), LedFeedbackCtl(..), GetDeviceKeyMapping(..),
        GetDeviceKeyMappingReply(..), ChangeDeviceKeyMapping(..),
        GetDeviceModifierMapping(..), GetDeviceModifierMappingReply(..),
        SetDeviceModifierMapping(..), SetDeviceModifierMappingReply(..),
        GetDeviceButtonMapping(..), GetDeviceButtonMappingReply(..),
        SetDeviceButtonMapping(..), SetDeviceButtonMappingReply(..),
        QueryDeviceState(..), QueryDeviceStateReply(..), InputState(..),
        KeyState(..), ButtonState(..), ValuatorState(..),
        SendExtensionEvent(..), DeviceBell(..), SetDeviceValuators(..),
        SetDeviceValuatorsReply(..), GetDeviceControl(..),
        GetDeviceControlReply(..), DeviceState(..),
        DeviceResolutionState(..), DeviceAbsCalibState(..),
        DeviceAbsAreaState(..), DeviceCoreState(..), DeviceEnableState(..),
        DeviceCtl(..), DeviceResolutionCtl(..), DeviceAbsCalibCtl(..),
        DeviceAbsAreaCtrl(..), DeviceCoreCtrl(..), DeviceEnableCtrl(..),
        DeviceValuatorEvent(..), DeviceKeyPressEvent(..),
        DeviceKeyReleaseEvent(..), DeviceButtonPressEvent(..),
        DeviceButtonReleaseEvent(..), DeviceMotionNotifyEvent(..),
        ProximityInEvent(..), ProximityOutEvent(..), FocusInEvent(..),
        FocusOutEvent(..), DeviceStateNotifyEvent(..),
        DeviceMappingNotifyEvent(..), ChangeDeviceNotifyEvent(..),
        DeviceKeyStateNotifyEvent(..), DeviceButtonStateNotifyEvent(..),
        DevicePresenceNotifyEvent(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (FocusInEvent(..), FocusOutEvent(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get DeviceValuatorEvent))
deserializeEvent 1
  = return (liftM toEvent (deserialize :: Get DeviceKeyPressEvent))
deserializeEvent 2
  = return (liftM toEvent (deserialize :: Get DeviceKeyReleaseEvent))
deserializeEvent 3
  = return
      (liftM toEvent (deserialize :: Get DeviceButtonPressEvent))
deserializeEvent 4
  = return
      (liftM toEvent (deserialize :: Get DeviceButtonReleaseEvent))
deserializeEvent 5
  = return
      (liftM toEvent (deserialize :: Get DeviceMotionNotifyEvent))
deserializeEvent 8
  = return (liftM toEvent (deserialize :: Get ProximityInEvent))
deserializeEvent 9
  = return (liftM toEvent (deserialize :: Get ProximityOutEvent))
deserializeEvent 6
  = return (liftM toEvent (deserialize :: Get FocusInEvent))
deserializeEvent 7
  = return (liftM toEvent (deserialize :: Get FocusOutEvent))
deserializeEvent 10
  = return
      (liftM toEvent (deserialize :: Get DeviceStateNotifyEvent))
deserializeEvent 11
  = return
      (liftM toEvent (deserialize :: Get DeviceMappingNotifyEvent))
deserializeEvent 12
  = return
      (liftM toEvent (deserialize :: Get ChangeDeviceNotifyEvent))
deserializeEvent 13
  = return
      (liftM toEvent (deserialize :: Get DeviceKeyStateNotifyEvent))
deserializeEvent 14
  = return
      (liftM toEvent (deserialize :: Get DeviceButtonStateNotifyEvent))
deserializeEvent 15
  = return
      (liftM toEvent (deserialize :: Get DevicePresenceNotifyEvent))
deserializeEvent _ = Nothing
 
type KeyCode = Word8
 
type EventClass = Word32
 
data ValuatorMode = ValuatorModeRelative
                  | ValuatorModeAbsolute
                  deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum ValuatorMode where
        toValue ValuatorModeRelative{} = 0
        toValue ValuatorModeAbsolute{} = 1
        fromValue 0 = ValuatorModeRelative
        fromValue 1 = ValuatorModeAbsolute
 
data PropagateMode = PropagateModeAddToList
                   | PropagateModeDeleteFromList
                   deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum PropagateMode where
        toValue PropagateModeAddToList{} = 0
        toValue PropagateModeDeleteFromList{} = 1
        fromValue 0 = PropagateModeAddToList
        fromValue 1 = PropagateModeDeleteFromList
 
data GetExtensionVersion = MkGetExtensionVersion{name_len_GetExtensionVersion
                                                 :: Word16,
                                                 name_GetExtensionVersion :: [CChar]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetExtensionVersion where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (name_len_GetExtensionVersion x) + 2 +
                         sum (map size (name_GetExtensionVersion x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (name_len_GetExtensionVersion x)
               putSkip 2
               serializeList (name_GetExtensionVersion x)
               putSkip (requiredPadding size__)
 
data GetExtensionVersionReply = MkGetExtensionVersionReply{server_major_GetExtensionVersionReply
                                                           :: Word16,
                                                           server_minor_GetExtensionVersionReply ::
                                                           Word16,
                                                           present_GetExtensionVersionReply :: Bool}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetExtensionVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               server_major <- deserialize
               server_minor <- deserialize
               present <- deserialize
               skip 19
               let _ = isCard32 length
               return
                 (MkGetExtensionVersionReply server_major server_minor present)
 
data DeviceUse = DeviceUseIsXPointer
               | DeviceUseIsXKeyboard
               | DeviceUseIsXExtensionDevice
               | DeviceUseIsXExtensionKeyboard
               | DeviceUseIsXExtensionPointer
               deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum DeviceUse where
        toValue DeviceUseIsXPointer{} = 0
        toValue DeviceUseIsXKeyboard{} = 1
        toValue DeviceUseIsXExtensionDevice{} = 2
        toValue DeviceUseIsXExtensionKeyboard{} = 3
        toValue DeviceUseIsXExtensionPointer{} = 4
        fromValue 0 = DeviceUseIsXPointer
        fromValue 1 = DeviceUseIsXKeyboard
        fromValue 2 = DeviceUseIsXExtensionDevice
        fromValue 3 = DeviceUseIsXExtensionKeyboard
        fromValue 4 = DeviceUseIsXExtensionPointer
 
data DeviceInfo = MkDeviceInfo{device_type_DeviceInfo :: ATOM,
                               device_id_DeviceInfo :: Word8, num_class_info_DeviceInfo :: Word8,
                               device_use_DeviceInfo :: DeviceUse}
                deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceInfo where
        serialize x
          = do serialize (device_type_DeviceInfo x)
               serialize (device_id_DeviceInfo x)
               serialize (num_class_info_DeviceInfo x)
               serialize (toValue (device_use_DeviceInfo x) :: Word8)
               putSkip 1
        size x
          = size (device_type_DeviceInfo x) + size (device_id_DeviceInfo x) +
              size (num_class_info_DeviceInfo x)
              + size (undefined :: Word8)
              + 1
 
instance Deserialize DeviceInfo where
        deserialize
          = do device_type <- deserialize
               device_id <- deserialize
               num_class_info <- deserialize
               device_use <- liftM fromValue (deserialize :: Get Word8)
               skip 1
               return
                 (MkDeviceInfo device_type device_id num_class_info device_use)
 
data ListInputDevices = MkListInputDevices{}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ListInputDevices where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data ListInputDevicesReply = MkListInputDevicesReply{devices_len_ListInputDevicesReply
                                                     :: Word8,
                                                     devices_ListInputDevicesReply :: [DeviceInfo]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ListInputDevicesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               devices_len <- deserialize
               skip 23
               devices <- deserializeList (fromIntegral devices_len)
               let _ = isCard32 length
               return (MkListInputDevicesReply devices_len devices)
 
data InputClass = InputClassKey
                | InputClassButton
                | InputClassValuator
                | InputClassFeedback
                | InputClassProximity
                | InputClassFocus
                | InputClassOther
                deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum InputClass where
        toValue InputClassKey{} = 0
        toValue InputClassButton{} = 1
        toValue InputClassValuator{} = 2
        toValue InputClassFeedback{} = 3
        toValue InputClassProximity{} = 4
        toValue InputClassFocus{} = 5
        toValue InputClassOther{} = 6
        fromValue 0 = InputClassKey
        fromValue 1 = InputClassButton
        fromValue 2 = InputClassValuator
        fromValue 3 = InputClassFeedback
        fromValue 4 = InputClassProximity
        fromValue 5 = InputClassFocus
        fromValue 6 = InputClassOther
 
data InputInfo = MkInputInfo{class_id_InputInfo :: InputClass,
                             len_InputInfo :: Word8}
               deriving (Show, Typeable, Eq, Ord)
 
instance Serialize InputInfo where
        serialize x
          = do serialize (toValue (class_id_InputInfo x) :: Word8)
               serialize (len_InputInfo x)
        size x = size (undefined :: Word8) + size (len_InputInfo x)
 
instance Deserialize InputInfo where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               len <- deserialize
               return (MkInputInfo class_id len)
 
data KeyInfo = MkKeyInfo{class_id_KeyInfo :: InputClass,
                         len_KeyInfo :: Word8, min_keycode_KeyInfo :: KeyCode,
                         max_keycode_KeyInfo :: KeyCode, num_keys_KeyInfo :: Word16}
             deriving (Show, Typeable, Eq, Ord)
 
instance Serialize KeyInfo where
        serialize x
          = do serialize (toValue (class_id_KeyInfo x) :: Word8)
               serialize (len_KeyInfo x)
               serialize (min_keycode_KeyInfo x)
               serialize (max_keycode_KeyInfo x)
               serialize (num_keys_KeyInfo x)
               putSkip 2
        size x
          = size (undefined :: Word8) + size (len_KeyInfo x) +
              size (min_keycode_KeyInfo x)
              + size (max_keycode_KeyInfo x)
              + size (num_keys_KeyInfo x)
              + 2
 
instance Deserialize KeyInfo where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               len <- deserialize
               min_keycode <- deserialize
               max_keycode <- deserialize
               num_keys <- deserialize
               skip 2
               return (MkKeyInfo class_id len min_keycode max_keycode num_keys)
 
data ButtonInfo = MkButtonInfo{class_id_ButtonInfo :: InputClass,
                               len_ButtonInfo :: Word8, num_buttons_ButtonInfo :: Word16}
                deriving (Show, Typeable, Eq, Ord)
 
instance Serialize ButtonInfo where
        serialize x
          = do serialize (toValue (class_id_ButtonInfo x) :: Word8)
               serialize (len_ButtonInfo x)
               serialize (num_buttons_ButtonInfo x)
        size x
          = size (undefined :: Word8) + size (len_ButtonInfo x) +
              size (num_buttons_ButtonInfo x)
 
instance Deserialize ButtonInfo where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               len <- deserialize
               num_buttons <- deserialize
               return (MkButtonInfo class_id len num_buttons)
 
data AxisInfo = MkAxisInfo{resolution_AxisInfo :: Word32,
                           minimum_AxisInfo :: Int32, maximum_AxisInfo :: Int32}
              deriving (Show, Typeable, Eq, Ord)
 
instance Serialize AxisInfo where
        serialize x
          = do serialize (resolution_AxisInfo x)
               serialize (minimum_AxisInfo x)
               serialize (maximum_AxisInfo x)
        size x
          = size (resolution_AxisInfo x) + size (minimum_AxisInfo x) +
              size (maximum_AxisInfo x)
 
instance Deserialize AxisInfo where
        deserialize
          = do resolution <- deserialize
               minimum <- deserialize
               maximum <- deserialize
               return (MkAxisInfo resolution minimum maximum)
 
data ValuatorInfo = MkValuatorInfo{class_id_ValuatorInfo ::
                                   InputClass,
                                   len_ValuatorInfo :: Word8, axes_len_ValuatorInfo :: Word8,
                                   mode_ValuatorInfo :: ValuatorMode,
                                   motion_size_ValuatorInfo :: Word32,
                                   axes_ValuatorInfo :: [AxisInfo]}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Serialize ValuatorInfo where
        serialize x
          = do serialize (toValue (class_id_ValuatorInfo x) :: Word8)
               serialize (len_ValuatorInfo x)
               serialize (axes_len_ValuatorInfo x)
               serialize (toValue (mode_ValuatorInfo x) :: Word8)
               serialize (motion_size_ValuatorInfo x)
               serializeList (axes_ValuatorInfo x)
        size x
          = size (undefined :: Word8) + size (len_ValuatorInfo x) +
              size (axes_len_ValuatorInfo x)
              + size (undefined :: Word8)
              + size (motion_size_ValuatorInfo x)
              + sum (map size (axes_ValuatorInfo x))
 
instance Deserialize ValuatorInfo where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               len <- deserialize
               axes_len <- deserialize
               mode <- liftM fromValue (deserialize :: Get Word8)
               motion_size <- deserialize
               axes <- deserializeList (fromIntegral axes_len)
               return (MkValuatorInfo class_id len axes_len mode motion_size axes)
 
data InputClassInfo = MkInputClassInfo{class_id_InputClassInfo ::
                                       InputClass,
                                       event_type_base_InputClassInfo :: Word8}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Serialize InputClassInfo where
        serialize x
          = do serialize (toValue (class_id_InputClassInfo x) :: Word8)
               serialize (event_type_base_InputClassInfo x)
        size x
          = size (undefined :: Word8) +
              size (event_type_base_InputClassInfo x)
 
instance Deserialize InputClassInfo where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               event_type_base <- deserialize
               return (MkInputClassInfo class_id event_type_base)
 
data OpenDevice = MkOpenDevice{device_id_OpenDevice :: Word8}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest OpenDevice where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__ = 4 + size (device_id_OpenDevice x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_OpenDevice x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data OpenDeviceReply = MkOpenDeviceReply{num_classes_OpenDeviceReply
                                         :: Word8,
                                         class_info_OpenDeviceReply :: [InputClassInfo]}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize OpenDeviceReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_classes <- deserialize
               skip 23
               class_info <- deserializeList (fromIntegral num_classes)
               let _ = isCard32 length
               return (MkOpenDeviceReply num_classes class_info)
 
data CloseDevice = MkCloseDevice{device_id_CloseDevice :: Word8}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CloseDevice where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4 + size (device_id_CloseDevice x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_CloseDevice x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data SetDeviceMode = MkSetDeviceMode{device_id_SetDeviceMode ::
                                     Word8,
                                     mode_SetDeviceMode :: ValuatorMode}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetDeviceMode where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (device_id_SetDeviceMode x) + size (undefined :: Word8)
                         + 2
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_SetDeviceMode x)
               serialize (toValue (mode_SetDeviceMode x) :: Word8)
               putSkip 2
               putSkip (requiredPadding size__)
 
data SetDeviceModeReply = MkSetDeviceModeReply{status_SetDeviceModeReply
                                               :: Word8}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize SetDeviceModeReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status <- deserialize
               skip 23
               let _ = isCard32 length
               return (MkSetDeviceModeReply status)
 
data SelectExtensionEvent = MkSelectExtensionEvent{window_SelectExtensionEvent
                                                   :: WINDOW,
                                                   num_classes_SelectExtensionEvent :: Word16,
                                                   classes_SelectExtensionEvent :: [EventClass]}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SelectExtensionEvent where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__
                     = 4 + size (window_SelectExtensionEvent x) +
                         size (num_classes_SelectExtensionEvent x)
                         + 2
                         + sum (map size (classes_SelectExtensionEvent x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_SelectExtensionEvent x)
               serialize (num_classes_SelectExtensionEvent x)
               putSkip 2
               serializeList (classes_SelectExtensionEvent x)
               putSkip (requiredPadding size__)
 
data GetSelectedExtensionEvents = MkGetSelectedExtensionEvents{window_GetSelectedExtensionEvents
                                                               :: WINDOW}
                                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetSelectedExtensionEvents where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4 + size (window_GetSelectedExtensionEvents x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetSelectedExtensionEvents x)
               putSkip (requiredPadding size__)
 
data GetSelectedExtensionEventsReply = MkGetSelectedExtensionEventsReply{num_this_classes_GetSelectedExtensionEventsReply
                                                                         :: Word16,
                                                                         num_all_classes_GetSelectedExtensionEventsReply
                                                                         :: Word16,
                                                                         this_classes_GetSelectedExtensionEventsReply
                                                                         :: [EventClass],
                                                                         all_classes_GetSelectedExtensionEventsReply
                                                                         :: [EventClass]}
                                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetSelectedExtensionEventsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_this_classes <- deserialize
               num_all_classes <- deserialize
               skip 20
               this_classes <- deserializeList (fromIntegral num_this_classes)
               all_classes <- deserializeList (fromIntegral num_all_classes)
               let _ = isCard32 length
               return
                 (MkGetSelectedExtensionEventsReply num_this_classes num_all_classes
                    this_classes
                    all_classes)
 
data ChangeDeviceDontPropagateList = MkChangeDeviceDontPropagateList{window_ChangeDeviceDontPropagateList
                                                                     :: WINDOW,
                                                                     num_classes_ChangeDeviceDontPropagateList
                                                                     :: Word16,
                                                                     mode_ChangeDeviceDontPropagateList
                                                                     :: PropagateMode,
                                                                     classes_ChangeDeviceDontPropagateList
                                                                     :: [EventClass]}
                                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeDeviceDontPropagateList where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__
                     = 4 + size (window_ChangeDeviceDontPropagateList x) +
                         size (num_classes_ChangeDeviceDontPropagateList x)
                         + size (undefined :: Word8)
                         + 1
                         + sum (map size (classes_ChangeDeviceDontPropagateList x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_ChangeDeviceDontPropagateList x)
               serialize (num_classes_ChangeDeviceDontPropagateList x)
               serialize (toValue (mode_ChangeDeviceDontPropagateList x) :: Word8)
               putSkip 1
               serializeList (classes_ChangeDeviceDontPropagateList x)
               putSkip (requiredPadding size__)
 
data GetDeviceDontPropagateList = MkGetDeviceDontPropagateList{window_GetDeviceDontPropagateList
                                                               :: WINDOW}
                                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceDontPropagateList where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 9
               let size__ = 4 + size (window_GetDeviceDontPropagateList x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetDeviceDontPropagateList x)
               putSkip (requiredPadding size__)
 
data GetDeviceDontPropagateListReply = MkGetDeviceDontPropagateListReply{num_classes_GetDeviceDontPropagateListReply
                                                                         :: Word16,
                                                                         classes_GetDeviceDontPropagateListReply
                                                                         :: [EventClass]}
                                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceDontPropagateListReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_classes <- deserialize
               skip 22
               classes <- deserializeList (fromIntegral num_classes)
               let _ = isCard32 length
               return (MkGetDeviceDontPropagateListReply num_classes classes)
 
data GetDeviceMotionEvents = MkGetDeviceMotionEvents{start_GetDeviceMotionEvents
                                                     :: TIMESTAMP,
                                                     stop_GetDeviceMotionEvents :: TIMESTAMP,
                                                     device_id_GetDeviceMotionEvents :: Word8}
                           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceMotionEvents where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 10
               let size__
                     = 4 + size (start_GetDeviceMotionEvents x) +
                         size (stop_GetDeviceMotionEvents x)
                         + size (device_id_GetDeviceMotionEvents x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (start_GetDeviceMotionEvents x)
               serialize (stop_GetDeviceMotionEvents x)
               serialize (device_id_GetDeviceMotionEvents x)
               putSkip (requiredPadding size__)
 
data GetDeviceMotionEventsReply = MkGetDeviceMotionEventsReply{num_coords_GetDeviceMotionEventsReply
                                                               :: Word32,
                                                               num_axes_GetDeviceMotionEventsReply
                                                               :: Word8,
                                                               device_mode_GetDeviceMotionEventsReply
                                                               :: ValuatorMode}
                                deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceMotionEventsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_coords <- deserialize
               num_axes <- deserialize
               device_mode <- liftM fromValue (deserialize :: Get Word8)
               skip 18
               let _ = isCard32 length
               return
                 (MkGetDeviceMotionEventsReply num_coords num_axes device_mode)
 
data DeviceTimeCoord = MkDeviceTimeCoord{time_DeviceTimeCoord ::
                                         TIMESTAMP}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceTimeCoord where
        serialize x = do serialize (time_DeviceTimeCoord x)
        size x = size (time_DeviceTimeCoord x)
 
instance Deserialize DeviceTimeCoord where
        deserialize
          = do time <- deserialize
               return (MkDeviceTimeCoord time)
 
data ChangeKeyboardDevice = MkChangeKeyboardDevice{device_id_ChangeKeyboardDevice
                                                   :: Word8}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeKeyboardDevice where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 11
               let size__ = 4 + size (device_id_ChangeKeyboardDevice x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_ChangeKeyboardDevice x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data ChangeKeyboardDeviceReply = MkChangeKeyboardDeviceReply{status_ChangeKeyboardDeviceReply
                                                             :: Word8}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ChangeKeyboardDeviceReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status <- deserialize
               skip 23
               let _ = isCard32 length
               return (MkChangeKeyboardDeviceReply status)
 
data ChangePointerDevice = MkChangePointerDevice{x_axis_ChangePointerDevice
                                                 :: Word8,
                                                 y_axis_ChangePointerDevice :: Word8,
                                                 device_id_ChangePointerDevice :: Word8}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangePointerDevice where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 12
               let size__
                     = 4 + size (x_axis_ChangePointerDevice x) +
                         size (y_axis_ChangePointerDevice x)
                         + size (device_id_ChangePointerDevice x)
                         + 1
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (x_axis_ChangePointerDevice x)
               serialize (y_axis_ChangePointerDevice x)
               serialize (device_id_ChangePointerDevice x)
               putSkip 1
               putSkip (requiredPadding size__)
 
data ChangePointerDeviceReply = MkChangePointerDeviceReply{status_ChangePointerDeviceReply
                                                           :: Word8}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize ChangePointerDeviceReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status <- deserialize
               skip 23
               let _ = isCard32 length
               return (MkChangePointerDeviceReply status)
 
data GrabDevice = MkGrabDevice{grab_window_GrabDevice :: WINDOW,
                               time_GrabDevice :: TIMESTAMP, num_classes_GrabDevice :: Word16,
                               this_device_mode_GrabDevice :: GrabMode,
                               other_device_mode_GrabDevice :: GrabMode,
                               owner_events_GrabDevice :: Bool, device_id_GrabDevice :: Word8,
                               classes_GrabDevice :: [EventClass]}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GrabDevice where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 13
               let size__
                     = 4 + size (grab_window_GrabDevice x) + size (time_GrabDevice x) +
                         size (num_classes_GrabDevice x)
                         + size (undefined :: Word8)
                         + size (undefined :: Word8)
                         + size (owner_events_GrabDevice x)
                         + size (device_id_GrabDevice x)
                         + 2
                         + sum (map size (classes_GrabDevice x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (grab_window_GrabDevice x)
               serialize (time_GrabDevice x)
               serialize (num_classes_GrabDevice x)
               serialize (toValue (this_device_mode_GrabDevice x) :: Word8)
               serialize (toValue (other_device_mode_GrabDevice x) :: Word8)
               serialize (owner_events_GrabDevice x)
               serialize (device_id_GrabDevice x)
               putSkip 2
               serializeList (classes_GrabDevice x)
               putSkip (requiredPadding size__)
 
data GrabDeviceReply = MkGrabDeviceReply{status_GrabDeviceReply ::
                                         GrabStatus}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GrabDeviceReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status <- liftM fromValue (deserialize :: Get Word8)
               skip 23
               let _ = isCard32 length
               return (MkGrabDeviceReply status)
 
data UngrabDevice = MkUngrabDevice{time_UngrabDevice :: TIMESTAMP,
                                   device_id_UngrabDevice :: Word8}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest UngrabDevice where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 14
               let size__
                     = 4 + size (time_UngrabDevice x) + size (device_id_UngrabDevice x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (time_UngrabDevice x)
               serialize (device_id_UngrabDevice x)
               putSkip (requiredPadding size__)
 
data GrabDeviceKey = MkGrabDeviceKey{grab_window_GrabDeviceKey ::
                                     WINDOW,
                                     num_classes_GrabDeviceKey :: Word16,
                                     modifiers_GrabDeviceKey :: [ModMask],
                                     modifier_device_GrabDeviceKey :: Word8,
                                     grabbed_device_GrabDeviceKey :: Word8,
                                     key_GrabDeviceKey :: Word8,
                                     this_device_mode_GrabDeviceKey :: GrabMode,
                                     other_device_mode_GrabDeviceKey :: GrabMode,
                                     owner_events_GrabDeviceKey :: Bool,
                                     classes_GrabDeviceKey :: [EventClass]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GrabDeviceKey where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 15
               let size__
                     = 4 + size (grab_window_GrabDeviceKey x) +
                         size (num_classes_GrabDeviceKey x)
                         + size (undefined :: Word16)
                         + size (modifier_device_GrabDeviceKey x)
                         + size (grabbed_device_GrabDeviceKey x)
                         + size (key_GrabDeviceKey x)
                         + size (undefined :: Word8)
                         + size (undefined :: Word8)
                         + size (owner_events_GrabDeviceKey x)
                         + 2
                         + sum (map size (classes_GrabDeviceKey x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (grab_window_GrabDeviceKey x)
               serialize (num_classes_GrabDeviceKey x)
               serialize (toMask (modifiers_GrabDeviceKey x) :: Word16)
               serialize (modifier_device_GrabDeviceKey x)
               serialize (grabbed_device_GrabDeviceKey x)
               serialize (key_GrabDeviceKey x)
               serialize (toValue (this_device_mode_GrabDeviceKey x) :: Word8)
               serialize (toValue (other_device_mode_GrabDeviceKey x) :: Word8)
               serialize (owner_events_GrabDeviceKey x)
               putSkip 2
               serializeList (classes_GrabDeviceKey x)
               putSkip (requiredPadding size__)
 
data UngrabDeviceKey = MkUngrabDeviceKey{grabWindow_UngrabDeviceKey
                                         :: WINDOW,
                                         modifiers_UngrabDeviceKey :: [ModMask],
                                         modifier_device_UngrabDeviceKey :: Word8,
                                         key_UngrabDeviceKey :: Word8,
                                         grabbed_device_UngrabDeviceKey :: Word8}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest UngrabDeviceKey where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 16
               let size__
                     = 4 + size (grabWindow_UngrabDeviceKey x) +
                         size (undefined :: Word16)
                         + size (modifier_device_UngrabDeviceKey x)
                         + size (key_UngrabDeviceKey x)
                         + size (grabbed_device_UngrabDeviceKey x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (grabWindow_UngrabDeviceKey x)
               serialize (toMask (modifiers_UngrabDeviceKey x) :: Word16)
               serialize (modifier_device_UngrabDeviceKey x)
               serialize (key_UngrabDeviceKey x)
               serialize (grabbed_device_UngrabDeviceKey x)
               putSkip (requiredPadding size__)
 
data GrabDeviceButton = MkGrabDeviceButton{grab_window_GrabDeviceButton
                                           :: WINDOW,
                                           grabbed_device_GrabDeviceButton :: Word8,
                                           modifier_device_GrabDeviceButton :: Word8,
                                           num_classes_GrabDeviceButton :: Word16,
                                           modifiers_GrabDeviceButton :: [ModMask],
                                           this_device_mode_GrabDeviceButton :: GrabMode,
                                           other_device_mode_GrabDeviceButton :: GrabMode,
                                           button_GrabDeviceButton :: Word8,
                                           owner_events_GrabDeviceButton :: Word8,
                                           classes_GrabDeviceButton :: [EventClass]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GrabDeviceButton where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 17
               let size__
                     = 4 + size (grab_window_GrabDeviceButton x) +
                         size (grabbed_device_GrabDeviceButton x)
                         + size (modifier_device_GrabDeviceButton x)
                         + size (num_classes_GrabDeviceButton x)
                         + size (undefined :: Word16)
                         + size (undefined :: Word8)
                         + size (undefined :: Word8)
                         + size (button_GrabDeviceButton x)
                         + size (owner_events_GrabDeviceButton x)
                         + 2
                         + sum (map size (classes_GrabDeviceButton x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (grab_window_GrabDeviceButton x)
               serialize (grabbed_device_GrabDeviceButton x)
               serialize (modifier_device_GrabDeviceButton x)
               serialize (num_classes_GrabDeviceButton x)
               serialize (toMask (modifiers_GrabDeviceButton x) :: Word16)
               serialize (toValue (this_device_mode_GrabDeviceButton x) :: Word8)
               serialize (toValue (other_device_mode_GrabDeviceButton x) :: Word8)
               serialize (button_GrabDeviceButton x)
               serialize (owner_events_GrabDeviceButton x)
               putSkip 2
               serializeList (classes_GrabDeviceButton x)
               putSkip (requiredPadding size__)
 
data UngrabDeviceButton = MkUngrabDeviceButton{grab_window_UngrabDeviceButton
                                               :: WINDOW,
                                               modifiers_UngrabDeviceButton :: [ModMask],
                                               modifier_device_UngrabDeviceButton :: Word8,
                                               button_UngrabDeviceButton :: Word8,
                                               grabbed_device_UngrabDeviceButton :: Word8}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest UngrabDeviceButton where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 18
               let size__
                     = 4 + size (grab_window_UngrabDeviceButton x) +
                         size (undefined :: Word16)
                         + size (modifier_device_UngrabDeviceButton x)
                         + size (button_UngrabDeviceButton x)
                         + size (grabbed_device_UngrabDeviceButton x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (grab_window_UngrabDeviceButton x)
               serialize (toMask (modifiers_UngrabDeviceButton x) :: Word16)
               serialize (modifier_device_UngrabDeviceButton x)
               serialize (button_UngrabDeviceButton x)
               serialize (grabbed_device_UngrabDeviceButton x)
               putSkip (requiredPadding size__)
 
data DeviceInputMode = DeviceInputModeAsyncThisDevice
                     | DeviceInputModeSyncThisDevice
                     | DeviceInputModeReplayThisDevice
                     | DeviceInputModeAsyncOtherDevices
                     | DeviceInputModeAsyncAll
                     | DeviceInputModeSyncAll
                     deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum DeviceInputMode where
        toValue DeviceInputModeAsyncThisDevice{} = 0
        toValue DeviceInputModeSyncThisDevice{} = 1
        toValue DeviceInputModeReplayThisDevice{} = 2
        toValue DeviceInputModeAsyncOtherDevices{} = 3
        toValue DeviceInputModeAsyncAll{} = 4
        toValue DeviceInputModeSyncAll{} = 5
        fromValue 0 = DeviceInputModeAsyncThisDevice
        fromValue 1 = DeviceInputModeSyncThisDevice
        fromValue 2 = DeviceInputModeReplayThisDevice
        fromValue 3 = DeviceInputModeAsyncOtherDevices
        fromValue 4 = DeviceInputModeAsyncAll
        fromValue 5 = DeviceInputModeSyncAll
 
data AllowDeviceEvents = MkAllowDeviceEvents{time_AllowDeviceEvents
                                             :: TIMESTAMP,
                                             mode_AllowDeviceEvents :: DeviceInputMode,
                                             device_id_AllowDeviceEvents :: Word8}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest AllowDeviceEvents where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 19
               let size__
                     = 4 + size (time_AllowDeviceEvents x) + size (undefined :: Word8) +
                         size (device_id_AllowDeviceEvents x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (time_AllowDeviceEvents x)
               serialize (toValue (mode_AllowDeviceEvents x) :: Word8)
               serialize (device_id_AllowDeviceEvents x)
               putSkip (requiredPadding size__)
 
data GetDeviceFocus = MkGetDeviceFocus{device_id_GetDeviceFocus ::
                                       Word8}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceFocus where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 20
               let size__ = 4 + size (device_id_GetDeviceFocus x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_GetDeviceFocus x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data GetDeviceFocusReply = MkGetDeviceFocusReply{focus_GetDeviceFocusReply
                                                 :: WINDOW,
                                                 time_GetDeviceFocusReply :: TIMESTAMP,
                                                 revert_to_GetDeviceFocusReply :: InputFocus}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceFocusReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               focus <- deserialize
               time <- deserialize
               revert_to <- liftM fromValue (deserialize :: Get Word8)
               skip 15
               let _ = isCard32 length
               return (MkGetDeviceFocusReply focus time revert_to)
 
data SetDeviceFocus = MkSetDeviceFocus{focus_SetDeviceFocus ::
                                       WINDOW,
                                       time_SetDeviceFocus :: TIMESTAMP,
                                       revert_to_SetDeviceFocus :: InputFocus,
                                       device_id_SetDeviceFocus :: Word8}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetDeviceFocus where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 21
               let size__
                     = 4 + size (focus_SetDeviceFocus x) + size (time_SetDeviceFocus x)
                         + size (undefined :: Word8)
                         + size (device_id_SetDeviceFocus x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (focus_SetDeviceFocus x)
               serialize (time_SetDeviceFocus x)
               serialize (toValue (revert_to_SetDeviceFocus x) :: Word8)
               serialize (device_id_SetDeviceFocus x)
               putSkip (requiredPadding size__)
 
data GetFeedbackControl = MkGetFeedbackControl{device_id_GetFeedbackControl
                                               :: Word8}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetFeedbackControl where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 22
               let size__ = 4 + size (device_id_GetFeedbackControl x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_GetFeedbackControl x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data GetFeedbackControlReply = MkGetFeedbackControlReply{num_feedback_GetFeedbackControlReply
                                                         :: Word16}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetFeedbackControlReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_feedback <- deserialize
               skip 22
               let _ = isCard32 length
               return (MkGetFeedbackControlReply num_feedback)
 
data FeedbackClass = FeedbackClassKeyboard
                   | FeedbackClassPointer
                   | FeedbackClassString
                   | FeedbackClassInteger
                   | FeedbackClassLed
                   | FeedbackClassBell
                   deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum FeedbackClass where
        toValue FeedbackClassKeyboard{} = 0
        toValue FeedbackClassPointer{} = 1
        toValue FeedbackClassString{} = 2
        toValue FeedbackClassInteger{} = 3
        toValue FeedbackClassLed{} = 4
        toValue FeedbackClassBell{} = 5
        fromValue 0 = FeedbackClassKeyboard
        fromValue 1 = FeedbackClassPointer
        fromValue 2 = FeedbackClassString
        fromValue 3 = FeedbackClassInteger
        fromValue 4 = FeedbackClassLed
        fromValue 5 = FeedbackClassBell
 
data FeedbackState = MkFeedbackState{class_id_FeedbackState ::
                                     FeedbackClass,
                                     id_FeedbackState :: Word8, len_FeedbackState :: Word16}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Serialize FeedbackState where
        serialize x
          = do serialize (toValue (class_id_FeedbackState x) :: Word8)
               serialize (id_FeedbackState x)
               serialize (len_FeedbackState x)
        size x
          = size (undefined :: Word8) + size (id_FeedbackState x) +
              size (len_FeedbackState x)
 
instance Deserialize FeedbackState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               return (MkFeedbackState class_id id len)
 
data KbdFeedbackState = MkKbdFeedbackState{class_id_KbdFeedbackState
                                           :: FeedbackClass,
                                           id_KbdFeedbackState :: Word8,
                                           len_KbdFeedbackState :: Word16,
                                           pitch_KbdFeedbackState :: Word16,
                                           duration_KbdFeedbackState :: Word16,
                                           led_mask_KbdFeedbackState :: Word32,
                                           led_values_KbdFeedbackState :: Word32,
                                           global_auto_repeat_KbdFeedbackState :: Bool,
                                           click_KbdFeedbackState :: Word8,
                                           percent_KbdFeedbackState :: Word8,
                                           auto_repeats_KbdFeedbackState :: [Word8]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Serialize KbdFeedbackState where
        serialize x
          = do serialize (toValue (class_id_KbdFeedbackState x) :: Word8)
               serialize (id_KbdFeedbackState x)
               serialize (len_KbdFeedbackState x)
               serialize (pitch_KbdFeedbackState x)
               serialize (duration_KbdFeedbackState x)
               serialize (led_mask_KbdFeedbackState x)
               serialize (led_values_KbdFeedbackState x)
               serialize (global_auto_repeat_KbdFeedbackState x)
               serialize (click_KbdFeedbackState x)
               serialize (percent_KbdFeedbackState x)
               putSkip 1
               serializeList (auto_repeats_KbdFeedbackState x)
        size x
          = size (undefined :: Word8) + size (id_KbdFeedbackState x) +
              size (len_KbdFeedbackState x)
              + size (pitch_KbdFeedbackState x)
              + size (duration_KbdFeedbackState x)
              + size (led_mask_KbdFeedbackState x)
              + size (led_values_KbdFeedbackState x)
              + size (global_auto_repeat_KbdFeedbackState x)
              + size (click_KbdFeedbackState x)
              + size (percent_KbdFeedbackState x)
              + 1
              + sum (map size (auto_repeats_KbdFeedbackState x))
 
instance Deserialize KbdFeedbackState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               pitch <- deserialize
               duration <- deserialize
               led_mask <- deserialize
               led_values <- deserialize
               global_auto_repeat <- deserialize
               click <- deserialize
               percent <- deserialize
               skip 1
               auto_repeats <- deserializeList (fromIntegral 32)
               return
                 (MkKbdFeedbackState class_id id len pitch duration led_mask
                    led_values
                    global_auto_repeat
                    click
                    percent
                    auto_repeats)
 
data PtrFeedbackState = MkPtrFeedbackState{class_id_PtrFeedbackState
                                           :: FeedbackClass,
                                           id_PtrFeedbackState :: Word8,
                                           len_PtrFeedbackState :: Word16,
                                           accel_num_PtrFeedbackState :: Word16,
                                           accel_denom_PtrFeedbackState :: Word16,
                                           threshold_PtrFeedbackState :: Word16}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Serialize PtrFeedbackState where
        serialize x
          = do serialize (toValue (class_id_PtrFeedbackState x) :: Word8)
               serialize (id_PtrFeedbackState x)
               serialize (len_PtrFeedbackState x)
               putSkip 2
               serialize (accel_num_PtrFeedbackState x)
               serialize (accel_denom_PtrFeedbackState x)
               serialize (threshold_PtrFeedbackState x)
        size x
          = size (undefined :: Word8) + size (id_PtrFeedbackState x) +
              size (len_PtrFeedbackState x)
              + 2
              + size (accel_num_PtrFeedbackState x)
              + size (accel_denom_PtrFeedbackState x)
              + size (threshold_PtrFeedbackState x)
 
instance Deserialize PtrFeedbackState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               skip 2
               accel_num <- deserialize
               accel_denom <- deserialize
               threshold <- deserialize
               return
                 (MkPtrFeedbackState class_id id len accel_num accel_denom
                    threshold)
 
data IntegerFeedbackState = MkIntegerFeedbackState{class_id_IntegerFeedbackState
                                                   :: FeedbackClass,
                                                   id_IntegerFeedbackState :: Word8,
                                                   len_IntegerFeedbackState :: Word16,
                                                   resolution_IntegerFeedbackState :: Word32,
                                                   min_value_IntegerFeedbackState :: Int32,
                                                   max_value_IntegerFeedbackState :: Int32}
                          deriving (Show, Typeable, Eq, Ord)
 
instance Serialize IntegerFeedbackState where
        serialize x
          = do serialize (toValue (class_id_IntegerFeedbackState x) :: Word8)
               serialize (id_IntegerFeedbackState x)
               serialize (len_IntegerFeedbackState x)
               serialize (resolution_IntegerFeedbackState x)
               serialize (min_value_IntegerFeedbackState x)
               serialize (max_value_IntegerFeedbackState x)
        size x
          = size (undefined :: Word8) + size (id_IntegerFeedbackState x) +
              size (len_IntegerFeedbackState x)
              + size (resolution_IntegerFeedbackState x)
              + size (min_value_IntegerFeedbackState x)
              + size (max_value_IntegerFeedbackState x)
 
instance Deserialize IntegerFeedbackState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               resolution <- deserialize
               min_value <- deserialize
               max_value <- deserialize
               return
                 (MkIntegerFeedbackState class_id id len resolution min_value
                    max_value)
 
data StringFeedbackState = MkStringFeedbackState{class_id_StringFeedbackState
                                                 :: FeedbackClass,
                                                 id_StringFeedbackState :: Word8,
                                                 len_StringFeedbackState :: Word16,
                                                 max_symbols_StringFeedbackState :: Word16,
                                                 num_keysyms_StringFeedbackState :: Word16,
                                                 keysyms_StringFeedbackState :: [KEYSYM]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Serialize StringFeedbackState where
        serialize x
          = do serialize (toValue (class_id_StringFeedbackState x) :: Word8)
               serialize (id_StringFeedbackState x)
               serialize (len_StringFeedbackState x)
               serialize (max_symbols_StringFeedbackState x)
               serialize (num_keysyms_StringFeedbackState x)
               serializeList (keysyms_StringFeedbackState x)
        size x
          = size (undefined :: Word8) + size (id_StringFeedbackState x) +
              size (len_StringFeedbackState x)
              + size (max_symbols_StringFeedbackState x)
              + size (num_keysyms_StringFeedbackState x)
              + sum (map size (keysyms_StringFeedbackState x))
 
instance Deserialize StringFeedbackState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               max_symbols <- deserialize
               num_keysyms <- deserialize
               keysyms <- deserializeList (fromIntegral num_keysyms)
               return
                 (MkStringFeedbackState class_id id len max_symbols num_keysyms
                    keysyms)
 
data BellFeedbackState = MkBellFeedbackState{class_id_BellFeedbackState
                                             :: FeedbackClass,
                                             id_BellFeedbackState :: Word8,
                                             len_BellFeedbackState :: Word16,
                                             percent_BellFeedbackState :: Word8,
                                             pitch_BellFeedbackState :: Word16,
                                             duration_BellFeedbackState :: Word16}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Serialize BellFeedbackState where
        serialize x
          = do serialize (toValue (class_id_BellFeedbackState x) :: Word8)
               serialize (id_BellFeedbackState x)
               serialize (len_BellFeedbackState x)
               serialize (percent_BellFeedbackState x)
               putSkip 3
               serialize (pitch_BellFeedbackState x)
               serialize (duration_BellFeedbackState x)
        size x
          = size (undefined :: Word8) + size (id_BellFeedbackState x) +
              size (len_BellFeedbackState x)
              + size (percent_BellFeedbackState x)
              + 3
              + size (pitch_BellFeedbackState x)
              + size (duration_BellFeedbackState x)
 
instance Deserialize BellFeedbackState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               percent <- deserialize
               skip 3
               pitch <- deserialize
               duration <- deserialize
               return (MkBellFeedbackState class_id id len percent pitch duration)
 
data LedFeedbackState = MkLedFeedbackState{class_id_LedFeedbackState
                                           :: FeedbackClass,
                                           id_LedFeedbackState :: Word8,
                                           len_LedFeedbackState :: Word16,
                                           led_mask_LedFeedbackState :: Word32,
                                           led_values_LedFeedbackState :: Word32}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Serialize LedFeedbackState where
        serialize x
          = do serialize (toValue (class_id_LedFeedbackState x) :: Word8)
               serialize (id_LedFeedbackState x)
               serialize (len_LedFeedbackState x)
               serialize (led_mask_LedFeedbackState x)
               serialize (led_values_LedFeedbackState x)
        size x
          = size (undefined :: Word8) + size (id_LedFeedbackState x) +
              size (len_LedFeedbackState x)
              + size (led_mask_LedFeedbackState x)
              + size (led_values_LedFeedbackState x)
 
instance Deserialize LedFeedbackState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               led_mask <- deserialize
               led_values <- deserialize
               return (MkLedFeedbackState class_id id len led_mask led_values)
 
data FeedbackCtl = MkFeedbackCtl{class_id_FeedbackCtl ::
                                 FeedbackClass,
                                 id_FeedbackCtl :: Word8, len_FeedbackCtl :: Word16}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Serialize FeedbackCtl where
        serialize x
          = do serialize (toValue (class_id_FeedbackCtl x) :: Word8)
               serialize (id_FeedbackCtl x)
               serialize (len_FeedbackCtl x)
        size x
          = size (undefined :: Word8) + size (id_FeedbackCtl x) +
              size (len_FeedbackCtl x)
 
instance Deserialize FeedbackCtl where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               return (MkFeedbackCtl class_id id len)
 
data KbdFeedbackCtl = MkKbdFeedbackCtl{class_id_KbdFeedbackCtl ::
                                       FeedbackClass,
                                       id_KbdFeedbackCtl :: Word8, len_KbdFeedbackCtl :: Word16,
                                       key_KbdFeedbackCtl :: KeyCode,
                                       auto_repeat_mode_KbdFeedbackCtl :: Word8,
                                       key_click_percent_KbdFeedbackCtl :: Int8,
                                       bell_percent_KbdFeedbackCtl :: Int8,
                                       bell_pitch_KbdFeedbackCtl :: Int16,
                                       bell_duration_KbdFeedbackCtl :: Int16,
                                       led_mask_KbdFeedbackCtl :: Word32,
                                       led_values_KbdFeedbackCtl :: Word32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Serialize KbdFeedbackCtl where
        serialize x
          = do serialize (toValue (class_id_KbdFeedbackCtl x) :: Word8)
               serialize (id_KbdFeedbackCtl x)
               serialize (len_KbdFeedbackCtl x)
               serialize (key_KbdFeedbackCtl x)
               serialize (auto_repeat_mode_KbdFeedbackCtl x)
               serialize (key_click_percent_KbdFeedbackCtl x)
               serialize (bell_percent_KbdFeedbackCtl x)
               serialize (bell_pitch_KbdFeedbackCtl x)
               serialize (bell_duration_KbdFeedbackCtl x)
               serialize (led_mask_KbdFeedbackCtl x)
               serialize (led_values_KbdFeedbackCtl x)
        size x
          = size (undefined :: Word8) + size (id_KbdFeedbackCtl x) +
              size (len_KbdFeedbackCtl x)
              + size (key_KbdFeedbackCtl x)
              + size (auto_repeat_mode_KbdFeedbackCtl x)
              + size (key_click_percent_KbdFeedbackCtl x)
              + size (bell_percent_KbdFeedbackCtl x)
              + size (bell_pitch_KbdFeedbackCtl x)
              + size (bell_duration_KbdFeedbackCtl x)
              + size (led_mask_KbdFeedbackCtl x)
              + size (led_values_KbdFeedbackCtl x)
 
instance Deserialize KbdFeedbackCtl where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               key <- deserialize
               auto_repeat_mode <- deserialize
               key_click_percent <- deserialize
               bell_percent <- deserialize
               bell_pitch <- deserialize
               bell_duration <- deserialize
               led_mask <- deserialize
               led_values <- deserialize
               return
                 (MkKbdFeedbackCtl class_id id len key auto_repeat_mode
                    key_click_percent
                    bell_percent
                    bell_pitch
                    bell_duration
                    led_mask
                    led_values)
 
data PtrFeedbackCtl = MkPtrFeedbackCtl{class_id_PtrFeedbackCtl ::
                                       FeedbackClass,
                                       id_PtrFeedbackCtl :: Word8, len_PtrFeedbackCtl :: Word16,
                                       num_PtrFeedbackCtl :: Int16, denom_PtrFeedbackCtl :: Int16,
                                       threshold_PtrFeedbackCtl :: Int16}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Serialize PtrFeedbackCtl where
        serialize x
          = do serialize (toValue (class_id_PtrFeedbackCtl x) :: Word8)
               serialize (id_PtrFeedbackCtl x)
               serialize (len_PtrFeedbackCtl x)
               putSkip 2
               serialize (num_PtrFeedbackCtl x)
               serialize (denom_PtrFeedbackCtl x)
               serialize (threshold_PtrFeedbackCtl x)
        size x
          = size (undefined :: Word8) + size (id_PtrFeedbackCtl x) +
              size (len_PtrFeedbackCtl x)
              + 2
              + size (num_PtrFeedbackCtl x)
              + size (denom_PtrFeedbackCtl x)
              + size (threshold_PtrFeedbackCtl x)
 
instance Deserialize PtrFeedbackCtl where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               skip 2
               num <- deserialize
               denom <- deserialize
               threshold <- deserialize
               return (MkPtrFeedbackCtl class_id id len num denom threshold)
 
data IntegerFeedbackCtl = MkIntegerFeedbackCtl{class_id_IntegerFeedbackCtl
                                               :: FeedbackClass,
                                               id_IntegerFeedbackCtl :: Word8,
                                               len_IntegerFeedbackCtl :: Word16,
                                               int_to_display_IntegerFeedbackCtl :: Int32}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Serialize IntegerFeedbackCtl where
        serialize x
          = do serialize (toValue (class_id_IntegerFeedbackCtl x) :: Word8)
               serialize (id_IntegerFeedbackCtl x)
               serialize (len_IntegerFeedbackCtl x)
               serialize (int_to_display_IntegerFeedbackCtl x)
        size x
          = size (undefined :: Word8) + size (id_IntegerFeedbackCtl x) +
              size (len_IntegerFeedbackCtl x)
              + size (int_to_display_IntegerFeedbackCtl x)
 
instance Deserialize IntegerFeedbackCtl where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               int_to_display <- deserialize
               return (MkIntegerFeedbackCtl class_id id len int_to_display)
 
data StringFeedbackCtl = MkStringFeedbackCtl{class_id_StringFeedbackCtl
                                             :: FeedbackClass,
                                             id_StringFeedbackCtl :: Word8,
                                             len_StringFeedbackCtl :: Word16,
                                             num_keysyms_StringFeedbackCtl :: Word16,
                                             keysyms_StringFeedbackCtl :: [KEYSYM]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Serialize StringFeedbackCtl where
        serialize x
          = do serialize (toValue (class_id_StringFeedbackCtl x) :: Word8)
               serialize (id_StringFeedbackCtl x)
               serialize (len_StringFeedbackCtl x)
               putSkip 2
               serialize (num_keysyms_StringFeedbackCtl x)
               serializeList (keysyms_StringFeedbackCtl x)
        size x
          = size (undefined :: Word8) + size (id_StringFeedbackCtl x) +
              size (len_StringFeedbackCtl x)
              + 2
              + size (num_keysyms_StringFeedbackCtl x)
              + sum (map size (keysyms_StringFeedbackCtl x))
 
instance Deserialize StringFeedbackCtl where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               skip 2
               num_keysyms <- deserialize
               keysyms <- deserializeList (fromIntegral num_keysyms)
               return (MkStringFeedbackCtl class_id id len num_keysyms keysyms)
 
data BellFeedbackCtl = MkBellFeedbackCtl{class_id_BellFeedbackCtl
                                         :: FeedbackClass,
                                         id_BellFeedbackCtl :: Word8, len_BellFeedbackCtl :: Word16,
                                         percent_BellFeedbackCtl :: Int8,
                                         pitch_BellFeedbackCtl :: Int16,
                                         duration_BellFeedbackCtl :: Int16}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Serialize BellFeedbackCtl where
        serialize x
          = do serialize (toValue (class_id_BellFeedbackCtl x) :: Word8)
               serialize (id_BellFeedbackCtl x)
               serialize (len_BellFeedbackCtl x)
               serialize (percent_BellFeedbackCtl x)
               putSkip 3
               serialize (pitch_BellFeedbackCtl x)
               serialize (duration_BellFeedbackCtl x)
        size x
          = size (undefined :: Word8) + size (id_BellFeedbackCtl x) +
              size (len_BellFeedbackCtl x)
              + size (percent_BellFeedbackCtl x)
              + 3
              + size (pitch_BellFeedbackCtl x)
              + size (duration_BellFeedbackCtl x)
 
instance Deserialize BellFeedbackCtl where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               percent <- deserialize
               skip 3
               pitch <- deserialize
               duration <- deserialize
               return (MkBellFeedbackCtl class_id id len percent pitch duration)
 
data LedFeedbackCtl = MkLedFeedbackCtl{class_id_LedFeedbackCtl ::
                                       FeedbackClass,
                                       id_LedFeedbackCtl :: Word8, len_LedFeedbackCtl :: Word16,
                                       led_mask_LedFeedbackCtl :: Word32,
                                       led_values_LedFeedbackCtl :: Word32}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Serialize LedFeedbackCtl where
        serialize x
          = do serialize (toValue (class_id_LedFeedbackCtl x) :: Word8)
               serialize (id_LedFeedbackCtl x)
               serialize (len_LedFeedbackCtl x)
               serialize (led_mask_LedFeedbackCtl x)
               serialize (led_values_LedFeedbackCtl x)
        size x
          = size (undefined :: Word8) + size (id_LedFeedbackCtl x) +
              size (len_LedFeedbackCtl x)
              + size (led_mask_LedFeedbackCtl x)
              + size (led_values_LedFeedbackCtl x)
 
instance Deserialize LedFeedbackCtl where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               id <- deserialize
               len <- deserialize
               led_mask <- deserialize
               led_values <- deserialize
               return (MkLedFeedbackCtl class_id id len led_mask led_values)
 
data GetDeviceKeyMapping = MkGetDeviceKeyMapping{device_id_GetDeviceKeyMapping
                                                 :: Word8,
                                                 first_keycode_GetDeviceKeyMapping :: KeyCode,
                                                 count_GetDeviceKeyMapping :: Word8}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceKeyMapping where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 24
               let size__
                     = 4 + size (device_id_GetDeviceKeyMapping x) +
                         size (first_keycode_GetDeviceKeyMapping x)
                         + size (count_GetDeviceKeyMapping x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_GetDeviceKeyMapping x)
               serialize (first_keycode_GetDeviceKeyMapping x)
               serialize (count_GetDeviceKeyMapping x)
               putSkip (requiredPadding size__)
 
data GetDeviceKeyMappingReply = MkGetDeviceKeyMappingReply{keysyms_per_keycode_GetDeviceKeyMappingReply
                                                           :: Word8,
                                                           keysyms_GetDeviceKeyMappingReply ::
                                                           [KEYSYM]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceKeyMappingReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               keysyms_per_keycode <- deserialize
               skip 23
               keysyms <- deserializeList (fromIntegral length)
               let _ = isCard32 length
               return (MkGetDeviceKeyMappingReply keysyms_per_keycode keysyms)
 
data ChangeDeviceKeyMapping = MkChangeDeviceKeyMapping{device_id_ChangeDeviceKeyMapping
                                                       :: Word8,
                                                       first_keycode_ChangeDeviceKeyMapping ::
                                                       KeyCode,
                                                       keysyms_per_keycode_ChangeDeviceKeyMapping ::
                                                       Word8,
                                                       keycode_count_ChangeDeviceKeyMapping ::
                                                       Word8,
                                                       keysyms_ChangeDeviceKeyMapping :: [KEYSYM]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeDeviceKeyMapping where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 25
               let size__
                     = 4 + size (device_id_ChangeDeviceKeyMapping x) +
                         size (first_keycode_ChangeDeviceKeyMapping x)
                         + size (keysyms_per_keycode_ChangeDeviceKeyMapping x)
                         + size (keycode_count_ChangeDeviceKeyMapping x)
                         + sum (map size (keysyms_ChangeDeviceKeyMapping x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_ChangeDeviceKeyMapping x)
               serialize (first_keycode_ChangeDeviceKeyMapping x)
               serialize (keysyms_per_keycode_ChangeDeviceKeyMapping x)
               serialize (keycode_count_ChangeDeviceKeyMapping x)
               serializeList (keysyms_ChangeDeviceKeyMapping x)
               putSkip (requiredPadding size__)
 
data GetDeviceModifierMapping = MkGetDeviceModifierMapping{device_id_GetDeviceModifierMapping
                                                           :: Word8}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceModifierMapping where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 26
               let size__ = 4 + size (device_id_GetDeviceModifierMapping x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_GetDeviceModifierMapping x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data GetDeviceModifierMappingReply = MkGetDeviceModifierMappingReply{keycodes_per_modifier_GetDeviceModifierMappingReply
                                                                     :: Word8,
                                                                     keymaps_GetDeviceModifierMappingReply
                                                                     :: [Word8]}
                                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceModifierMappingReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               keycodes_per_modifier <- deserialize
               skip 23
               keymaps <- deserializeList
                            (fromIntegral (fromIntegral (keycodes_per_modifier * 8)))
               let _ = isCard32 length
               return
                 (MkGetDeviceModifierMappingReply keycodes_per_modifier keymaps)
 
data SetDeviceModifierMapping = MkSetDeviceModifierMapping{device_id_SetDeviceModifierMapping
                                                           :: Word8,
                                                           keycodes_per_modifier_SetDeviceModifierMapping
                                                           :: Word8,
                                                           keymaps_SetDeviceModifierMapping ::
                                                           [Word8]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetDeviceModifierMapping where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 27
               let size__
                     = 4 + size (device_id_SetDeviceModifierMapping x) +
                         size (keycodes_per_modifier_SetDeviceModifierMapping x)
                         + 1
                         + sum (map size (keymaps_SetDeviceModifierMapping x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_SetDeviceModifierMapping x)
               serialize (keycodes_per_modifier_SetDeviceModifierMapping x)
               putSkip 1
               serializeList (keymaps_SetDeviceModifierMapping x)
               putSkip (requiredPadding size__)
 
data SetDeviceModifierMappingReply = MkSetDeviceModifierMappingReply{status_SetDeviceModifierMappingReply
                                                                     :: MappingStatus}
                                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize SetDeviceModifierMappingReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status <- liftM fromValue (deserialize :: Get Word8)
               skip 23
               let _ = isCard32 length
               return (MkSetDeviceModifierMappingReply status)
 
data GetDeviceButtonMapping = MkGetDeviceButtonMapping{device_id_GetDeviceButtonMapping
                                                       :: Word8}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceButtonMapping where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 28
               let size__ = 4 + size (device_id_GetDeviceButtonMapping x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_GetDeviceButtonMapping x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data GetDeviceButtonMappingReply = MkGetDeviceButtonMappingReply{map_size_GetDeviceButtonMappingReply
                                                                 :: Word8,
                                                                 map_GetDeviceButtonMappingReply ::
                                                                 [Word8]}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceButtonMappingReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               map_size <- deserialize
               skip 23
               map <- deserializeList (fromIntegral map_size)
               let _ = isCard32 length
               return (MkGetDeviceButtonMappingReply map_size map)
 
data SetDeviceButtonMapping = MkSetDeviceButtonMapping{device_id_SetDeviceButtonMapping
                                                       :: Word8,
                                                       map_size_SetDeviceButtonMapping :: Word8,
                                                       map_SetDeviceButtonMapping :: [Word8]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetDeviceButtonMapping where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 29
               let size__
                     = 4 + size (device_id_SetDeviceButtonMapping x) +
                         size (map_size_SetDeviceButtonMapping x)
                         + 2
                         + sum (map size (map_SetDeviceButtonMapping x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_SetDeviceButtonMapping x)
               serialize (map_size_SetDeviceButtonMapping x)
               putSkip 2
               serializeList (map_SetDeviceButtonMapping x)
               putSkip (requiredPadding size__)
 
data SetDeviceButtonMappingReply = MkSetDeviceButtonMappingReply{status_SetDeviceButtonMappingReply
                                                                 :: MappingStatus}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize SetDeviceButtonMappingReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status <- liftM fromValue (deserialize :: Get Word8)
               skip 23
               let _ = isCard32 length
               return (MkSetDeviceButtonMappingReply status)
 
data QueryDeviceState = MkQueryDeviceState{device_id_QueryDeviceState
                                           :: Word8}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryDeviceState where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 30
               let size__ = 4 + size (device_id_QueryDeviceState x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_QueryDeviceState x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data QueryDeviceStateReply = MkQueryDeviceStateReply{num_classes_QueryDeviceStateReply
                                                     :: Word8}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryDeviceStateReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_classes <- deserialize
               skip 23
               let _ = isCard32 length
               return (MkQueryDeviceStateReply num_classes)
 
data InputState = MkInputState{class_id_InputState :: InputClass,
                               len_InputState :: Word8, num_items_InputState :: Word8}
                deriving (Show, Typeable, Eq, Ord)
 
instance Serialize InputState where
        serialize x
          = do serialize (toValue (class_id_InputState x) :: Word8)
               serialize (len_InputState x)
               serialize (num_items_InputState x)
        size x
          = size (undefined :: Word8) + size (len_InputState x) +
              size (num_items_InputState x)
 
instance Deserialize InputState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               len <- deserialize
               num_items <- deserialize
               return (MkInputState class_id len num_items)
 
data KeyState = MkKeyState{class_id_KeyState :: InputClass,
                           len_KeyState :: Word8, num_keys_KeyState :: Word8,
                           keys_KeyState :: [Word8]}
              deriving (Show, Typeable, Eq, Ord)
 
instance Serialize KeyState where
        serialize x
          = do serialize (toValue (class_id_KeyState x) :: Word8)
               serialize (len_KeyState x)
               serialize (num_keys_KeyState x)
               putSkip 1
               serializeList (keys_KeyState x)
        size x
          = size (undefined :: Word8) + size (len_KeyState x) +
              size (num_keys_KeyState x)
              + 1
              + sum (map size (keys_KeyState x))
 
instance Deserialize KeyState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               len <- deserialize
               num_keys <- deserialize
               skip 1
               keys <- deserializeList (fromIntegral 32)
               return (MkKeyState class_id len num_keys keys)
 
data ButtonState = MkButtonState{class_id_ButtonState ::
                                 InputClass,
                                 len_ButtonState :: Word8, num_buttons_ButtonState :: Word8,
                                 buttons_ButtonState :: [Word8]}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Serialize ButtonState where
        serialize x
          = do serialize (toValue (class_id_ButtonState x) :: Word8)
               serialize (len_ButtonState x)
               serialize (num_buttons_ButtonState x)
               putSkip 1
               serializeList (buttons_ButtonState x)
        size x
          = size (undefined :: Word8) + size (len_ButtonState x) +
              size (num_buttons_ButtonState x)
              + 1
              + sum (map size (buttons_ButtonState x))
 
instance Deserialize ButtonState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               len <- deserialize
               num_buttons <- deserialize
               skip 1
               buttons <- deserializeList (fromIntegral 32)
               return (MkButtonState class_id len num_buttons buttons)
 
data ValuatorState = MkValuatorState{class_id_ValuatorState ::
                                     InputClass,
                                     len_ValuatorState :: Word8,
                                     num_valuators_ValuatorState :: Word8,
                                     mode_ValuatorState :: Word8,
                                     valuators_ValuatorState :: [Word32]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Serialize ValuatorState where
        serialize x
          = do serialize (toValue (class_id_ValuatorState x) :: Word8)
               serialize (len_ValuatorState x)
               serialize (num_valuators_ValuatorState x)
               serialize (mode_ValuatorState x)
               serializeList (valuators_ValuatorState x)
        size x
          = size (undefined :: Word8) + size (len_ValuatorState x) +
              size (num_valuators_ValuatorState x)
              + size (mode_ValuatorState x)
              + sum (map size (valuators_ValuatorState x))
 
instance Deserialize ValuatorState where
        deserialize
          = do class_id <- liftM fromValue (deserialize :: Get Word8)
               len <- deserialize
               num_valuators <- deserialize
               mode <- deserialize
               valuators <- deserializeList (fromIntegral num_valuators)
               return (MkValuatorState class_id len num_valuators mode valuators)
 
data SendExtensionEvent = MkSendExtensionEvent{destination_SendExtensionEvent
                                               :: WINDOW,
                                               device_id_SendExtensionEvent :: Word8,
                                               propagate_SendExtensionEvent :: Bool,
                                               num_classes_SendExtensionEvent :: Word16,
                                               num_events_SendExtensionEvent :: Word8,
                                               events_SendExtensionEvent :: [CChar],
                                               classes_SendExtensionEvent :: [EventClass]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SendExtensionEvent where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 31
               let size__
                     = 4 + size (destination_SendExtensionEvent x) +
                         size (device_id_SendExtensionEvent x)
                         + size (propagate_SendExtensionEvent x)
                         + size (num_classes_SendExtensionEvent x)
                         + size (num_events_SendExtensionEvent x)
                         + 3
                         + sum (map size (events_SendExtensionEvent x))
                         + sum (map size (classes_SendExtensionEvent x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (destination_SendExtensionEvent x)
               serialize (device_id_SendExtensionEvent x)
               serialize (propagate_SendExtensionEvent x)
               serialize (num_classes_SendExtensionEvent x)
               serialize (num_events_SendExtensionEvent x)
               putSkip 3
               serializeList (events_SendExtensionEvent x)
               serializeList (classes_SendExtensionEvent x)
               putSkip (requiredPadding size__)
 
data DeviceBell = MkDeviceBell{device_id_DeviceBell :: Word8,
                               feedback_id_DeviceBell :: Word8,
                               feedback_class_DeviceBell :: Word8, percent_DeviceBell :: Int8}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DeviceBell where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 32
               let size__
                     = 4 + size (device_id_DeviceBell x) +
                         size (feedback_id_DeviceBell x)
                         + size (feedback_class_DeviceBell x)
                         + size (percent_DeviceBell x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_DeviceBell x)
               serialize (feedback_id_DeviceBell x)
               serialize (feedback_class_DeviceBell x)
               serialize (percent_DeviceBell x)
               putSkip (requiredPadding size__)
 
data SetDeviceValuators = MkSetDeviceValuators{device_id_SetDeviceValuators
                                               :: Word8,
                                               first_valuator_SetDeviceValuators :: Word8,
                                               num_valuators_SetDeviceValuators :: Word8,
                                               valuators_SetDeviceValuators :: [Int32]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetDeviceValuators where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 33
               let size__
                     = 4 + size (device_id_SetDeviceValuators x) +
                         size (first_valuator_SetDeviceValuators x)
                         + size (num_valuators_SetDeviceValuators x)
                         + 1
                         + sum (map size (valuators_SetDeviceValuators x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (device_id_SetDeviceValuators x)
               serialize (first_valuator_SetDeviceValuators x)
               serialize (num_valuators_SetDeviceValuators x)
               putSkip 1
               serializeList (valuators_SetDeviceValuators x)
               putSkip (requiredPadding size__)
 
data SetDeviceValuatorsReply = MkSetDeviceValuatorsReply{status_SetDeviceValuatorsReply
                                                         :: GrabStatus}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize SetDeviceValuatorsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status <- liftM fromValue (deserialize :: Get Word8)
               skip 23
               let _ = isCard32 length
               return (MkSetDeviceValuatorsReply status)
 
data GetDeviceControl = MkGetDeviceControl{control_id_GetDeviceControl
                                           :: Word16,
                                           device_id_GetDeviceControl :: Word8}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetDeviceControl where
        extensionId _ = "XInputExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 34
               let size__
                     = 4 + size (control_id_GetDeviceControl x) +
                         size (device_id_GetDeviceControl x)
                         + 1
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (control_id_GetDeviceControl x)
               serialize (device_id_GetDeviceControl x)
               putSkip 1
               putSkip (requiredPadding size__)
 
data GetDeviceControlReply = MkGetDeviceControlReply{status_GetDeviceControlReply
                                                     :: Word8}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetDeviceControlReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status <- deserialize
               skip 23
               let _ = isCard32 length
               return (MkGetDeviceControlReply status)
 
data DeviceState = MkDeviceState{control_id_DeviceState :: Word16,
                                 len_DeviceState :: Word16}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceState where
        serialize x
          = do serialize (control_id_DeviceState x)
               serialize (len_DeviceState x)
        size x = size (control_id_DeviceState x) + size (len_DeviceState x)
 
instance Deserialize DeviceState where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               return (MkDeviceState control_id len)
 
data DeviceResolutionState = MkDeviceResolutionState{control_id_DeviceResolutionState
                                                     :: Word16,
                                                     len_DeviceResolutionState :: Word16,
                                                     num_valuators_DeviceResolutionState :: Word32,
                                                     resolution_values_DeviceResolutionState ::
                                                     [Word32],
                                                     resolution_min_DeviceResolutionState ::
                                                     [Word32],
                                                     resolution_max_DeviceResolutionState ::
                                                     [Word32]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceResolutionState where
        serialize x
          = do serialize (control_id_DeviceResolutionState x)
               serialize (len_DeviceResolutionState x)
               serialize (num_valuators_DeviceResolutionState x)
               serializeList (resolution_values_DeviceResolutionState x)
               serializeList (resolution_min_DeviceResolutionState x)
               serializeList (resolution_max_DeviceResolutionState x)
        size x
          = size (control_id_DeviceResolutionState x) +
              size (len_DeviceResolutionState x)
              + size (num_valuators_DeviceResolutionState x)
              + sum (map size (resolution_values_DeviceResolutionState x))
              + sum (map size (resolution_min_DeviceResolutionState x))
              + sum (map size (resolution_max_DeviceResolutionState x))
 
instance Deserialize DeviceResolutionState where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               num_valuators <- deserialize
               resolution_values <- deserializeList (fromIntegral num_valuators)
               resolution_min <- deserializeList (fromIntegral num_valuators)
               resolution_max <- deserializeList (fromIntegral num_valuators)
               return
                 (MkDeviceResolutionState control_id len num_valuators
                    resolution_values
                    resolution_min
                    resolution_max)
 
data DeviceAbsCalibState = MkDeviceAbsCalibState{control_id_DeviceAbsCalibState
                                                 :: Word16,
                                                 len_DeviceAbsCalibState :: Word16,
                                                 min_x_DeviceAbsCalibState :: Int32,
                                                 max_x_DeviceAbsCalibState :: Int32,
                                                 min_y_DeviceAbsCalibState :: Int32,
                                                 max_y_DeviceAbsCalibState :: Int32,
                                                 flip_x_DeviceAbsCalibState :: Word32,
                                                 flip_y_DeviceAbsCalibState :: Word32,
                                                 rotation_DeviceAbsCalibState :: Word32,
                                                 button_threshold_DeviceAbsCalibState :: Word32}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceAbsCalibState where
        serialize x
          = do serialize (control_id_DeviceAbsCalibState x)
               serialize (len_DeviceAbsCalibState x)
               serialize (min_x_DeviceAbsCalibState x)
               serialize (max_x_DeviceAbsCalibState x)
               serialize (min_y_DeviceAbsCalibState x)
               serialize (max_y_DeviceAbsCalibState x)
               serialize (flip_x_DeviceAbsCalibState x)
               serialize (flip_y_DeviceAbsCalibState x)
               serialize (rotation_DeviceAbsCalibState x)
               serialize (button_threshold_DeviceAbsCalibState x)
        size x
          = size (control_id_DeviceAbsCalibState x) +
              size (len_DeviceAbsCalibState x)
              + size (min_x_DeviceAbsCalibState x)
              + size (max_x_DeviceAbsCalibState x)
              + size (min_y_DeviceAbsCalibState x)
              + size (max_y_DeviceAbsCalibState x)
              + size (flip_x_DeviceAbsCalibState x)
              + size (flip_y_DeviceAbsCalibState x)
              + size (rotation_DeviceAbsCalibState x)
              + size (button_threshold_DeviceAbsCalibState x)
 
instance Deserialize DeviceAbsCalibState where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               min_x <- deserialize
               max_x <- deserialize
               min_y <- deserialize
               max_y <- deserialize
               flip_x <- deserialize
               flip_y <- deserialize
               rotation <- deserialize
               button_threshold <- deserialize
               return
                 (MkDeviceAbsCalibState control_id len min_x max_x min_y max_y
                    flip_x
                    flip_y
                    rotation
                    button_threshold)
 
data DeviceAbsAreaState = MkDeviceAbsAreaState{control_id_DeviceAbsAreaState
                                               :: Word16,
                                               len_DeviceAbsAreaState :: Word16,
                                               offset_x_DeviceAbsAreaState :: Word32,
                                               offset_y_DeviceAbsAreaState :: Word32,
                                               width_DeviceAbsAreaState :: Word32,
                                               height_DeviceAbsAreaState :: Word32,
                                               screen_DeviceAbsAreaState :: Word32,
                                               following_DeviceAbsAreaState :: Word32}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceAbsAreaState where
        serialize x
          = do serialize (control_id_DeviceAbsAreaState x)
               serialize (len_DeviceAbsAreaState x)
               serialize (offset_x_DeviceAbsAreaState x)
               serialize (offset_y_DeviceAbsAreaState x)
               serialize (width_DeviceAbsAreaState x)
               serialize (height_DeviceAbsAreaState x)
               serialize (screen_DeviceAbsAreaState x)
               serialize (following_DeviceAbsAreaState x)
        size x
          = size (control_id_DeviceAbsAreaState x) +
              size (len_DeviceAbsAreaState x)
              + size (offset_x_DeviceAbsAreaState x)
              + size (offset_y_DeviceAbsAreaState x)
              + size (width_DeviceAbsAreaState x)
              + size (height_DeviceAbsAreaState x)
              + size (screen_DeviceAbsAreaState x)
              + size (following_DeviceAbsAreaState x)
 
instance Deserialize DeviceAbsAreaState where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               offset_x <- deserialize
               offset_y <- deserialize
               width <- deserialize
               height <- deserialize
               screen <- deserialize
               following <- deserialize
               return
                 (MkDeviceAbsAreaState control_id len offset_x offset_y width height
                    screen
                    following)
 
data DeviceCoreState = MkDeviceCoreState{control_id_DeviceCoreState
                                         :: Word16,
                                         len_DeviceCoreState :: Word16,
                                         status_DeviceCoreState :: Word8,
                                         iscore_DeviceCoreState :: Word8}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceCoreState where
        serialize x
          = do serialize (control_id_DeviceCoreState x)
               serialize (len_DeviceCoreState x)
               serialize (status_DeviceCoreState x)
               serialize (iscore_DeviceCoreState x)
               putSkip 2
        size x
          = size (control_id_DeviceCoreState x) +
              size (len_DeviceCoreState x)
              + size (status_DeviceCoreState x)
              + size (iscore_DeviceCoreState x)
              + 2
 
instance Deserialize DeviceCoreState where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               status <- deserialize
               iscore <- deserialize
               skip 2
               return (MkDeviceCoreState control_id len status iscore)
 
data DeviceEnableState = MkDeviceEnableState{control_id_DeviceEnableState
                                             :: Word16,
                                             len_DeviceEnableState :: Word16,
                                             enable_DeviceEnableState :: Word8}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceEnableState where
        serialize x
          = do serialize (control_id_DeviceEnableState x)
               serialize (len_DeviceEnableState x)
               serialize (enable_DeviceEnableState x)
               putSkip 3
        size x
          = size (control_id_DeviceEnableState x) +
              size (len_DeviceEnableState x)
              + size (enable_DeviceEnableState x)
              + 3
 
instance Deserialize DeviceEnableState where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               enable <- deserialize
               skip 3
               return (MkDeviceEnableState control_id len enable)
 
data DeviceCtl = MkDeviceCtl{control_id_DeviceCtl :: Word16,
                             len_DeviceCtl :: Word16}
               deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceCtl where
        serialize x
          = do serialize (control_id_DeviceCtl x)
               serialize (len_DeviceCtl x)
        size x = size (control_id_DeviceCtl x) + size (len_DeviceCtl x)
 
instance Deserialize DeviceCtl where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               return (MkDeviceCtl control_id len)
 
data DeviceResolutionCtl = MkDeviceResolutionCtl{control_id_DeviceResolutionCtl
                                                 :: Word16,
                                                 len_DeviceResolutionCtl :: Word16,
                                                 first_valuator_DeviceResolutionCtl :: Word8,
                                                 num_valuators_DeviceResolutionCtl :: Word8,
                                                 resolution_values_DeviceResolutionCtl :: [Word32]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceResolutionCtl where
        serialize x
          = do serialize (control_id_DeviceResolutionCtl x)
               serialize (len_DeviceResolutionCtl x)
               serialize (first_valuator_DeviceResolutionCtl x)
               serialize (num_valuators_DeviceResolutionCtl x)
               serializeList (resolution_values_DeviceResolutionCtl x)
        size x
          = size (control_id_DeviceResolutionCtl x) +
              size (len_DeviceResolutionCtl x)
              + size (first_valuator_DeviceResolutionCtl x)
              + size (num_valuators_DeviceResolutionCtl x)
              + sum (map size (resolution_values_DeviceResolutionCtl x))
 
instance Deserialize DeviceResolutionCtl where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               first_valuator <- deserialize
               num_valuators <- deserialize
               resolution_values <- deserializeList (fromIntegral num_valuators)
               return
                 (MkDeviceResolutionCtl control_id len first_valuator num_valuators
                    resolution_values)
 
data DeviceAbsCalibCtl = MkDeviceAbsCalibCtl{control_id_DeviceAbsCalibCtl
                                             :: Word16,
                                             len_DeviceAbsCalibCtl :: Word16,
                                             min_x_DeviceAbsCalibCtl :: Int32,
                                             max_x_DeviceAbsCalibCtl :: Int32,
                                             min_y_DeviceAbsCalibCtl :: Int32,
                                             max_y_DeviceAbsCalibCtl :: Int32,
                                             flip_x_DeviceAbsCalibCtl :: Word32,
                                             flip_y_DeviceAbsCalibCtl :: Word32,
                                             rotation_DeviceAbsCalibCtl :: Word32,
                                             button_threshold_DeviceAbsCalibCtl :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceAbsCalibCtl where
        serialize x
          = do serialize (control_id_DeviceAbsCalibCtl x)
               serialize (len_DeviceAbsCalibCtl x)
               serialize (min_x_DeviceAbsCalibCtl x)
               serialize (max_x_DeviceAbsCalibCtl x)
               serialize (min_y_DeviceAbsCalibCtl x)
               serialize (max_y_DeviceAbsCalibCtl x)
               serialize (flip_x_DeviceAbsCalibCtl x)
               serialize (flip_y_DeviceAbsCalibCtl x)
               serialize (rotation_DeviceAbsCalibCtl x)
               serialize (button_threshold_DeviceAbsCalibCtl x)
        size x
          = size (control_id_DeviceAbsCalibCtl x) +
              size (len_DeviceAbsCalibCtl x)
              + size (min_x_DeviceAbsCalibCtl x)
              + size (max_x_DeviceAbsCalibCtl x)
              + size (min_y_DeviceAbsCalibCtl x)
              + size (max_y_DeviceAbsCalibCtl x)
              + size (flip_x_DeviceAbsCalibCtl x)
              + size (flip_y_DeviceAbsCalibCtl x)
              + size (rotation_DeviceAbsCalibCtl x)
              + size (button_threshold_DeviceAbsCalibCtl x)
 
instance Deserialize DeviceAbsCalibCtl where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               min_x <- deserialize
               max_x <- deserialize
               min_y <- deserialize
               max_y <- deserialize
               flip_x <- deserialize
               flip_y <- deserialize
               rotation <- deserialize
               button_threshold <- deserialize
               return
                 (MkDeviceAbsCalibCtl control_id len min_x max_x min_y max_y flip_x
                    flip_y
                    rotation
                    button_threshold)
 
data DeviceAbsAreaCtrl = MkDeviceAbsAreaCtrl{control_id_DeviceAbsAreaCtrl
                                             :: Word16,
                                             len_DeviceAbsAreaCtrl :: Word16,
                                             offset_x_DeviceAbsAreaCtrl :: Word32,
                                             offset_y_DeviceAbsAreaCtrl :: Word32,
                                             width_DeviceAbsAreaCtrl :: Int32,
                                             height_DeviceAbsAreaCtrl :: Int32,
                                             screen_DeviceAbsAreaCtrl :: Int32,
                                             following_DeviceAbsAreaCtrl :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceAbsAreaCtrl where
        serialize x
          = do serialize (control_id_DeviceAbsAreaCtrl x)
               serialize (len_DeviceAbsAreaCtrl x)
               serialize (offset_x_DeviceAbsAreaCtrl x)
               serialize (offset_y_DeviceAbsAreaCtrl x)
               serialize (width_DeviceAbsAreaCtrl x)
               serialize (height_DeviceAbsAreaCtrl x)
               serialize (screen_DeviceAbsAreaCtrl x)
               serialize (following_DeviceAbsAreaCtrl x)
        size x
          = size (control_id_DeviceAbsAreaCtrl x) +
              size (len_DeviceAbsAreaCtrl x)
              + size (offset_x_DeviceAbsAreaCtrl x)
              + size (offset_y_DeviceAbsAreaCtrl x)
              + size (width_DeviceAbsAreaCtrl x)
              + size (height_DeviceAbsAreaCtrl x)
              + size (screen_DeviceAbsAreaCtrl x)
              + size (following_DeviceAbsAreaCtrl x)
 
instance Deserialize DeviceAbsAreaCtrl where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               offset_x <- deserialize
               offset_y <- deserialize
               width <- deserialize
               height <- deserialize
               screen <- deserialize
               following <- deserialize
               return
                 (MkDeviceAbsAreaCtrl control_id len offset_x offset_y width height
                    screen
                    following)
 
data DeviceCoreCtrl = MkDeviceCoreCtrl{control_id_DeviceCoreCtrl ::
                                       Word16,
                                       len_DeviceCoreCtrl :: Word16, status_DeviceCoreCtrl :: Word8}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceCoreCtrl where
        serialize x
          = do serialize (control_id_DeviceCoreCtrl x)
               serialize (len_DeviceCoreCtrl x)
               serialize (status_DeviceCoreCtrl x)
               putSkip 3
        size x
          = size (control_id_DeviceCoreCtrl x) + size (len_DeviceCoreCtrl x)
              + size (status_DeviceCoreCtrl x)
              + 3
 
instance Deserialize DeviceCoreCtrl where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               status <- deserialize
               skip 3
               return (MkDeviceCoreCtrl control_id len status)
 
data DeviceEnableCtrl = MkDeviceEnableCtrl{control_id_DeviceEnableCtrl
                                           :: Word16,
                                           len_DeviceEnableCtrl :: Word16,
                                           enable_DeviceEnableCtrl :: Word8}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Serialize DeviceEnableCtrl where
        serialize x
          = do serialize (control_id_DeviceEnableCtrl x)
               serialize (len_DeviceEnableCtrl x)
               serialize (enable_DeviceEnableCtrl x)
               putSkip 3
        size x
          = size (control_id_DeviceEnableCtrl x) +
              size (len_DeviceEnableCtrl x)
              + size (enable_DeviceEnableCtrl x)
              + 3
 
instance Deserialize DeviceEnableCtrl where
        deserialize
          = do control_id <- deserialize
               len <- deserialize
               enable <- deserialize
               skip 3
               return (MkDeviceEnableCtrl control_id len enable)
 
data DeviceValuatorEvent = MkDeviceValuatorEvent{device_id_DeviceValuatorEvent
                                                 :: Word8,
                                                 device_state_DeviceValuatorEvent :: Word16,
                                                 num_valuators_DeviceValuatorEvent :: Word8,
                                                 first_valuator_DeviceValuatorEvent :: Word8,
                                                 valuators_DeviceValuatorEvent :: [Int32]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceValuatorEvent
 
instance Deserialize DeviceValuatorEvent where
        deserialize
          = do skip 1
               device_id <- deserialize
               skip 2
               device_state <- deserialize
               num_valuators <- deserialize
               first_valuator <- deserialize
               valuators <- deserializeList (fromIntegral 6)
               return
                 (MkDeviceValuatorEvent device_id device_state num_valuators
                    first_valuator
                    valuators)
 
data DeviceKeyPressEvent = MkDeviceKeyPressEvent{detail_DeviceKeyPressEvent
                                                 :: Word8,
                                                 time_DeviceKeyPressEvent :: TIMESTAMP,
                                                 root_DeviceKeyPressEvent :: WINDOW,
                                                 event_DeviceKeyPressEvent :: WINDOW,
                                                 child_DeviceKeyPressEvent :: WINDOW,
                                                 root_x_DeviceKeyPressEvent :: Int16,
                                                 root_y_DeviceKeyPressEvent :: Int16,
                                                 event_x_DeviceKeyPressEvent :: Int16,
                                                 event_y_DeviceKeyPressEvent :: Int16,
                                                 state_DeviceKeyPressEvent :: Word16,
                                                 same_screen_DeviceKeyPressEvent :: Bool,
                                                 device_id_DeviceKeyPressEvent :: Word8}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceKeyPressEvent
 
instance Deserialize DeviceKeyPressEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               time <- deserialize
               root <- deserialize
               event <- deserialize
               child <- deserialize
               root_x <- deserialize
               root_y <- deserialize
               event_x <- deserialize
               event_y <- deserialize
               state <- deserialize
               same_screen <- deserialize
               device_id <- deserialize
               return
                 (MkDeviceKeyPressEvent detail time root event child root_x root_y
                    event_x
                    event_y
                    state
                    same_screen
                    device_id)
 
data DeviceKeyReleaseEvent = MkDeviceKeyReleaseEvent{detail_DeviceKeyReleaseEvent
                                                     :: Word8,
                                                     time_DeviceKeyReleaseEvent :: TIMESTAMP,
                                                     root_DeviceKeyReleaseEvent :: WINDOW,
                                                     event_DeviceKeyReleaseEvent :: WINDOW,
                                                     child_DeviceKeyReleaseEvent :: WINDOW,
                                                     root_x_DeviceKeyReleaseEvent :: Int16,
                                                     root_y_DeviceKeyReleaseEvent :: Int16,
                                                     event_x_DeviceKeyReleaseEvent :: Int16,
                                                     event_y_DeviceKeyReleaseEvent :: Int16,
                                                     state_DeviceKeyReleaseEvent :: Word16,
                                                     same_screen_DeviceKeyReleaseEvent :: Bool,
                                                     device_id_DeviceKeyReleaseEvent :: Word8}
                           deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceKeyReleaseEvent
 
instance Deserialize DeviceKeyReleaseEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               time <- deserialize
               root <- deserialize
               event <- deserialize
               child <- deserialize
               root_x <- deserialize
               root_y <- deserialize
               event_x <- deserialize
               event_y <- deserialize
               state <- deserialize
               same_screen <- deserialize
               device_id <- deserialize
               return
                 (MkDeviceKeyReleaseEvent detail time root event child root_x root_y
                    event_x
                    event_y
                    state
                    same_screen
                    device_id)
 
data DeviceButtonPressEvent = MkDeviceButtonPressEvent{detail_DeviceButtonPressEvent
                                                       :: Word8,
                                                       time_DeviceButtonPressEvent :: TIMESTAMP,
                                                       root_DeviceButtonPressEvent :: WINDOW,
                                                       event_DeviceButtonPressEvent :: WINDOW,
                                                       child_DeviceButtonPressEvent :: WINDOW,
                                                       root_x_DeviceButtonPressEvent :: Int16,
                                                       root_y_DeviceButtonPressEvent :: Int16,
                                                       event_x_DeviceButtonPressEvent :: Int16,
                                                       event_y_DeviceButtonPressEvent :: Int16,
                                                       state_DeviceButtonPressEvent :: Word16,
                                                       same_screen_DeviceButtonPressEvent :: Bool,
                                                       device_id_DeviceButtonPressEvent :: Word8}
                            deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceButtonPressEvent
 
instance Deserialize DeviceButtonPressEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               time <- deserialize
               root <- deserialize
               event <- deserialize
               child <- deserialize
               root_x <- deserialize
               root_y <- deserialize
               event_x <- deserialize
               event_y <- deserialize
               state <- deserialize
               same_screen <- deserialize
               device_id <- deserialize
               return
                 (MkDeviceButtonPressEvent detail time root event child root_x
                    root_y
                    event_x
                    event_y
                    state
                    same_screen
                    device_id)
 
data DeviceButtonReleaseEvent = MkDeviceButtonReleaseEvent{detail_DeviceButtonReleaseEvent
                                                           :: Word8,
                                                           time_DeviceButtonReleaseEvent ::
                                                           TIMESTAMP,
                                                           root_DeviceButtonReleaseEvent :: WINDOW,
                                                           event_DeviceButtonReleaseEvent :: WINDOW,
                                                           child_DeviceButtonReleaseEvent :: WINDOW,
                                                           root_x_DeviceButtonReleaseEvent :: Int16,
                                                           root_y_DeviceButtonReleaseEvent :: Int16,
                                                           event_x_DeviceButtonReleaseEvent ::
                                                           Int16,
                                                           event_y_DeviceButtonReleaseEvent ::
                                                           Int16,
                                                           state_DeviceButtonReleaseEvent :: Word16,
                                                           same_screen_DeviceButtonReleaseEvent ::
                                                           Bool,
                                                           device_id_DeviceButtonReleaseEvent ::
                                                           Word8}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceButtonReleaseEvent
 
instance Deserialize DeviceButtonReleaseEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               time <- deserialize
               root <- deserialize
               event <- deserialize
               child <- deserialize
               root_x <- deserialize
               root_y <- deserialize
               event_x <- deserialize
               event_y <- deserialize
               state <- deserialize
               same_screen <- deserialize
               device_id <- deserialize
               return
                 (MkDeviceButtonReleaseEvent detail time root event child root_x
                    root_y
                    event_x
                    event_y
                    state
                    same_screen
                    device_id)
 
data DeviceMotionNotifyEvent = MkDeviceMotionNotifyEvent{detail_DeviceMotionNotifyEvent
                                                         :: Word8,
                                                         time_DeviceMotionNotifyEvent :: TIMESTAMP,
                                                         root_DeviceMotionNotifyEvent :: WINDOW,
                                                         event_DeviceMotionNotifyEvent :: WINDOW,
                                                         child_DeviceMotionNotifyEvent :: WINDOW,
                                                         root_x_DeviceMotionNotifyEvent :: Int16,
                                                         root_y_DeviceMotionNotifyEvent :: Int16,
                                                         event_x_DeviceMotionNotifyEvent :: Int16,
                                                         event_y_DeviceMotionNotifyEvent :: Int16,
                                                         state_DeviceMotionNotifyEvent :: Word16,
                                                         same_screen_DeviceMotionNotifyEvent ::
                                                         Bool,
                                                         device_id_DeviceMotionNotifyEvent :: Word8}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceMotionNotifyEvent
 
instance Deserialize DeviceMotionNotifyEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               time <- deserialize
               root <- deserialize
               event <- deserialize
               child <- deserialize
               root_x <- deserialize
               root_y <- deserialize
               event_x <- deserialize
               event_y <- deserialize
               state <- deserialize
               same_screen <- deserialize
               device_id <- deserialize
               return
                 (MkDeviceMotionNotifyEvent detail time root event child root_x
                    root_y
                    event_x
                    event_y
                    state
                    same_screen
                    device_id)
 
data ProximityInEvent = MkProximityInEvent{detail_ProximityInEvent
                                           :: Word8,
                                           time_ProximityInEvent :: TIMESTAMP,
                                           root_ProximityInEvent :: WINDOW,
                                           event_ProximityInEvent :: WINDOW,
                                           child_ProximityInEvent :: WINDOW,
                                           root_x_ProximityInEvent :: Int16,
                                           root_y_ProximityInEvent :: Int16,
                                           event_x_ProximityInEvent :: Int16,
                                           event_y_ProximityInEvent :: Int16,
                                           state_ProximityInEvent :: Word16,
                                           same_screen_ProximityInEvent :: Bool,
                                           device_id_ProximityInEvent :: Word8}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event ProximityInEvent
 
instance Deserialize ProximityInEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               time <- deserialize
               root <- deserialize
               event <- deserialize
               child <- deserialize
               root_x <- deserialize
               root_y <- deserialize
               event_x <- deserialize
               event_y <- deserialize
               state <- deserialize
               same_screen <- deserialize
               device_id <- deserialize
               return
                 (MkProximityInEvent detail time root event child root_x root_y
                    event_x
                    event_y
                    state
                    same_screen
                    device_id)
 
data ProximityOutEvent = MkProximityOutEvent{detail_ProximityOutEvent
                                             :: Word8,
                                             time_ProximityOutEvent :: TIMESTAMP,
                                             root_ProximityOutEvent :: WINDOW,
                                             event_ProximityOutEvent :: WINDOW,
                                             child_ProximityOutEvent :: WINDOW,
                                             root_x_ProximityOutEvent :: Int16,
                                             root_y_ProximityOutEvent :: Int16,
                                             event_x_ProximityOutEvent :: Int16,
                                             event_y_ProximityOutEvent :: Int16,
                                             state_ProximityOutEvent :: Word16,
                                             same_screen_ProximityOutEvent :: Bool,
                                             device_id_ProximityOutEvent :: Word8}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event ProximityOutEvent
 
instance Deserialize ProximityOutEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               time <- deserialize
               root <- deserialize
               event <- deserialize
               child <- deserialize
               root_x <- deserialize
               root_y <- deserialize
               event_x <- deserialize
               event_y <- deserialize
               state <- deserialize
               same_screen <- deserialize
               device_id <- deserialize
               return
                 (MkProximityOutEvent detail time root event child root_x root_y
                    event_x
                    event_y
                    state
                    same_screen
                    device_id)
 
data FocusInEvent = MkFocusInEvent{detail_FocusInEvent ::
                                   NotifyDetail,
                                   time_FocusInEvent :: TIMESTAMP, window_FocusInEvent :: WINDOW,
                                   mode_FocusInEvent :: NotifyMode, device_id_FocusInEvent :: Word8}
                  deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event FocusInEvent
 
instance Deserialize FocusInEvent where
        deserialize
          = do skip 1
               detail <- liftM fromValue (deserialize :: Get Word8)
               skip 2
               time <- deserialize
               window <- deserialize
               mode <- liftM fromValue (deserialize :: Get Word8)
               device_id <- deserialize
               skip 18
               return (MkFocusInEvent detail time window mode device_id)
 
data FocusOutEvent = MkFocusOutEvent{detail_FocusOutEvent ::
                                     NotifyDetail,
                                     time_FocusOutEvent :: TIMESTAMP,
                                     window_FocusOutEvent :: WINDOW,
                                     mode_FocusOutEvent :: NotifyMode,
                                     device_id_FocusOutEvent :: Word8}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event FocusOutEvent
 
instance Deserialize FocusOutEvent where
        deserialize
          = do skip 1
               detail <- liftM fromValue (deserialize :: Get Word8)
               skip 2
               time <- deserialize
               window <- deserialize
               mode <- liftM fromValue (deserialize :: Get Word8)
               device_id <- deserialize
               skip 18
               return (MkFocusOutEvent detail time window mode device_id)
 
data DeviceStateNotifyEvent = MkDeviceStateNotifyEvent{device_id_DeviceStateNotifyEvent
                                                       :: Word8,
                                                       time_DeviceStateNotifyEvent :: TIMESTAMP,
                                                       num_keys_DeviceStateNotifyEvent :: Word8,
                                                       num_buttons_DeviceStateNotifyEvent :: Word8,
                                                       num_valuators_DeviceStateNotifyEvent ::
                                                       Word8,
                                                       classes_reported_DeviceStateNotifyEvent ::
                                                       Word8,
                                                       buttons_DeviceStateNotifyEvent :: [Word8],
                                                       keys_DeviceStateNotifyEvent :: [Word8],
                                                       valuators_DeviceStateNotifyEvent :: [Word32]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceStateNotifyEvent
 
instance Deserialize DeviceStateNotifyEvent where
        deserialize
          = do skip 1
               device_id <- deserialize
               skip 2
               time <- deserialize
               num_keys <- deserialize
               num_buttons <- deserialize
               num_valuators <- deserialize
               classes_reported <- deserialize
               buttons <- deserializeList (fromIntegral 4)
               keys <- deserializeList (fromIntegral 4)
               valuators <- deserializeList (fromIntegral 3)
               return
                 (MkDeviceStateNotifyEvent device_id time num_keys num_buttons
                    num_valuators
                    classes_reported
                    buttons
                    keys
                    valuators)
 
data DeviceMappingNotifyEvent = MkDeviceMappingNotifyEvent{device_id_DeviceMappingNotifyEvent
                                                           :: Word8,
                                                           request_DeviceMappingNotifyEvent ::
                                                           Word8,
                                                           first_keycode_DeviceMappingNotifyEvent ::
                                                           KeyCode,
                                                           count_DeviceMappingNotifyEvent :: Word8,
                                                           time_DeviceMappingNotifyEvent ::
                                                           TIMESTAMP}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceMappingNotifyEvent
 
instance Deserialize DeviceMappingNotifyEvent where
        deserialize
          = do skip 1
               device_id <- deserialize
               skip 2
               request <- deserialize
               first_keycode <- deserialize
               count <- deserialize
               skip 1
               time <- deserialize
               skip 20
               return
                 (MkDeviceMappingNotifyEvent device_id request first_keycode count
                    time)
 
data ChangeDeviceNotifyEvent = MkChangeDeviceNotifyEvent{device_id_ChangeDeviceNotifyEvent
                                                         :: Word8,
                                                         time_ChangeDeviceNotifyEvent :: TIMESTAMP,
                                                         request_ChangeDeviceNotifyEvent :: Word8}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event ChangeDeviceNotifyEvent
 
instance Deserialize ChangeDeviceNotifyEvent where
        deserialize
          = do skip 1
               device_id <- deserialize
               skip 2
               time <- deserialize
               request <- deserialize
               skip 23
               return (MkChangeDeviceNotifyEvent device_id time request)
 
data DeviceKeyStateNotifyEvent = MkDeviceKeyStateNotifyEvent{device_id_DeviceKeyStateNotifyEvent
                                                             :: Word8,
                                                             keys_DeviceKeyStateNotifyEvent ::
                                                             [Word8]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceKeyStateNotifyEvent
 
instance Deserialize DeviceKeyStateNotifyEvent where
        deserialize
          = do skip 1
               device_id <- deserialize
               skip 2
               keys <- deserializeList (fromIntegral 28)
               return (MkDeviceKeyStateNotifyEvent device_id keys)
 
data DeviceButtonStateNotifyEvent = MkDeviceButtonStateNotifyEvent{device_id_DeviceButtonStateNotifyEvent
                                                                   :: Word8,
                                                                   buttons_DeviceButtonStateNotifyEvent
                                                                   :: [Word8]}
                                  deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DeviceButtonStateNotifyEvent
 
instance Deserialize DeviceButtonStateNotifyEvent where
        deserialize
          = do skip 1
               device_id <- deserialize
               skip 2
               buttons <- deserializeList (fromIntegral 28)
               return (MkDeviceButtonStateNotifyEvent device_id buttons)
 
data DevicePresenceNotifyEvent = MkDevicePresenceNotifyEvent{time_DevicePresenceNotifyEvent
                                                             :: TIMESTAMP,
                                                             devchange_DevicePresenceNotifyEvent ::
                                                             Word8,
                                                             device_id_DevicePresenceNotifyEvent ::
                                                             Word8,
                                                             control_DevicePresenceNotifyEvent ::
                                                             Word16}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event DevicePresenceNotifyEvent
 
instance Deserialize DevicePresenceNotifyEvent where
        deserialize
          = do skip 1
               skip 1
               skip 2
               time <- deserialize
               devchange <- deserialize
               device_id <- deserialize
               control <- deserialize
               skip 20
               return
                 (MkDevicePresenceNotifyEvent time devchange device_id control)