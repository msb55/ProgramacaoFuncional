module Graphics.XHB.Gen.SELinux
       (extension, queryVersion, setDeviceCreateContext,
        getDeviceCreateContext, setDeviceContext, getDeviceContext,
        setWindowCreateContext, getWindowCreateContext, getWindowContext,
        setPropertyCreateContext, getPropertyCreateContext,
        setPropertyUseContext, getPropertyUseContext, getPropertyContext,
        getPropertyDataContext, listProperties, setSelectionCreateContext,
        getSelectionCreateContext, setSelectionUseContext,
        getSelectionUseContext, getSelectionContext,
        getSelectionDataContext, listSelections, getClientContext,
        module Graphics.XHB.Gen.SELinux.Types)
       where
import Graphics.XHB.Gen.SELinux.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (ListProperties(..), ListPropertiesReply(..),
               deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "SELinux"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word8 -> Word8 -> IO (Receipt QueryVersionReply)
queryVersion c client_major client_minor
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion client_major client_minor
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setDeviceCreateContext ::
                         Graphics.XHB.Connection.Types.Connection ->
                           Word32 -> [CChar] -> IO ()
setDeviceCreateContext c context_len context
  = do let req = MkSetDeviceCreateContext context_len context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getDeviceCreateContext ::
                         Graphics.XHB.Connection.Types.Connection ->
                           IO (Receipt GetDeviceCreateContextReply)
getDeviceCreateContext c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDeviceCreateContext
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setDeviceContext ::
                   Graphics.XHB.Connection.Types.Connection ->
                     SetDeviceContext -> IO ()
setDeviceContext c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getDeviceContext ::
                   Graphics.XHB.Connection.Types.Connection ->
                     Word32 -> IO (Receipt GetDeviceContextReply)
getDeviceContext c device
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDeviceContext device
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setWindowCreateContext ::
                         Graphics.XHB.Connection.Types.Connection ->
                           Word32 -> [CChar] -> IO ()
setWindowCreateContext c context_len context
  = do let req = MkSetWindowCreateContext context_len context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getWindowCreateContext ::
                         Graphics.XHB.Connection.Types.Connection ->
                           IO (Receipt GetWindowCreateContextReply)
getWindowCreateContext c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetWindowCreateContext
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getWindowContext ::
                   Graphics.XHB.Connection.Types.Connection ->
                     WINDOW -> IO (Receipt GetWindowContextReply)
getWindowContext c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetWindowContext window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setPropertyCreateContext ::
                           Graphics.XHB.Connection.Types.Connection ->
                             Word32 -> [CChar] -> IO ()
setPropertyCreateContext c context_len context
  = do let req = MkSetPropertyCreateContext context_len context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getPropertyCreateContext ::
                           Graphics.XHB.Connection.Types.Connection ->
                             IO (Receipt GetPropertyCreateContextReply)
getPropertyCreateContext c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetPropertyCreateContext
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setPropertyUseContext ::
                        Graphics.XHB.Connection.Types.Connection ->
                          Word32 -> [CChar] -> IO ()
setPropertyUseContext c context_len context
  = do let req = MkSetPropertyUseContext context_len context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getPropertyUseContext ::
                        Graphics.XHB.Connection.Types.Connection ->
                          IO (Receipt GetPropertyUseContextReply)
getPropertyUseContext c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetPropertyUseContext
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getPropertyContext ::
                     Graphics.XHB.Connection.Types.Connection ->
                       WINDOW -> ATOM -> IO (Receipt GetPropertyContextReply)
getPropertyContext c window property
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetPropertyContext window property
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getPropertyDataContext ::
                         Graphics.XHB.Connection.Types.Connection ->
                           WINDOW -> ATOM -> IO (Receipt GetPropertyDataContextReply)
getPropertyDataContext c window property
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetPropertyDataContext window property
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
listProperties ::
                 Graphics.XHB.Connection.Types.Connection ->
                   WINDOW -> IO (Receipt ListPropertiesReply)
listProperties c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkListProperties window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setSelectionCreateContext ::
                            Graphics.XHB.Connection.Types.Connection ->
                              Word32 -> [CChar] -> IO ()
setSelectionCreateContext c context_len context
  = do let req = MkSetSelectionCreateContext context_len context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getSelectionCreateContext ::
                            Graphics.XHB.Connection.Types.Connection ->
                              IO (Receipt GetSelectionCreateContextReply)
getSelectionCreateContext c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetSelectionCreateContext
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setSelectionUseContext ::
                         Graphics.XHB.Connection.Types.Connection ->
                           Word32 -> [CChar] -> IO ()
setSelectionUseContext c context_len context
  = do let req = MkSetSelectionUseContext context_len context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getSelectionUseContext ::
                         Graphics.XHB.Connection.Types.Connection ->
                           IO (Receipt GetSelectionUseContextReply)
getSelectionUseContext c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetSelectionUseContext
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getSelectionContext ::
                      Graphics.XHB.Connection.Types.Connection ->
                        ATOM -> IO (Receipt GetSelectionContextReply)
getSelectionContext c selection
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetSelectionContext selection
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getSelectionDataContext ::
                          Graphics.XHB.Connection.Types.Connection ->
                            ATOM -> IO (Receipt GetSelectionDataContextReply)
getSelectionDataContext c selection
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetSelectionDataContext selection
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
listSelections ::
                 Graphics.XHB.Connection.Types.Connection ->
                   IO (Receipt ListSelectionsReply)
listSelections c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkListSelections
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getClientContext ::
                   Graphics.XHB.Connection.Types.Connection ->
                     Word32 -> IO (Receipt GetClientContextReply)
getClientContext c resource
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetClientContext resource
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt