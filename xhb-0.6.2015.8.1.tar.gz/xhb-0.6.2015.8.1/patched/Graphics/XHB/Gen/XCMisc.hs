module Graphics.XHB.Gen.XCMisc
       (extension, getVersion, getXIDRange, getXIDList,
        module Graphics.XHB.Gen.XCMisc.Types)
       where
import Graphics.XHB.Gen.XCMisc.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
 
extension :: ExtensionId
extension = "XC-MISC"
 
getVersion ::
             Graphics.XHB.Connection.Types.Connection ->
               Word16 -> Word16 -> IO (Receipt GetVersionReply)
getVersion c client_major_version client_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetVersion client_major_version client_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getXIDRange ::
              Graphics.XHB.Connection.Types.Connection ->
                IO (Receipt GetXIDRangeReply)
getXIDRange c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetXIDRange
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getXIDList ::
             Graphics.XHB.Connection.Types.Connection ->
               Word32 -> IO (Receipt GetXIDListReply)
getXIDList c count
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetXIDList count
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt