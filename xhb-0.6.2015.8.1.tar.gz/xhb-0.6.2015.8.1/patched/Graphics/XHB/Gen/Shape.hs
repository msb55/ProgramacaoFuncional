module Graphics.XHB.Gen.Shape
       (extension, queryVersion, rectangles, mask, combine, offset,
        queryExtents, selectInput, inputSelected, getRectangles,
        module Graphics.XHB.Gen.Shape.Types)
       where
import Graphics.XHB.Gen.Shape.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "SHAPE"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 IO (Receipt QueryVersionReply)
queryVersion c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
rectangles ::
             Graphics.XHB.Connection.Types.Connection -> Rectangles -> IO ()
rectangles c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
mask :: Graphics.XHB.Connection.Types.Connection -> Mask -> IO ()
mask c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
combine ::
          Graphics.XHB.Connection.Types.Connection -> Combine -> IO ()
combine c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
offset ::
         Graphics.XHB.Connection.Types.Connection -> Offset -> IO ()
offset c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
queryExtents ::
               Graphics.XHB.Connection.Types.Connection ->
                 WINDOW -> IO (Receipt QueryExtentsReply)
queryExtents c destination_window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryExtents destination_window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
selectInput ::
              Graphics.XHB.Connection.Types.Connection -> WINDOW -> Bool -> IO ()
selectInput c destination_window enable
  = do let req = MkSelectInput destination_window enable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
inputSelected ::
                Graphics.XHB.Connection.Types.Connection ->
                  WINDOW -> IO (Receipt Bool)
inputSelected c destination_window
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (enabled_InputSelectedReply `fmap` deserialize))
       let req = MkInputSelected destination_window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getRectangles ::
                Graphics.XHB.Connection.Types.Connection ->
                  WINDOW -> SK -> IO (Receipt GetRectanglesReply)
getRectangles c window source_kind
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetRectangles window source_kind
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt