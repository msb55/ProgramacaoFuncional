module Graphics.XHB.Gen.Input
       (extension, getExtensionVersion, listInputDevices, openDevice,
        closeDevice, setDeviceMode, selectExtensionEvent,
        getSelectedExtensionEvents, changeDeviceDontPropagateList,
        getDeviceDontPropagateList, getDeviceMotionEvents,
        changeKeyboardDevice, changePointerDevice, grabDevice,
        ungrabDevice, grabDeviceKey, ungrabDeviceKey, grabDeviceButton,
        ungrabDeviceButton, allowDeviceEvents, getDeviceFocus,
        setDeviceFocus, getFeedbackControl, getDeviceKeyMapping,
        changeDeviceKeyMapping, getDeviceModifierMapping,
        setDeviceModifierMapping, getDeviceButtonMapping,
        setDeviceButtonMapping, queryDeviceState, sendExtensionEvent,
        deviceBell, setDeviceValuators, getDeviceControl,
        module Graphics.XHB.Gen.Input.Types)
       where
import Graphics.XHB.Gen.Input.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (FocusInEvent(..), FocusOutEvent(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "XInputExtension"
 
getExtensionVersion ::
                      Graphics.XHB.Connection.Types.Connection ->
                        Word16 -> [CChar] -> IO (Receipt GetExtensionVersionReply)
getExtensionVersion c name_len name
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetExtensionVersion name_len name
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
listInputDevices ::
                   Graphics.XHB.Connection.Types.Connection ->
                     IO (Receipt ListInputDevicesReply)
listInputDevices c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkListInputDevices
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
openDevice ::
             Graphics.XHB.Connection.Types.Connection ->
               Word8 -> IO (Receipt OpenDeviceReply)
openDevice c device_id
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkOpenDevice device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
closeDevice ::
              Graphics.XHB.Connection.Types.Connection -> Word8 -> IO ()
closeDevice c device_id
  = do let req = MkCloseDevice device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setDeviceMode ::
                Graphics.XHB.Connection.Types.Connection ->
                  Word8 -> ValuatorMode -> IO (Receipt Word8)
setDeviceMode c device_id mode
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (status_SetDeviceModeReply `fmap` deserialize))
       let req = MkSetDeviceMode device_id mode
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
selectExtensionEvent ::
                       Graphics.XHB.Connection.Types.Connection ->
                         SelectExtensionEvent -> IO ()
selectExtensionEvent c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getSelectedExtensionEvents ::
                             Graphics.XHB.Connection.Types.Connection ->
                               WINDOW -> IO (Receipt GetSelectedExtensionEventsReply)
getSelectedExtensionEvents c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetSelectedExtensionEvents window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
changeDeviceDontPropagateList ::
                                Graphics.XHB.Connection.Types.Connection ->
                                  ChangeDeviceDontPropagateList -> IO ()
changeDeviceDontPropagateList c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getDeviceDontPropagateList ::
                             Graphics.XHB.Connection.Types.Connection ->
                               WINDOW -> IO (Receipt GetDeviceDontPropagateListReply)
getDeviceDontPropagateList c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDeviceDontPropagateList window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getDeviceMotionEvents ::
                        Graphics.XHB.Connection.Types.Connection ->
                          GetDeviceMotionEvents -> IO (Receipt GetDeviceMotionEventsReply)
getDeviceMotionEvents c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
changeKeyboardDevice ::
                       Graphics.XHB.Connection.Types.Connection ->
                         Word8 -> IO (Receipt Word8)
changeKeyboardDevice c device_id
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (status_ChangeKeyboardDeviceReply `fmap` deserialize))
       let req = MkChangeKeyboardDevice device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
changePointerDevice ::
                      Graphics.XHB.Connection.Types.Connection ->
                        ChangePointerDevice -> IO (Receipt Word8)
changePointerDevice c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (status_ChangePointerDeviceReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
grabDevice ::
             Graphics.XHB.Connection.Types.Connection ->
               GrabDevice -> IO (Receipt GrabStatus)
grabDevice c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (status_GrabDeviceReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
ungrabDevice ::
               Graphics.XHB.Connection.Types.Connection ->
                 TIMESTAMP -> Word8 -> IO ()
ungrabDevice c time device_id
  = do let req = MkUngrabDevice time device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
grabDeviceKey ::
                Graphics.XHB.Connection.Types.Connection -> GrabDeviceKey -> IO ()
grabDeviceKey c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
ungrabDeviceKey ::
                  Graphics.XHB.Connection.Types.Connection ->
                    UngrabDeviceKey -> IO ()
ungrabDeviceKey c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
grabDeviceButton ::
                   Graphics.XHB.Connection.Types.Connection ->
                     GrabDeviceButton -> IO ()
grabDeviceButton c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
ungrabDeviceButton ::
                     Graphics.XHB.Connection.Types.Connection ->
                       UngrabDeviceButton -> IO ()
ungrabDeviceButton c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
allowDeviceEvents ::
                    Graphics.XHB.Connection.Types.Connection ->
                      AllowDeviceEvents -> IO ()
allowDeviceEvents c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getDeviceFocus ::
                 Graphics.XHB.Connection.Types.Connection ->
                   Word8 -> IO (Receipt GetDeviceFocusReply)
getDeviceFocus c device_id
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDeviceFocus device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setDeviceFocus ::
                 Graphics.XHB.Connection.Types.Connection -> SetDeviceFocus -> IO ()
setDeviceFocus c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getFeedbackControl ::
                     Graphics.XHB.Connection.Types.Connection ->
                       Word8 -> IO (Receipt Word16)
getFeedbackControl c device_id
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (num_feedback_GetFeedbackControlReply `fmap` deserialize))
       let req = MkGetFeedbackControl device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getDeviceKeyMapping ::
                      Graphics.XHB.Connection.Types.Connection ->
                        GetDeviceKeyMapping -> IO (Receipt GetDeviceKeyMappingReply)
getDeviceKeyMapping c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
changeDeviceKeyMapping ::
                         Graphics.XHB.Connection.Types.Connection ->
                           ChangeDeviceKeyMapping -> IO ()
changeDeviceKeyMapping c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getDeviceModifierMapping ::
                           Graphics.XHB.Connection.Types.Connection ->
                             Word8 -> IO (Receipt GetDeviceModifierMappingReply)
getDeviceModifierMapping c device_id
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDeviceModifierMapping device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setDeviceModifierMapping ::
                           Graphics.XHB.Connection.Types.Connection ->
                             SetDeviceModifierMapping -> IO (Receipt MappingStatus)
setDeviceModifierMapping c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (status_SetDeviceModifierMappingReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getDeviceButtonMapping ::
                         Graphics.XHB.Connection.Types.Connection ->
                           Word8 -> IO (Receipt GetDeviceButtonMappingReply)
getDeviceButtonMapping c device_id
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDeviceButtonMapping device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setDeviceButtonMapping ::
                         Graphics.XHB.Connection.Types.Connection ->
                           SetDeviceButtonMapping -> IO (Receipt MappingStatus)
setDeviceButtonMapping c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (status_SetDeviceButtonMappingReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryDeviceState ::
                   Graphics.XHB.Connection.Types.Connection ->
                     Word8 -> IO (Receipt Word8)
queryDeviceState c device_id
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (num_classes_QueryDeviceStateReply `fmap` deserialize))
       let req = MkQueryDeviceState device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
sendExtensionEvent ::
                     Graphics.XHB.Connection.Types.Connection ->
                       SendExtensionEvent -> IO ()
sendExtensionEvent c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
deviceBell ::
             Graphics.XHB.Connection.Types.Connection -> DeviceBell -> IO ()
deviceBell c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setDeviceValuators ::
                     Graphics.XHB.Connection.Types.Connection ->
                       SetDeviceValuators -> IO (Receipt GrabStatus)
setDeviceValuators c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (status_SetDeviceValuatorsReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getDeviceControl ::
                   Graphics.XHB.Connection.Types.Connection ->
                     Word16 -> Word8 -> IO (Receipt Word8)
getDeviceControl c control_id device_id
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (status_GetDeviceControlReply `fmap` deserialize))
       let req = MkGetDeviceControl control_id device_id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt