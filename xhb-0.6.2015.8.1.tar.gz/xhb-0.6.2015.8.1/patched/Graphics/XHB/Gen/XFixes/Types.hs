module Graphics.XHB.Gen.XFixes.Types
       (deserializeError, deserializeEvent, QueryVersion(..),
        QueryVersionReply(..), SaveSetMode(..), SaveSetTarget(..),
        SaveSetMapping(..), ChangeSaveSet(..), SelectionEvent(..),
        SelectionEventMask(..), SelectionNotifyEvent(..),
        SelectSelectionInput(..), CursorNotify(..), CursorNotifyMask(..),
        CursorNotifyEvent(..), SelectCursorInput(..), GetCursorImage(..),
        GetCursorImageReply(..), REGION, Region(..), CreateRegion(..),
        CreateRegionFromBitmap(..), CreateRegionFromWindow(..),
        CreateRegionFromGC(..), CreateRegionFromPicture(..),
        DestroyRegion(..), SetRegion(..), CopyRegion(..), UnionRegion(..),
        IntersectRegion(..), SubtractRegion(..), InvertRegion(..),
        TranslateRegion(..), RegionExtents(..), FetchRegion(..),
        FetchRegionReply(..), SetGCClipRegion(..),
        SetWindowShapeRegion(..), SetPictureClipRegion(..),
        SetCursorName(..), GetCursorName(..), GetCursorNameReply(..),
        GetCursorImageAndName(..), GetCursorImageAndNameReply(..),
        ChangeCursor(..), ChangeCursorByName(..), ExpandRegion(..),
        HideCursor(..), ShowCursor(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (ChangeSaveSet(..), SelectionNotifyEvent(..),
               deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
import Graphics.XHB.Gen.Render.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Render.Types
import Graphics.XHB.Gen.Shape.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Shape.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get SelectionNotifyEvent))
deserializeEvent 1
  = return (liftM toEvent (deserialize :: Get CursorNotifyEvent))
deserializeEvent _ = Nothing
 
data QueryVersion = MkQueryVersion{client_major_version_QueryVersion
                                   :: Word32,
                                   client_minor_version_QueryVersion :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_version_QueryVersion x) +
                         size (client_minor_version_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_version_QueryVersion x)
               serialize (client_minor_version_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_version_QueryVersionReply
                                             :: Word32,
                                             minor_version_QueryVersionReply :: Word32}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               skip 16
               let _ = isCard32 length
               return (MkQueryVersionReply major_version minor_version)
 
data SaveSetMode = SaveSetModeInsert
                 | SaveSetModeDelete
                 deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum SaveSetMode where
        toValue SaveSetModeInsert{} = 0
        toValue SaveSetModeDelete{} = 1
        fromValue 0 = SaveSetModeInsert
        fromValue 1 = SaveSetModeDelete
 
data SaveSetTarget = SaveSetTargetNearest
                   | SaveSetTargetRoot
                   deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum SaveSetTarget where
        toValue SaveSetTargetNearest{} = 0
        toValue SaveSetTargetRoot{} = 1
        fromValue 0 = SaveSetTargetNearest
        fromValue 1 = SaveSetTargetRoot
 
data SaveSetMapping = SaveSetMappingMap
                    | SaveSetMappingUnmap
                    deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum SaveSetMapping where
        toValue SaveSetMappingMap{} = 0
        toValue SaveSetMappingUnmap{} = 1
        fromValue 0 = SaveSetMappingMap
        fromValue 1 = SaveSetMappingUnmap
 
data ChangeSaveSet = MkChangeSaveSet{mode_ChangeSaveSet ::
                                     SaveSetMode,
                                     target_ChangeSaveSet :: SaveSetTarget,
                                     map_ChangeSaveSet :: SaveSetMapping,
                                     window_ChangeSaveSet :: WINDOW}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeSaveSet where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (undefined :: Word8) + size (undefined :: Word8) +
                         size (undefined :: Word8)
                         + 1
                         + size (window_ChangeSaveSet x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (mode_ChangeSaveSet x) :: Word8)
               serialize (toValue (target_ChangeSaveSet x) :: Word8)
               serialize (toValue (map_ChangeSaveSet x) :: Word8)
               putSkip 1
               serialize (window_ChangeSaveSet x)
               putSkip (requiredPadding size__)
 
data SelectionEvent = SelectionEventSetSelectionOwner
                    | SelectionEventSelectionWindowDestroy
                    | SelectionEventSelectionClientClose
                    deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum SelectionEvent where
        toValue SelectionEventSetSelectionOwner{} = 0
        toValue SelectionEventSelectionWindowDestroy{} = 1
        toValue SelectionEventSelectionClientClose{} = 2
        fromValue 0 = SelectionEventSetSelectionOwner
        fromValue 1 = SelectionEventSelectionWindowDestroy
        fromValue 2 = SelectionEventSelectionClientClose
 
data SelectionEventMask = SelectionEventMaskSetSelectionOwner
                        | SelectionEventMaskSelectionWindowDestroy
                        | SelectionEventMaskSelectionClientClose
                        deriving (Show, Eq, Ord, Enum, Typeable)
 
instance BitEnum SelectionEventMask where
        toBit SelectionEventMaskSetSelectionOwner{} = 0
        toBit SelectionEventMaskSelectionWindowDestroy{} = 1
        toBit SelectionEventMaskSelectionClientClose{} = 2
        fromBit 0 = SelectionEventMaskSetSelectionOwner
        fromBit 1 = SelectionEventMaskSelectionWindowDestroy
        fromBit 2 = SelectionEventMaskSelectionClientClose
 
data SelectionNotifyEvent = MkSelectionNotifyEvent{subtype_SelectionNotifyEvent
                                                   :: SelectionEvent,
                                                   window_SelectionNotifyEvent :: WINDOW,
                                                   owner_SelectionNotifyEvent :: WINDOW,
                                                   selection_SelectionNotifyEvent :: ATOM,
                                                   timestamp_SelectionNotifyEvent :: TIMESTAMP,
                                                   selection_timestamp_SelectionNotifyEvent ::
                                                   TIMESTAMP}
                          deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event SelectionNotifyEvent
 
instance Deserialize SelectionNotifyEvent where
        deserialize
          = do skip 1
               subtype <- liftM fromValue (deserialize :: Get Word8)
               skip 2
               window <- deserialize
               owner <- deserialize
               selection <- deserialize
               timestamp <- deserialize
               selection_timestamp <- deserialize
               skip 8
               return
                 (MkSelectionNotifyEvent subtype window owner selection timestamp
                    selection_timestamp)
 
data SelectSelectionInput = MkSelectSelectionInput{window_SelectSelectionInput
                                                   :: WINDOW,
                                                   selection_SelectSelectionInput :: ATOM,
                                                   event_mask_SelectSelectionInput ::
                                                   [SelectionEventMask]}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SelectSelectionInput where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (window_SelectSelectionInput x) +
                         size (selection_SelectSelectionInput x)
                         + size (undefined :: Word32)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_SelectSelectionInput x)
               serialize (selection_SelectSelectionInput x)
               serialize (toMask (event_mask_SelectSelectionInput x) :: Word32)
               putSkip (requiredPadding size__)
 
data CursorNotify = CursorNotifyDisplayCursor
                  deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum CursorNotify where
        toValue CursorNotifyDisplayCursor{} = 0
        fromValue 0 = CursorNotifyDisplayCursor
 
data CursorNotifyMask = CursorNotifyMaskDisplayCursor
                      deriving (Show, Eq, Ord, Enum, Typeable)
 
instance BitEnum CursorNotifyMask where
        toBit CursorNotifyMaskDisplayCursor{} = 0
        fromBit 0 = CursorNotifyMaskDisplayCursor
 
data CursorNotifyEvent = MkCursorNotifyEvent{subtype_CursorNotifyEvent
                                             :: CursorNotify,
                                             window_CursorNotifyEvent :: WINDOW,
                                             cursor_serial_CursorNotifyEvent :: Word32,
                                             timestamp_CursorNotifyEvent :: TIMESTAMP,
                                             name_CursorNotifyEvent :: ATOM}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event CursorNotifyEvent
 
instance Deserialize CursorNotifyEvent where
        deserialize
          = do skip 1
               subtype <- liftM fromValue (deserialize :: Get Word8)
               skip 2
               window <- deserialize
               cursor_serial <- deserialize
               timestamp <- deserialize
               name <- deserialize
               skip 12
               return
                 (MkCursorNotifyEvent subtype window cursor_serial timestamp name)
 
data SelectCursorInput = MkSelectCursorInput{window_SelectCursorInput
                                             :: WINDOW,
                                             event_mask_SelectCursorInput :: [CursorNotifyMask]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SelectCursorInput where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (window_SelectCursorInput x) +
                         size (undefined :: Word32)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_SelectCursorInput x)
               serialize (toMask (event_mask_SelectCursorInput x) :: Word32)
               putSkip (requiredPadding size__)
 
data GetCursorImage = MkGetCursorImage{}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetCursorImage where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetCursorImageReply = MkGetCursorImageReply{x_GetCursorImageReply
                                                 :: Int16,
                                                 y_GetCursorImageReply :: Int16,
                                                 width_GetCursorImageReply :: Word16,
                                                 height_GetCursorImageReply :: Word16,
                                                 xhot_GetCursorImageReply :: Word16,
                                                 yhot_GetCursorImageReply :: Word16,
                                                 cursor_serial_GetCursorImageReply :: Word32,
                                                 cursor_image_GetCursorImageReply :: [Word32]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetCursorImageReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               x <- deserialize
               y <- deserialize
               width <- deserialize
               height <- deserialize
               xhot <- deserialize
               yhot <- deserialize
               cursor_serial <- deserialize
               skip 8
               cursor_image <- deserializeList
                                 (fromIntegral (fromIntegral (width * height)))
               let _ = isCard32 length
               return
                 (MkGetCursorImageReply x y width height xhot yhot cursor_serial
                    cursor_image)
 
newtype REGION = MkREGION Xid
                 deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
data Region = RegionNone
            deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Region where
        toValue RegionNone{} = 0
        fromValue 0 = RegionNone
 
data CreateRegion = MkCreateRegion{region_CreateRegion :: REGION,
                                   rectangles_CreateRegion :: [RECTANGLE]}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (region_CreateRegion x) +
                         sum (map size (rectangles_CreateRegion x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_CreateRegion x)
               serializeList (rectangles_CreateRegion x)
               putSkip (requiredPadding size__)
 
data CreateRegionFromBitmap = MkCreateRegionFromBitmap{region_CreateRegionFromBitmap
                                                       :: REGION,
                                                       bitmap_CreateRegionFromBitmap :: PIXMAP}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateRegionFromBitmap where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__
                     = 4 + size (region_CreateRegionFromBitmap x) +
                         size (bitmap_CreateRegionFromBitmap x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_CreateRegionFromBitmap x)
               serialize (bitmap_CreateRegionFromBitmap x)
               putSkip (requiredPadding size__)
 
data CreateRegionFromWindow = MkCreateRegionFromWindow{region_CreateRegionFromWindow
                                                       :: REGION,
                                                       window_CreateRegionFromWindow :: WINDOW,
                                                       kind_CreateRegionFromWindow :: SK}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateRegionFromWindow where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__
                     = 4 + size (region_CreateRegionFromWindow x) +
                         size (window_CreateRegionFromWindow x)
                         + size (undefined :: Graphics.XHB.Gen.Shape.Types.KIND)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_CreateRegionFromWindow x)
               serialize (window_CreateRegionFromWindow x)
               serialize
                 (toValue (kind_CreateRegionFromWindow x) ::
                      Graphics.XHB.Gen.Shape.Types.KIND)
               putSkip 3
               putSkip (requiredPadding size__)
 
data CreateRegionFromGC = MkCreateRegionFromGC{region_CreateRegionFromGC
                                               :: REGION,
                                               gc_CreateRegionFromGC :: GCONTEXT}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateRegionFromGC where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__
                     = 4 + size (region_CreateRegionFromGC x) +
                         size (gc_CreateRegionFromGC x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_CreateRegionFromGC x)
               serialize (gc_CreateRegionFromGC x)
               putSkip (requiredPadding size__)
 
data CreateRegionFromPicture = MkCreateRegionFromPicture{region_CreateRegionFromPicture
                                                         :: REGION,
                                                         picture_CreateRegionFromPicture :: PICTURE}
                             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateRegionFromPicture where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 9
               let size__
                     = 4 + size (region_CreateRegionFromPicture x) +
                         size (picture_CreateRegionFromPicture x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_CreateRegionFromPicture x)
               serialize (picture_CreateRegionFromPicture x)
               putSkip (requiredPadding size__)
 
data DestroyRegion = MkDestroyRegion{region_DestroyRegion ::
                                     REGION}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest DestroyRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 10
               let size__ = 4 + size (region_DestroyRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_DestroyRegion x)
               putSkip (requiredPadding size__)
 
data SetRegion = MkSetRegion{region_SetRegion :: REGION,
                             rectangles_SetRegion :: [RECTANGLE]}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 11
               let size__
                     = 4 + size (region_SetRegion x) +
                         sum (map size (rectangles_SetRegion x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_SetRegion x)
               serializeList (rectangles_SetRegion x)
               putSkip (requiredPadding size__)
 
data CopyRegion = MkCopyRegion{source_CopyRegion :: REGION,
                               destination_CopyRegion :: REGION}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CopyRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 12
               let size__
                     = 4 + size (source_CopyRegion x) + size (destination_CopyRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (source_CopyRegion x)
               serialize (destination_CopyRegion x)
               putSkip (requiredPadding size__)
 
data UnionRegion = MkUnionRegion{source1_UnionRegion :: REGION,
                                 source2_UnionRegion :: REGION, destination_UnionRegion :: REGION}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest UnionRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 13
               let size__
                     = 4 + size (source1_UnionRegion x) + size (source2_UnionRegion x) +
                         size (destination_UnionRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (source1_UnionRegion x)
               serialize (source2_UnionRegion x)
               serialize (destination_UnionRegion x)
               putSkip (requiredPadding size__)
 
data IntersectRegion = MkIntersectRegion{source1_IntersectRegion ::
                                         REGION,
                                         source2_IntersectRegion :: REGION,
                                         destination_IntersectRegion :: REGION}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest IntersectRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 14
               let size__
                     = 4 + size (source1_IntersectRegion x) +
                         size (source2_IntersectRegion x)
                         + size (destination_IntersectRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (source1_IntersectRegion x)
               serialize (source2_IntersectRegion x)
               serialize (destination_IntersectRegion x)
               putSkip (requiredPadding size__)
 
data SubtractRegion = MkSubtractRegion{source1_SubtractRegion ::
                                       REGION,
                                       source2_SubtractRegion :: REGION,
                                       destination_SubtractRegion :: REGION}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SubtractRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 15
               let size__
                     = 4 + size (source1_SubtractRegion x) +
                         size (source2_SubtractRegion x)
                         + size (destination_SubtractRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (source1_SubtractRegion x)
               serialize (source2_SubtractRegion x)
               serialize (destination_SubtractRegion x)
               putSkip (requiredPadding size__)
 
data InvertRegion = MkInvertRegion{source_InvertRegion :: REGION,
                                   bounds_InvertRegion :: RECTANGLE,
                                   destination_InvertRegion :: REGION}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest InvertRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 16
               let size__
                     = 4 + size (source_InvertRegion x) + size (bounds_InvertRegion x) +
                         size (destination_InvertRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (source_InvertRegion x)
               serialize (bounds_InvertRegion x)
               serialize (destination_InvertRegion x)
               putSkip (requiredPadding size__)
 
data TranslateRegion = MkTranslateRegion{region_TranslateRegion ::
                                         REGION,
                                         dx_TranslateRegion :: Int16, dy_TranslateRegion :: Int16}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest TranslateRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 17
               let size__
                     = 4 + size (region_TranslateRegion x) + size (dx_TranslateRegion x)
                         + size (dy_TranslateRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_TranslateRegion x)
               serialize (dx_TranslateRegion x)
               serialize (dy_TranslateRegion x)
               putSkip (requiredPadding size__)
 
data RegionExtents = MkRegionExtents{source_RegionExtents ::
                                     REGION,
                                     destination_RegionExtents :: REGION}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest RegionExtents where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 18
               let size__
                     = 4 + size (source_RegionExtents x) +
                         size (destination_RegionExtents x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (source_RegionExtents x)
               serialize (destination_RegionExtents x)
               putSkip (requiredPadding size__)
 
data FetchRegion = MkFetchRegion{region_FetchRegion :: REGION}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest FetchRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 19
               let size__ = 4 + size (region_FetchRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (region_FetchRegion x)
               putSkip (requiredPadding size__)
 
data FetchRegionReply = MkFetchRegionReply{extents_FetchRegionReply
                                           :: RECTANGLE,
                                           rectangles_FetchRegionReply :: [RECTANGLE]}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize FetchRegionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               extents <- deserialize
               skip 16
               rectangles <- deserializeList
                               (fromIntegral (fromIntegral (length `div` 2)))
               let _ = isCard32 length
               return (MkFetchRegionReply extents rectangles)
 
data SetGCClipRegion = MkSetGCClipRegion{gc_SetGCClipRegion ::
                                         GCONTEXT,
                                         region_SetGCClipRegion :: REGION,
                                         x_origin_SetGCClipRegion :: Int16,
                                         y_origin_SetGCClipRegion :: Int16}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetGCClipRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 20
               let size__
                     = 4 + size (gc_SetGCClipRegion x) + size (region_SetGCClipRegion x)
                         + size (x_origin_SetGCClipRegion x)
                         + size (y_origin_SetGCClipRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (gc_SetGCClipRegion x)
               serialize (region_SetGCClipRegion x)
               serialize (x_origin_SetGCClipRegion x)
               serialize (y_origin_SetGCClipRegion x)
               putSkip (requiredPadding size__)
 
data SetWindowShapeRegion = MkSetWindowShapeRegion{dest_SetWindowShapeRegion
                                                   :: WINDOW,
                                                   dest_kind_SetWindowShapeRegion :: SK,
                                                   x_offset_SetWindowShapeRegion :: Int16,
                                                   y_offset_SetWindowShapeRegion :: Int16,
                                                   region_SetWindowShapeRegion :: REGION}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetWindowShapeRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 21
               let size__
                     = 4 + size (dest_SetWindowShapeRegion x) +
                         size (undefined :: Graphics.XHB.Gen.Shape.Types.KIND)
                         + 3
                         + size (x_offset_SetWindowShapeRegion x)
                         + size (y_offset_SetWindowShapeRegion x)
                         + size (region_SetWindowShapeRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (dest_SetWindowShapeRegion x)
               serialize
                 (toValue (dest_kind_SetWindowShapeRegion x) ::
                      Graphics.XHB.Gen.Shape.Types.KIND)
               putSkip 3
               serialize (x_offset_SetWindowShapeRegion x)
               serialize (y_offset_SetWindowShapeRegion x)
               serialize (region_SetWindowShapeRegion x)
               putSkip (requiredPadding size__)
 
data SetPictureClipRegion = MkSetPictureClipRegion{picture_SetPictureClipRegion
                                                   :: PICTURE,
                                                   region_SetPictureClipRegion :: REGION,
                                                   x_origin_SetPictureClipRegion :: Int16,
                                                   y_origin_SetPictureClipRegion :: Int16}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetPictureClipRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 22
               let size__
                     = 4 + size (picture_SetPictureClipRegion x) +
                         size (region_SetPictureClipRegion x)
                         + size (x_origin_SetPictureClipRegion x)
                         + size (y_origin_SetPictureClipRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (picture_SetPictureClipRegion x)
               serialize (region_SetPictureClipRegion x)
               serialize (x_origin_SetPictureClipRegion x)
               serialize (y_origin_SetPictureClipRegion x)
               putSkip (requiredPadding size__)
 
data SetCursorName = MkSetCursorName{cursor_SetCursorName ::
                                     CURSOR,
                                     nbytes_SetCursorName :: Word16, name_SetCursorName :: [CChar]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetCursorName where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 23
               let size__
                     = 4 + size (cursor_SetCursorName x) + size (nbytes_SetCursorName x)
                         + 2
                         + sum (map size (name_SetCursorName x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (cursor_SetCursorName x)
               serialize (nbytes_SetCursorName x)
               putSkip 2
               serializeList (name_SetCursorName x)
               putSkip (requiredPadding size__)
 
data GetCursorName = MkGetCursorName{cursor_GetCursorName ::
                                     CURSOR}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetCursorName where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 24
               let size__ = 4 + size (cursor_GetCursorName x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (cursor_GetCursorName x)
               putSkip (requiredPadding size__)
 
data GetCursorNameReply = MkGetCursorNameReply{atom_GetCursorNameReply
                                               :: ATOM,
                                               nbytes_GetCursorNameReply :: Word16,
                                               name_GetCursorNameReply :: [CChar]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetCursorNameReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               atom <- deserialize
               nbytes <- deserialize
               skip 18
               name <- deserializeList (fromIntegral nbytes)
               let _ = isCard32 length
               return (MkGetCursorNameReply atom nbytes name)
 
data GetCursorImageAndName = MkGetCursorImageAndName{}
                           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetCursorImageAndName where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 25
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data GetCursorImageAndNameReply = MkGetCursorImageAndNameReply{x_GetCursorImageAndNameReply
                                                               :: Int16,
                                                               y_GetCursorImageAndNameReply ::
                                                               Int16,
                                                               width_GetCursorImageAndNameReply ::
                                                               Word16,
                                                               height_GetCursorImageAndNameReply ::
                                                               Word16,
                                                               xhot_GetCursorImageAndNameReply ::
                                                               Word16,
                                                               yhot_GetCursorImageAndNameReply ::
                                                               Word16,
                                                               cursor_serial_GetCursorImageAndNameReply
                                                               :: Word32,
                                                               cursor_atom_GetCursorImageAndNameReply
                                                               :: ATOM,
                                                               nbytes_GetCursorImageAndNameReply ::
                                                               Word16,
                                                               name_GetCursorImageAndNameReply ::
                                                               [CChar],
                                                               cursor_image_GetCursorImageAndNameReply
                                                               :: [Word32]}
                                deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetCursorImageAndNameReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               x <- deserialize
               y <- deserialize
               width <- deserialize
               height <- deserialize
               xhot <- deserialize
               yhot <- deserialize
               cursor_serial <- deserialize
               cursor_atom <- deserialize
               nbytes <- deserialize
               skip 2
               name <- deserializeList (fromIntegral nbytes)
               cursor_image <- deserializeList
                                 (fromIntegral (fromIntegral (width * height)))
               let _ = isCard32 length
               return
                 (MkGetCursorImageAndNameReply x y width height xhot yhot
                    cursor_serial
                    cursor_atom
                    nbytes
                    name
                    cursor_image)
 
data ChangeCursor = MkChangeCursor{source_ChangeCursor :: CURSOR,
                                   destination_ChangeCursor :: CURSOR}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeCursor where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 26
               let size__
                     = 4 + size (source_ChangeCursor x) +
                         size (destination_ChangeCursor x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (source_ChangeCursor x)
               serialize (destination_ChangeCursor x)
               putSkip (requiredPadding size__)
 
data ChangeCursorByName = MkChangeCursorByName{src_ChangeCursorByName
                                               :: CURSOR,
                                               nbytes_ChangeCursorByName :: Word16,
                                               name_ChangeCursorByName :: [CChar]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ChangeCursorByName where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 27
               let size__
                     = 4 + size (src_ChangeCursorByName x) +
                         size (nbytes_ChangeCursorByName x)
                         + 2
                         + sum (map size (name_ChangeCursorByName x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (src_ChangeCursorByName x)
               serialize (nbytes_ChangeCursorByName x)
               putSkip 2
               serializeList (name_ChangeCursorByName x)
               putSkip (requiredPadding size__)
 
data ExpandRegion = MkExpandRegion{source_ExpandRegion :: REGION,
                                   destination_ExpandRegion :: REGION, left_ExpandRegion :: Word16,
                                   right_ExpandRegion :: Word16, top_ExpandRegion :: Word16,
                                   bottom_ExpandRegion :: Word16}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ExpandRegion where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 28
               let size__
                     = 4 + size (source_ExpandRegion x) +
                         size (destination_ExpandRegion x)
                         + size (left_ExpandRegion x)
                         + size (right_ExpandRegion x)
                         + size (top_ExpandRegion x)
                         + size (bottom_ExpandRegion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (source_ExpandRegion x)
               serialize (destination_ExpandRegion x)
               serialize (left_ExpandRegion x)
               serialize (right_ExpandRegion x)
               serialize (top_ExpandRegion x)
               serialize (bottom_ExpandRegion x)
               putSkip (requiredPadding size__)
 
data HideCursor = MkHideCursor{window_HideCursor :: WINDOW}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest HideCursor where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 29
               let size__ = 4 + size (window_HideCursor x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_HideCursor x)
               putSkip (requiredPadding size__)
 
data ShowCursor = MkShowCursor{window_ShowCursor :: WINDOW}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest ShowCursor where
        extensionId _ = "XFIXES"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 30
               let size__ = 4 + size (window_ShowCursor x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_ShowCursor x)
               putSkip (requiredPadding size__)