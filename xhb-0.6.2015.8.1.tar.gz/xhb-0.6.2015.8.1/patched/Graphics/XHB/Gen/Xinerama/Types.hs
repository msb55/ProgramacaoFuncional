module Graphics.XHB.Gen.Xinerama.Types
       (deserializeError, deserializeEvent, ScreenInfo(..),
        QueryVersion(..), QueryVersionReply(..), GetState(..),
        GetStateReply(..), GetScreenCount(..), GetScreenCountReply(..),
        GetScreenSize(..), GetScreenSizeReply(..), IsActive(..),
        IsActiveReply(..), QueryScreens(..), QueryScreensReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data ScreenInfo = MkScreenInfo{x_org_ScreenInfo :: Int16,
                               y_org_ScreenInfo :: Int16, width_ScreenInfo :: Word16,
                               height_ScreenInfo :: Word16}
                deriving (Show, Typeable, Eq, Ord)
 
instance Serialize ScreenInfo where
        serialize x
          = do serialize (x_org_ScreenInfo x)
               serialize (y_org_ScreenInfo x)
               serialize (width_ScreenInfo x)
               serialize (height_ScreenInfo x)
        size x
          = size (x_org_ScreenInfo x) + size (y_org_ScreenInfo x) +
              size (width_ScreenInfo x)
              + size (height_ScreenInfo x)
 
instance Deserialize ScreenInfo where
        deserialize
          = do x_org <- deserialize
               y_org <- deserialize
               width <- deserialize
               height <- deserialize
               return (MkScreenInfo x_org y_org width height)
 
data QueryVersion = MkQueryVersion{major_QueryVersion :: Word8,
                                   minor_QueryVersion :: Word8}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "XINERAMA"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (major_QueryVersion x) + size (minor_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (major_QueryVersion x)
               serialize (minor_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_QueryVersionReply
                                             :: Word16,
                                             minor_QueryVersionReply :: Word16}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major <- deserialize
               minor <- deserialize
               let _ = isCard32 length
               return (MkQueryVersionReply major minor)
 
data GetState = MkGetState{window_GetState :: WINDOW}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetState where
        extensionId _ = "XINERAMA"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4 + size (window_GetState x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetState x)
               putSkip (requiredPadding size__)
 
data GetStateReply = MkGetStateReply{state_GetStateReply :: Word8,
                                     window_GetStateReply :: WINDOW}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetStateReply where
        deserialize
          = do skip 1
               state <- deserialize
               skip 2
               length <- deserialize
               window <- deserialize
               let _ = isCard32 length
               return (MkGetStateReply state window)
 
data GetScreenCount = MkGetScreenCount{window_GetScreenCount ::
                                       WINDOW}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetScreenCount where
        extensionId _ = "XINERAMA"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4 + size (window_GetScreenCount x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetScreenCount x)
               putSkip (requiredPadding size__)
 
data GetScreenCountReply = MkGetScreenCountReply{screen_count_GetScreenCountReply
                                                 :: Word8,
                                                 window_GetScreenCountReply :: WINDOW}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetScreenCountReply where
        deserialize
          = do skip 1
               screen_count <- deserialize
               skip 2
               length <- deserialize
               window <- deserialize
               let _ = isCard32 length
               return (MkGetScreenCountReply screen_count window)
 
data GetScreenSize = MkGetScreenSize{window_GetScreenSize ::
                                     WINDOW,
                                     screen_GetScreenSize :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetScreenSize where
        extensionId _ = "XINERAMA"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (window_GetScreenSize x) + size (screen_GetScreenSize x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetScreenSize x)
               serialize (screen_GetScreenSize x)
               putSkip (requiredPadding size__)
 
data GetScreenSizeReply = MkGetScreenSizeReply{width_GetScreenSizeReply
                                               :: Word32,
                                               height_GetScreenSizeReply :: Word32,
                                               window_GetScreenSizeReply :: WINDOW,
                                               screen_GetScreenSizeReply :: Word32}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetScreenSizeReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               width <- deserialize
               height <- deserialize
               window <- deserialize
               screen <- deserialize
               let _ = isCard32 length
               return (MkGetScreenSizeReply width height window screen)
 
data IsActive = MkIsActive{}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest IsActive where
        extensionId _ = "XINERAMA"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data IsActiveReply = MkIsActiveReply{state_IsActiveReply :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize IsActiveReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               state <- deserialize
               let _ = isCard32 length
               return (MkIsActiveReply state)
 
data QueryScreens = MkQueryScreens{}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryScreens where
        extensionId _ = "XINERAMA"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data QueryScreensReply = MkQueryScreensReply{number_QueryScreensReply
                                             :: Word32,
                                             screen_info_QueryScreensReply :: [ScreenInfo]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryScreensReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               number <- deserialize
               skip 20
               screen_info <- deserializeList (fromIntegral number)
               let _ = isCard32 length
               return (MkQueryScreensReply number screen_info)