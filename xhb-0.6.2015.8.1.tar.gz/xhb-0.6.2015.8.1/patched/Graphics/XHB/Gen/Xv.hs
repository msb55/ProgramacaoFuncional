module Graphics.XHB.Gen.Xv
       (extension, queryExtension, queryAdaptors, queryEncodings,
        grabPort, ungrabPort, putVideo, putStill, getVideo, getStill,
        stopVideo, selectVideoNotify, selectPortNotify, queryBestSize,
        setPortAttribute, getPortAttribute, queryPortAttributes,
        listImageFormats, queryImageAttributes, putImage, shmPutImage,
        module Graphics.XHB.Gen.Xv.Types)
       where
import Graphics.XHB.Gen.Xv.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (QueryExtension(..), QueryExtensionReply(..),
               QueryBestSize(..), QueryBestSizeReply(..), PutImage(..),
               deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
import Graphics.XHB.Gen.Shm.Types
       hiding (PutImage(..), deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Shm.Types
 
extension :: ExtensionId
extension = "XVideo"
 
queryExtension ::
                 Graphics.XHB.Connection.Types.Connection ->
                   IO (Receipt QueryExtensionReply)
queryExtension c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryExtension
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryAdaptors ::
                Graphics.XHB.Connection.Types.Connection ->
                  WINDOW -> IO (Receipt QueryAdaptorsReply)
queryAdaptors c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryAdaptors window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryEncodings ::
                 Graphics.XHB.Connection.Types.Connection ->
                   PORT -> IO (Receipt QueryEncodingsReply)
queryEncodings c port
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryEncodings port
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
grabPort ::
           Graphics.XHB.Connection.Types.Connection ->
             PORT -> TIMESTAMP -> IO (Receipt GrabPortStatus)
grabPort c port time
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (result_GrabPortReply `fmap` deserialize))
       let req = MkGrabPort port time
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
ungrabPort ::
             Graphics.XHB.Connection.Types.Connection ->
               PORT -> TIMESTAMP -> IO ()
ungrabPort c port time
  = do let req = MkUngrabPort port time
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
putVideo ::
           Graphics.XHB.Connection.Types.Connection -> PutVideo -> IO ()
putVideo c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
putStill ::
           Graphics.XHB.Connection.Types.Connection -> PutStill -> IO ()
putStill c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getVideo ::
           Graphics.XHB.Connection.Types.Connection -> GetVideo -> IO ()
getVideo c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getStill ::
           Graphics.XHB.Connection.Types.Connection -> GetStill -> IO ()
getStill c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
stopVideo ::
            Graphics.XHB.Connection.Types.Connection ->
              PORT -> DRAWABLE -> IO ()
stopVideo c port drawable
  = do let req = MkStopVideo port drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
selectVideoNotify ::
                    Graphics.XHB.Connection.Types.Connection ->
                      DRAWABLE -> Bool -> IO ()
selectVideoNotify c drawable onoff
  = do let req = MkSelectVideoNotify drawable onoff
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
selectPortNotify ::
                   Graphics.XHB.Connection.Types.Connection -> PORT -> Bool -> IO ()
selectPortNotify c port onoff
  = do let req = MkSelectPortNotify port onoff
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
queryBestSize ::
                Graphics.XHB.Connection.Types.Connection ->
                  QueryBestSize -> IO (Receipt QueryBestSizeReply)
queryBestSize c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setPortAttribute ::
                   Graphics.XHB.Connection.Types.Connection ->
                     SetPortAttribute -> IO ()
setPortAttribute c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getPortAttribute ::
                   Graphics.XHB.Connection.Types.Connection ->
                     PORT -> ATOM -> IO (Receipt Int32)
getPortAttribute c port attribute
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (value_GetPortAttributeReply `fmap` deserialize))
       let req = MkGetPortAttribute port attribute
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryPortAttributes ::
                      Graphics.XHB.Connection.Types.Connection ->
                        PORT -> IO (Receipt QueryPortAttributesReply)
queryPortAttributes c port
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryPortAttributes port
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
listImageFormats ::
                   Graphics.XHB.Connection.Types.Connection ->
                     PORT -> IO (Receipt ListImageFormatsReply)
listImageFormats c port
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkListImageFormats port
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryImageAttributes ::
                       Graphics.XHB.Connection.Types.Connection ->
                         QueryImageAttributes -> IO (Receipt QueryImageAttributesReply)
queryImageAttributes c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
putImage ::
           Graphics.XHB.Connection.Types.Connection -> PutImage -> IO ()
putImage c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
shmPutImage ::
              Graphics.XHB.Connection.Types.Connection -> ShmPutImage -> IO ()
shmPutImage c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk