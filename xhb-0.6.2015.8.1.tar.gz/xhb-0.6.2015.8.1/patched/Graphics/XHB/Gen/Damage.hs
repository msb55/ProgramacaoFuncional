module Graphics.XHB.Gen.Damage
       (extension, queryVersion, create, destroy, subtract, add,
        module Graphics.XHB.Gen.Damage.Types)
       where
import Prelude hiding (subtract)
import Graphics.XHB.Gen.Damage.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
import Graphics.XHB.Gen.XFixes.Types
       hiding (QueryVersion(..), QueryVersionReply(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.XFixes.Types
 
extension :: ExtensionId
extension = "DAMAGE"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word32 -> Word32 -> IO (Receipt QueryVersionReply)
queryVersion c client_major_version client_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion client_major_version client_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
create ::
         Graphics.XHB.Connection.Types.Connection -> Create -> IO ()
create c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
destroy ::
          Graphics.XHB.Connection.Types.Connection -> DAMAGE -> IO ()
destroy c damage
  = do let req = MkDestroy damage
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
subtract ::
           Graphics.XHB.Connection.Types.Connection -> Subtract -> IO ()
subtract c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
add ::
      Graphics.XHB.Connection.Types.Connection ->
        DRAWABLE -> REGION -> IO ()
add c drawable region
  = do let req = MkAdd drawable region
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk