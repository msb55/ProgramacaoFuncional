module Graphics.XHB.Gen.Shm
       (extension, queryVersion, attach, detach, putImage, getImage,
        createPixmap, module Graphics.XHB.Gen.Shm.Types)
       where
import Graphics.XHB.Gen.Shm.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (PutImage(..), GetImage(..), GetImageReply(..),
               CreatePixmap(..), deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "MIT-SHM"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 IO (Receipt QueryVersionReply)
queryVersion c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
attach ::
         Graphics.XHB.Connection.Types.Connection -> Attach -> IO ()
attach c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
detach :: Graphics.XHB.Connection.Types.Connection -> SEG -> IO ()
detach c shmseg
  = do let req = MkDetach shmseg
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
putImage ::
           Graphics.XHB.Connection.Types.Connection -> PutImage -> IO ()
putImage c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getImage ::
           Graphics.XHB.Connection.Types.Connection ->
             GetImage -> IO (Receipt GetImageReply)
getImage c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createPixmap ::
               Graphics.XHB.Connection.Types.Connection -> CreatePixmap -> IO ()
createPixmap c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk