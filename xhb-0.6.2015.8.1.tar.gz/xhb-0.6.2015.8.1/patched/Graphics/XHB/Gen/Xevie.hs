module Graphics.XHB.Gen.Xevie
       (extension, queryVersion, start, end, send, selectInput,
        module Graphics.XHB.Gen.Xevie.Types)
       where
import Graphics.XHB.Gen.Xevie.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
 
extension :: ExtensionId
extension = "XEVIE"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word16 -> Word16 -> IO (Receipt QueryVersionReply)
queryVersion c client_major_version client_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion client_major_version client_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
start ::
        Graphics.XHB.Connection.Types.Connection ->
          Word32 -> IO (Receipt StartReply)
start c screen
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkStart screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
end ::
      Graphics.XHB.Connection.Types.Connection ->
        Word32 -> IO (Receipt EndReply)
end c cmap
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkEnd cmap
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
send ::
       Graphics.XHB.Connection.Types.Connection ->
         Event -> Word32 -> IO (Receipt SendReply)
send c event data_type
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkSend event data_type
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
selectInput ::
              Graphics.XHB.Connection.Types.Connection ->
                Word32 -> IO (Receipt SelectInputReply)
selectInput c event_mask
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkSelectInput event_mask
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt