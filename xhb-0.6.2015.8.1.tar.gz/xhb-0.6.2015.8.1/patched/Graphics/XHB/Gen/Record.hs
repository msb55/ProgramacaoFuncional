module Graphics.XHB.Gen.Record
       (extension, queryVersion, createContext, registerClients,
        unregisterClients, getContext, enableContext, disableContext,
        freeContext, module Graphics.XHB.Gen.Record.Types)
       where
import Graphics.XHB.Gen.Record.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
 
extension :: ExtensionId
extension = "RECORD"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word16 -> Word16 -> IO (Receipt QueryVersionReply)
queryVersion c major_version minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion major_version minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createContext ::
                Graphics.XHB.Connection.Types.Connection -> CreateContext -> IO ()
createContext c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
registerClients ::
                  Graphics.XHB.Connection.Types.Connection ->
                    RegisterClients -> IO ()
registerClients c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
unregisterClients ::
                    Graphics.XHB.Connection.Types.Connection ->
                      UnregisterClients -> IO ()
unregisterClients c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getContext ::
             Graphics.XHB.Connection.Types.Connection ->
               Graphics.XHB.Gen.Record.Types.CONTEXT ->
                 IO (Receipt GetContextReply)
getContext c context
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetContext context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
enableContext ::
                Graphics.XHB.Connection.Types.Connection ->
                  Graphics.XHB.Gen.Record.Types.CONTEXT ->
                    IO (Receipt EnableContextReply)
enableContext c context
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkEnableContext context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
disableContext ::
                 Graphics.XHB.Connection.Types.Connection ->
                   Graphics.XHB.Gen.Record.Types.CONTEXT -> IO ()
disableContext c context
  = do let req = MkDisableContext context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
freeContext ::
              Graphics.XHB.Connection.Types.Connection ->
                Graphics.XHB.Gen.Record.Types.CONTEXT -> IO ()
freeContext c context
  = do let req = MkFreeContext context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk