module Graphics.XHB.Gen.Xinerama
       (extension, queryVersion, getState, getScreenCount, getScreenSize,
        isActive, queryScreens, module Graphics.XHB.Gen.Xinerama.Types)
       where
import Graphics.XHB.Gen.Xinerama.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "XINERAMA"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word8 -> Word8 -> IO (Receipt QueryVersionReply)
queryVersion c major minor
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion major minor
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getState ::
           Graphics.XHB.Connection.Types.Connection ->
             WINDOW -> IO (Receipt GetStateReply)
getState c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetState window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getScreenCount ::
                 Graphics.XHB.Connection.Types.Connection ->
                   WINDOW -> IO (Receipt GetScreenCountReply)
getScreenCount c window
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetScreenCount window
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getScreenSize ::
                Graphics.XHB.Connection.Types.Connection ->
                  WINDOW -> Word32 -> IO (Receipt GetScreenSizeReply)
getScreenSize c window screen
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetScreenSize window screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
isActive ::
           Graphics.XHB.Connection.Types.Connection -> IO (Receipt Word32)
isActive c
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (state_IsActiveReply `fmap` deserialize))
       let req = MkIsActive
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryScreens ::
               Graphics.XHB.Connection.Types.Connection ->
                 IO (Receipt QueryScreensReply)
queryScreens c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryScreens
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt