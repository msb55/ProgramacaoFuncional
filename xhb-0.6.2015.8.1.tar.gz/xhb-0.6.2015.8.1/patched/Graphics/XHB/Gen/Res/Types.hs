module Graphics.XHB.Gen.Res.Types
       (deserializeError, deserializeEvent, Client(..), Type(..),
        QueryVersion(..), QueryVersionReply(..), QueryClients(..),
        QueryClientsReply(..), QueryClientResources(..),
        QueryClientResourcesReply(..), QueryClientPixmapBytes(..),
        QueryClientPixmapBytesReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data Client = MkClient{resource_base_Client :: Word32,
                       resource_mask_Client :: Word32}
            deriving (Show, Typeable, Eq, Ord)
 
instance Serialize Client where
        serialize x
          = do serialize (resource_base_Client x)
               serialize (resource_mask_Client x)
        size x
          = size (resource_base_Client x) + size (resource_mask_Client x)
 
instance Deserialize Client where
        deserialize
          = do resource_base <- deserialize
               resource_mask <- deserialize
               return (MkClient resource_base resource_mask)
 
data Type = MkType{resource_type_Type :: ATOM,
                   count_Type :: Word32}
          deriving (Show, Typeable, Eq, Ord)
 
instance Serialize Type where
        serialize x
          = do serialize (resource_type_Type x)
               serialize (count_Type x)
        size x = size (resource_type_Type x) + size (count_Type x)
 
instance Deserialize Type where
        deserialize
          = do resource_type <- deserialize
               count <- deserialize
               return (MkType resource_type count)
 
data QueryVersion = MkQueryVersion{client_major_QueryVersion ::
                                   Word8,
                                   client_minor_QueryVersion :: Word8}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "X-Resource"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_QueryVersion x) +
                         size (client_minor_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_QueryVersion x)
               serialize (client_minor_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{server_major_QueryVersionReply
                                             :: Word16,
                                             server_minor_QueryVersionReply :: Word16}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               server_major <- deserialize
               server_minor <- deserialize
               let _ = isCard32 length
               return (MkQueryVersionReply server_major server_minor)
 
data QueryClients = MkQueryClients{}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryClients where
        extensionId _ = "X-Resource"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data QueryClientsReply = MkQueryClientsReply{num_clients_QueryClientsReply
                                             :: Word32,
                                             clients_QueryClientsReply :: [Client]}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryClientsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_clients <- deserialize
               skip 20
               clients <- deserializeList (fromIntegral num_clients)
               let _ = isCard32 length
               return (MkQueryClientsReply num_clients clients)
 
data QueryClientResources = MkQueryClientResources{xid_QueryClientResources
                                                   :: Word32}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryClientResources where
        extensionId _ = "X-Resource"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4 + size (xid_QueryClientResources x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (xid_QueryClientResources x)
               putSkip (requiredPadding size__)
 
data QueryClientResourcesReply = MkQueryClientResourcesReply{num_types_QueryClientResourcesReply
                                                             :: Word32,
                                                             types_QueryClientResourcesReply ::
                                                             [Type]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryClientResourcesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               num_types <- deserialize
               skip 20
               types <- deserializeList (fromIntegral num_types)
               let _ = isCard32 length
               return (MkQueryClientResourcesReply num_types types)
 
data QueryClientPixmapBytes = MkQueryClientPixmapBytes{xid_QueryClientPixmapBytes
                                                       :: Word32}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryClientPixmapBytes where
        extensionId _ = "X-Resource"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__ = 4 + size (xid_QueryClientPixmapBytes x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (xid_QueryClientPixmapBytes x)
               putSkip (requiredPadding size__)
 
data QueryClientPixmapBytesReply = MkQueryClientPixmapBytesReply{bytes_QueryClientPixmapBytesReply
                                                                 :: Word32,
                                                                 bytes_overflow_QueryClientPixmapBytesReply
                                                                 :: Word32}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryClientPixmapBytesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               bytes <- deserialize
               bytes_overflow <- deserialize
               let _ = isCard32 length
               return (MkQueryClientPixmapBytesReply bytes bytes_overflow)