module Graphics.XHB.Gen.ScreenSaver.Types
       (deserializeError, deserializeEvent, Kind(..), Event(..),
        State(..), QueryVersion(..), QueryVersionReply(..), QueryInfo(..),
        QueryInfoReply(..), SelectInput(..), SetAttributes(..),
        UnsetAttributes(..), Suspend(..), NotifyEvent(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get NotifyEvent))
deserializeEvent _ = Nothing
 
data Kind = KindBlanked
          | KindInternal
          | KindExternal
          deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Kind where
        toValue KindBlanked{} = 0
        toValue KindInternal{} = 1
        toValue KindExternal{} = 2
        fromValue 0 = KindBlanked
        fromValue 1 = KindInternal
        fromValue 2 = KindExternal
 
data Event = EventNotifyMask
           | EventCycleMask
           deriving (Show, Eq, Ord, Enum, Typeable)
 
instance BitEnum Event where
        toBit EventNotifyMask{} = 0
        toBit EventCycleMask{} = 1
        fromBit 0 = EventNotifyMask
        fromBit 1 = EventCycleMask
 
data State = StateOff
           | StateOn
           | StateCycle
           | StateDisabled
           deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum State where
        toValue StateOff{} = 0
        toValue StateOn{} = 1
        toValue StateCycle{} = 2
        toValue StateDisabled{} = 3
        fromValue 0 = StateOff
        fromValue 1 = StateOn
        fromValue 2 = StateCycle
        fromValue 3 = StateDisabled
 
data QueryVersion = MkQueryVersion{client_major_version_QueryVersion
                                   :: Word8,
                                   client_minor_version_QueryVersion :: Word8}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "MIT-SCREEN-SAVER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_version_QueryVersion x) +
                         size (client_minor_version_QueryVersion x)
                         + 2
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_version_QueryVersion x)
               serialize (client_minor_version_QueryVersion x)
               putSkip 2
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{server_major_version_QueryVersionReply
                                             :: Word16,
                                             server_minor_version_QueryVersionReply :: Word16}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               server_major_version <- deserialize
               server_minor_version <- deserialize
               skip 20
               let _ = isCard32 length
               return
                 (MkQueryVersionReply server_major_version server_minor_version)
 
data QueryInfo = MkQueryInfo{drawable_QueryInfo :: DRAWABLE}
               deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryInfo where
        extensionId _ = "MIT-SCREEN-SAVER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4 + size (drawable_QueryInfo x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_QueryInfo x)
               putSkip (requiredPadding size__)
 
data QueryInfoReply = MkQueryInfoReply{state_QueryInfoReply ::
                                       Word8,
                                       saver_window_QueryInfoReply :: WINDOW,
                                       ms_until_server_QueryInfoReply :: Word32,
                                       ms_since_user_input_QueryInfoReply :: Word32,
                                       event_mask_QueryInfoReply :: Word32,
                                       kind_QueryInfoReply :: Word8}
                    deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryInfoReply where
        deserialize
          = do skip 1
               state <- deserialize
               skip 2
               length <- deserialize
               saver_window <- deserialize
               ms_until_server <- deserialize
               ms_since_user_input <- deserialize
               event_mask <- deserialize
               kind <- deserialize
               skip 7
               let _ = isCard32 length
               return
                 (MkQueryInfoReply state saver_window ms_until_server
                    ms_since_user_input
                    event_mask
                    kind)
 
data SelectInput = MkSelectInput{drawable_SelectInput :: DRAWABLE,
                                 event_mask_SelectInput :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SelectInput where
        extensionId _ = "MIT-SCREEN-SAVER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (drawable_SelectInput x) +
                         size (event_mask_SelectInput x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_SelectInput x)
               serialize (event_mask_SelectInput x)
               putSkip (requiredPadding size__)
 
data SetAttributes = MkSetAttributes{drawable_SetAttributes ::
                                     DRAWABLE,
                                     x_SetAttributes :: Int16, y_SetAttributes :: Int16,
                                     width_SetAttributes :: Word16, height_SetAttributes :: Word16,
                                     border_width_SetAttributes :: Word16,
                                     class_SetAttributes :: Word8, depth_SetAttributes :: Word8,
                                     visual_SetAttributes :: VISUALID,
                                     value_SetAttributes :: ValueParam Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SetAttributes where
        extensionId _ = "MIT-SCREEN-SAVER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (drawable_SetAttributes x) + size (x_SetAttributes x) +
                         size (y_SetAttributes x)
                         + size (width_SetAttributes x)
                         + size (height_SetAttributes x)
                         + size (border_width_SetAttributes x)
                         + size (class_SetAttributes x)
                         + size (depth_SetAttributes x)
                         + size (visual_SetAttributes x)
                         + size (value_SetAttributes x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_SetAttributes x)
               serialize (x_SetAttributes x)
               serialize (y_SetAttributes x)
               serialize (width_SetAttributes x)
               serialize (height_SetAttributes x)
               serialize (border_width_SetAttributes x)
               serialize (class_SetAttributes x)
               serialize (depth_SetAttributes x)
               serialize (visual_SetAttributes x)
               serialize (value_SetAttributes x)
               putSkip (requiredPadding size__)
 
data UnsetAttributes = MkUnsetAttributes{drawable_UnsetAttributes
                                         :: DRAWABLE}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest UnsetAttributes where
        extensionId _ = "MIT-SCREEN-SAVER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4 + size (drawable_UnsetAttributes x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_UnsetAttributes x)
               putSkip (requiredPadding size__)
 
data Suspend = MkSuspend{suspend_Suspend :: Bool}
             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Suspend where
        extensionId _ = "MIT-SCREEN-SAVER"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__ = 4 + size (suspend_Suspend x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (suspend_Suspend x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data NotifyEvent = MkNotifyEvent{code_NotifyEvent :: Word8,
                                 state_NotifyEvent :: Word8, sequence_number_NotifyEvent :: Word16,
                                 time_NotifyEvent :: TIMESTAMP, root_NotifyEvent :: WINDOW,
                                 window_NotifyEvent :: WINDOW, kind_NotifyEvent :: Word8,
                                 forced_NotifyEvent :: Bool}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event NotifyEvent
 
instance Deserialize NotifyEvent where
        deserialize
          = do skip 1
               code <- deserialize
               skip 2
               state <- deserialize
               skip 1
               sequence_number <- deserialize
               time <- deserialize
               root <- deserialize
               window <- deserialize
               kind <- deserialize
               forced <- deserialize
               skip 14
               return
                 (MkNotifyEvent code state sequence_number time root window kind
                    forced)