module Graphics.XHB.Gen.Test
       (extension, getVersion, compareCursor, fakeInput, grabControl,
        module Graphics.XHB.Gen.Test.Types)
       where
import Graphics.XHB.Gen.Test.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (Cursor(..), deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "XTEST"
 
getVersion ::
             Graphics.XHB.Connection.Types.Connection ->
               Word8 -> Word16 -> IO (Receipt GetVersionReply)
getVersion c major_version minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetVersion major_version minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
compareCursor ::
                Graphics.XHB.Connection.Types.Connection ->
                  WINDOW -> CURSOR -> IO (Receipt Bool)
compareCursor c window cursor
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (same_CompareCursorReply `fmap` deserialize))
       let req = MkCompareCursor window cursor
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
fakeInput ::
            Graphics.XHB.Connection.Types.Connection -> FakeInput -> IO ()
fakeInput c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
grabControl ::
              Graphics.XHB.Connection.Types.Connection -> Bool -> IO ()
grabControl c impervious
  = do let req = MkGrabControl impervious
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk