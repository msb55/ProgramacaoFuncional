module Graphics.XHB.Gen.Render
       (extension, queryVersion, queryPictFormats, queryPictIndexValues,
        createPicture, changePicture, setPictureClipRectangles,
        freePicture, composite, trapezoids, triangles, triStrip, triFan,
        createGlyphSet, referenceGlyphSet, freeGlyphSet, addGlyphs,
        freeGlyphs, compositeGlyphs8, compositeGlyphs16, compositeGlyphs32,
        fillRectangles, createCursor, setPictureTransform, queryFilters,
        setPictureFilter, createAnimCursor, addTraps, createSolidFill,
        createLinearGradient, createRadialGradient, createConicalGradient,
        module Graphics.XHB.Gen.Render.Types)
       where
import Graphics.XHB.Gen.Render.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (CreateCursor(..), deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "RENDER"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word32 -> Word32 -> IO (Receipt QueryVersionReply)
queryVersion c client_major_version client_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion client_major_version client_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryPictFormats ::
                   Graphics.XHB.Connection.Types.Connection ->
                     IO (Receipt QueryPictFormatsReply)
queryPictFormats c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryPictFormats
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryPictIndexValues ::
                       Graphics.XHB.Connection.Types.Connection ->
                         PICTFORMAT -> IO (Receipt QueryPictIndexValuesReply)
queryPictIndexValues c format
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryPictIndexValues format
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createPicture ::
                Graphics.XHB.Connection.Types.Connection -> CreatePicture -> IO ()
createPicture c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
changePicture ::
                Graphics.XHB.Connection.Types.Connection ->
                  PICTURE -> ValueParam Word32 -> IO ()
changePicture c picture value
  = do let req = MkChangePicture picture value
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setPictureClipRectangles ::
                           Graphics.XHB.Connection.Types.Connection ->
                             SetPictureClipRectangles -> IO ()
setPictureClipRectangles c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
freePicture ::
              Graphics.XHB.Connection.Types.Connection -> PICTURE -> IO ()
freePicture c picture
  = do let req = MkFreePicture picture
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
composite ::
            Graphics.XHB.Connection.Types.Connection -> Composite -> IO ()
composite c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
trapezoids ::
             Graphics.XHB.Connection.Types.Connection -> Trapezoids -> IO ()
trapezoids c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
triangles ::
            Graphics.XHB.Connection.Types.Connection -> Triangles -> IO ()
triangles c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
triStrip ::
           Graphics.XHB.Connection.Types.Connection -> TriStrip -> IO ()
triStrip c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
triFan ::
         Graphics.XHB.Connection.Types.Connection -> TriFan -> IO ()
triFan c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createGlyphSet ::
                 Graphics.XHB.Connection.Types.Connection ->
                   GLYPHSET -> PICTFORMAT -> IO ()
createGlyphSet c gsid format
  = do let req = MkCreateGlyphSet gsid format
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
referenceGlyphSet ::
                    Graphics.XHB.Connection.Types.Connection ->
                      GLYPHSET -> GLYPHSET -> IO ()
referenceGlyphSet c gsid existing
  = do let req = MkReferenceGlyphSet gsid existing
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
freeGlyphSet ::
               Graphics.XHB.Connection.Types.Connection -> GLYPHSET -> IO ()
freeGlyphSet c glyphset
  = do let req = MkFreeGlyphSet glyphset
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
addGlyphs ::
            Graphics.XHB.Connection.Types.Connection -> AddGlyphs -> IO ()
addGlyphs c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
freeGlyphs ::
             Graphics.XHB.Connection.Types.Connection ->
               GLYPHSET -> [GLYPH] -> IO ()
freeGlyphs c glyphset glyphs
  = do let req = MkFreeGlyphs glyphset glyphs
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
compositeGlyphs8 ::
                   Graphics.XHB.Connection.Types.Connection ->
                     CompositeGlyphs8 -> IO ()
compositeGlyphs8 c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
compositeGlyphs16 ::
                    Graphics.XHB.Connection.Types.Connection ->
                      CompositeGlyphs16 -> IO ()
compositeGlyphs16 c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
compositeGlyphs32 ::
                    Graphics.XHB.Connection.Types.Connection ->
                      CompositeGlyphs32 -> IO ()
compositeGlyphs32 c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
fillRectangles ::
                 Graphics.XHB.Connection.Types.Connection -> FillRectangles -> IO ()
fillRectangles c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createCursor ::
               Graphics.XHB.Connection.Types.Connection -> CreateCursor -> IO ()
createCursor c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setPictureTransform ::
                      Graphics.XHB.Connection.Types.Connection ->
                        PICTURE -> TRANSFORM -> IO ()
setPictureTransform c picture transform
  = do let req = MkSetPictureTransform picture transform
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
queryFilters ::
               Graphics.XHB.Connection.Types.Connection ->
                 DRAWABLE -> IO (Receipt QueryFiltersReply)
queryFilters c drawable
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryFilters drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setPictureFilter ::
                   Graphics.XHB.Connection.Types.Connection ->
                     SetPictureFilter -> IO ()
setPictureFilter c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createAnimCursor ::
                   Graphics.XHB.Connection.Types.Connection ->
                     CURSOR -> [ANIMCURSORELT] -> IO ()
createAnimCursor c cid cursors
  = do let req = MkCreateAnimCursor cid cursors
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
addTraps ::
           Graphics.XHB.Connection.Types.Connection -> AddTraps -> IO ()
addTraps c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createSolidFill ::
                  Graphics.XHB.Connection.Types.Connection ->
                    PICTURE -> COLOR -> IO ()
createSolidFill c picture color
  = do let req = MkCreateSolidFill picture color
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createLinearGradient ::
                       Graphics.XHB.Connection.Types.Connection ->
                         CreateLinearGradient -> IO ()
createLinearGradient c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createRadialGradient ::
                       Graphics.XHB.Connection.Types.Connection ->
                         CreateRadialGradient -> IO ()
createRadialGradient c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createConicalGradient ::
                        Graphics.XHB.Connection.Types.Connection ->
                          CreateConicalGradient -> IO ()
createConicalGradient c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk