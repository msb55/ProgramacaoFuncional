module Graphics.XHB.Gen.Shm.Types
       (deserializeError, deserializeEvent, SEG, CompletionEvent(..),
        BadSegError(..), QueryVersion(..), QueryVersionReply(..),
        Attach(..), Detach(..), PutImage(..), GetImage(..),
        GetImageReply(..), CreatePixmap(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (PutImage(..), GetImage(..), GetImageReply(..),
               CreatePixmap(..), deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError 0
  = return (liftM toError (deserialize :: Get BadSegError))
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get CompletionEvent))
deserializeEvent _ = Nothing
 
newtype SEG = MkSEG Xid
              deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
data CompletionEvent = MkCompletionEvent{drawable_CompletionEvent
                                         :: DRAWABLE,
                                         minor_event_CompletionEvent :: Word16,
                                         major_event_CompletionEvent :: Word8,
                                         shmseg_CompletionEvent :: SEG,
                                         offset_CompletionEvent :: Word32}
                     deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event CompletionEvent
 
instance Deserialize CompletionEvent where
        deserialize
          = do skip 1
               skip 1
               skip 2
               drawable <- deserialize
               minor_event <- deserialize
               major_event <- deserialize
               skip 1
               shmseg <- deserialize
               offset <- deserialize
               return
                 (MkCompletionEvent drawable minor_event major_event shmseg offset)
 
data BadSegError = MkBadSegError{bad_value_BadSegError :: Word32,
                                 minor_opcode_BadSegError :: Word16,
                                 major_opcode_BadSegError :: Word8}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Error BadSegError
 
instance Deserialize BadSegError where
        deserialize
          = do skip 4
               bad_value <- deserialize
               minor_opcode <- deserialize
               major_opcode <- deserialize
               skip 1
               return (MkBadSegError bad_value minor_opcode major_opcode)
 
data QueryVersion = MkQueryVersion{}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "MIT-SHM"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{shared_pixmaps_QueryVersionReply
                                             :: Bool,
                                             major_version_QueryVersionReply :: Word16,
                                             minor_version_QueryVersionReply :: Word16,
                                             uid_QueryVersionReply :: Word16,
                                             gid_QueryVersionReply :: Word16,
                                             pixmap_format_QueryVersionReply :: Word8}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               shared_pixmaps <- deserialize
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               uid <- deserialize
               gid <- deserialize
               pixmap_format <- deserialize
               skip 15
               let _ = isCard32 length
               return
                 (MkQueryVersionReply shared_pixmaps major_version minor_version uid
                    gid
                    pixmap_format)
 
data Attach = MkAttach{shmseg_Attach :: SEG,
                       shmid_Attach :: Word32, read_only_Attach :: Bool}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Attach where
        extensionId _ = "MIT-SHM"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (shmseg_Attach x) + size (shmid_Attach x) +
                         size (read_only_Attach x)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (shmseg_Attach x)
               serialize (shmid_Attach x)
               serialize (read_only_Attach x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data Detach = MkDetach{shmseg_Detach :: SEG}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Detach where
        extensionId _ = "MIT-SHM"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4 + size (shmseg_Detach x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (shmseg_Detach x)
               putSkip (requiredPadding size__)
 
data PutImage = MkPutImage{drawable_PutImage :: DRAWABLE,
                           gc_PutImage :: GCONTEXT, total_width_PutImage :: Word16,
                           total_height_PutImage :: Word16, src_x_PutImage :: Word16,
                           src_y_PutImage :: Word16, src_width_PutImage :: Word16,
                           src_height_PutImage :: Word16, dst_x_PutImage :: Int16,
                           dst_y_PutImage :: Int16, depth_PutImage :: Word8,
                           format_PutImage :: Word8, send_event_PutImage :: Word8,
                           shmseg_PutImage :: SEG, offset_PutImage :: Word32}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PutImage where
        extensionId _ = "MIT-SHM"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (drawable_PutImage x) + size (gc_PutImage x) +
                         size (total_width_PutImage x)
                         + size (total_height_PutImage x)
                         + size (src_x_PutImage x)
                         + size (src_y_PutImage x)
                         + size (src_width_PutImage x)
                         + size (src_height_PutImage x)
                         + size (dst_x_PutImage x)
                         + size (dst_y_PutImage x)
                         + size (depth_PutImage x)
                         + size (format_PutImage x)
                         + size (send_event_PutImage x)
                         + 1
                         + size (shmseg_PutImage x)
                         + size (offset_PutImage x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_PutImage x)
               serialize (gc_PutImage x)
               serialize (total_width_PutImage x)
               serialize (total_height_PutImage x)
               serialize (src_x_PutImage x)
               serialize (src_y_PutImage x)
               serialize (src_width_PutImage x)
               serialize (src_height_PutImage x)
               serialize (dst_x_PutImage x)
               serialize (dst_y_PutImage x)
               serialize (depth_PutImage x)
               serialize (format_PutImage x)
               serialize (send_event_PutImage x)
               putSkip 1
               serialize (shmseg_PutImage x)
               serialize (offset_PutImage x)
               putSkip (requiredPadding size__)
 
data GetImage = MkGetImage{drawable_GetImage :: DRAWABLE,
                           x_GetImage :: Int16, y_GetImage :: Int16, width_GetImage :: Word16,
                           height_GetImage :: Word16, plane_mask_GetImage :: Word32,
                           format_GetImage :: Word8, shmseg_GetImage :: SEG,
                           offset_GetImage :: Word32}
              deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetImage where
        extensionId _ = "MIT-SHM"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__
                     = 4 + size (drawable_GetImage x) + size (x_GetImage x) +
                         size (y_GetImage x)
                         + size (width_GetImage x)
                         + size (height_GetImage x)
                         + size (plane_mask_GetImage x)
                         + size (format_GetImage x)
                         + 3
                         + size (shmseg_GetImage x)
                         + size (offset_GetImage x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_GetImage x)
               serialize (x_GetImage x)
               serialize (y_GetImage x)
               serialize (width_GetImage x)
               serialize (height_GetImage x)
               serialize (plane_mask_GetImage x)
               serialize (format_GetImage x)
               putSkip 3
               serialize (shmseg_GetImage x)
               serialize (offset_GetImage x)
               putSkip (requiredPadding size__)
 
data GetImageReply = MkGetImageReply{depth_GetImageReply :: Word8,
                                     visual_GetImageReply :: VISUALID, size_GetImageReply :: Word32}
                   deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetImageReply where
        deserialize
          = do skip 1
               depth <- deserialize
               skip 2
               length <- deserialize
               visual <- deserialize
               size <- deserialize
               let _ = isCard32 length
               return (MkGetImageReply depth visual size)
 
data CreatePixmap = MkCreatePixmap{pid_CreatePixmap :: PIXMAP,
                                   drawable_CreatePixmap :: DRAWABLE, width_CreatePixmap :: Word16,
                                   height_CreatePixmap :: Word16, depth_CreatePixmap :: Word8,
                                   shmseg_CreatePixmap :: SEG, offset_CreatePixmap :: Word32}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreatePixmap where
        extensionId _ = "MIT-SHM"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__
                     = 4 + size (pid_CreatePixmap x) + size (drawable_CreatePixmap x) +
                         size (width_CreatePixmap x)
                         + size (height_CreatePixmap x)
                         + size (depth_CreatePixmap x)
                         + 3
                         + size (shmseg_CreatePixmap x)
                         + size (offset_CreatePixmap x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (pid_CreatePixmap x)
               serialize (drawable_CreatePixmap x)
               serialize (width_CreatePixmap x)
               serialize (height_CreatePixmap x)
               serialize (depth_CreatePixmap x)
               putSkip 3
               serialize (shmseg_CreatePixmap x)
               serialize (offset_CreatePixmap x)
               putSkip (requiredPadding size__)