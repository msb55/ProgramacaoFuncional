module Graphics.XHB.Gen.BigRequests
       (extension, enable, module Graphics.XHB.Gen.BigRequests.Types)
       where
import Graphics.XHB.Gen.BigRequests.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
 
extension :: ExtensionId
extension = "BIG-REQUESTS"
 
enable ::
         Graphics.XHB.Connection.Types.Connection -> IO (Receipt Word32)
enable c
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (maximum_request_length_EnableReply `fmap` deserialize))
       let req = MkEnable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt