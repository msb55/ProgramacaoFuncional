module Graphics.XHB.Gen.BigRequests.Types
       (deserializeError, deserializeEvent, Enable(..), EnableReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data Enable = MkEnable{}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Enable where
        extensionId _ = "BIG-REQUESTS"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data EnableReply = MkEnableReply{maximum_request_length_EnableReply
                                 :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize EnableReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               maximum_request_length <- deserialize
               let _ = isCard32 length
               return (MkEnableReply maximum_request_length)