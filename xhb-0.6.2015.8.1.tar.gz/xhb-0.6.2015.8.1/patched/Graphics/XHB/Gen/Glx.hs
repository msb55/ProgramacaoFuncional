module Graphics.XHB.Gen.Glx
       (extension, render, renderLarge, createContext, destroyContext,
        makeCurrent, isDirect, queryVersion, waitGL, waitX, copyContext,
        swapBuffers, useXFont, createGLXPixmap, getVisualConfigs,
        destroyGLXPixmap, vendorPrivate, vendorPrivateWithReply,
        queryExtensionsString, queryServerString, clientInfo, getFBConfigs,
        createPixmap, destroyPixmap, createNewContext, queryContext,
        makeContextCurrent, createPbuffer, destroyPbuffer,
        getDrawableAttributes, changeDrawableAttributes, createWindow,
        deleteWindow, newList, endList, deleteLists, genLists,
        feedbackBuffer, selectBuffer, renderMode, finish, pixelStoref,
        pixelStorei, readPixels, getBooleanv, getClipPlane, getDoublev,
        getError, getFloatv, getIntegerv, getLightfv, getLightiv, getMapdv,
        getMapfv, getMapiv, getMaterialfv, getMaterialiv, getPixelMapfv,
        getPixelMapuiv, getPixelMapusv, getPolygonStipple, getString,
        getTexEnvfv, getTexEnviv, getTexGendv, getTexGenfv, getTexGeniv,
        getTexImage, getTexParameterfv, getTexParameteriv,
        getTexLevelParameterfv, getTexLevelParameteriv, isList, flush,
        areTexturesResident, deleteTextures, genTextures, isTexture,
        getColorTable, getColorTableParameterfv, getColorTableParameteriv,
        getConvolutionFilter, getConvolutionParameterfv,
        getConvolutionParameteriv, getSeparableFilter, getHistogram,
        getHistogramParameterfv, getHistogramParameteriv, getMinmax,
        getMinmaxParameterfv, getMinmaxParameteriv,
        getCompressedTexImageARB, deleteQueriesARB, genQueriesARB,
        isQueryARB, getQueryivARB, getQueryObjectivARB,
        getQueryObjectuivARB, module Graphics.XHB.Gen.Glx.Types)
       where
import Graphics.XHB.Gen.Glx.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (PIXMAP(..), WINDOW(..), DRAWABLE(..), GC(..),
               CreatePixmap(..), CreateWindow(..), deserializeError,
               deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "GLX"
 
render ::
         Graphics.XHB.Connection.Types.Connection ->
           CONTEXT_TAG -> [Word8] -> IO ()
render c context_tag data_
  = do let req = MkRender context_tag data_
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
renderLarge ::
              Graphics.XHB.Connection.Types.Connection -> RenderLarge -> IO ()
renderLarge c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createContext ::
                Graphics.XHB.Connection.Types.Connection -> CreateContext -> IO ()
createContext c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
destroyContext ::
                 Graphics.XHB.Connection.Types.Connection ->
                   Graphics.XHB.Gen.Glx.Types.CONTEXT -> IO ()
destroyContext c context
  = do let req = MkDestroyContext context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
makeCurrent ::
              Graphics.XHB.Connection.Types.Connection ->
                MakeCurrent -> IO (Receipt CONTEXT_TAG)
makeCurrent c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (context_tag_MakeCurrentReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
isDirect ::
           Graphics.XHB.Connection.Types.Connection ->
             Graphics.XHB.Gen.Glx.Types.CONTEXT -> IO (Receipt Bool)
isDirect c context
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (is_direct_IsDirectReply `fmap` deserialize))
       let req = MkIsDirect context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word32 -> Word32 -> IO (Receipt QueryVersionReply)
queryVersion c major_version minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion major_version minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
waitGL ::
         Graphics.XHB.Connection.Types.Connection -> CONTEXT_TAG -> IO ()
waitGL c context_tag
  = do let req = MkWaitGL context_tag
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
waitX ::
        Graphics.XHB.Connection.Types.Connection -> CONTEXT_TAG -> IO ()
waitX c context_tag
  = do let req = MkWaitX context_tag
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
copyContext ::
              Graphics.XHB.Connection.Types.Connection -> CopyContext -> IO ()
copyContext c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
swapBuffers ::
              Graphics.XHB.Connection.Types.Connection ->
                CONTEXT_TAG -> Graphics.XHB.Gen.Glx.Types.DRAWABLE -> IO ()
swapBuffers c context_tag drawable
  = do let req = MkSwapBuffers context_tag drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
useXFont ::
           Graphics.XHB.Connection.Types.Connection -> UseXFont -> IO ()
useXFont c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createGLXPixmap ::
                  Graphics.XHB.Connection.Types.Connection ->
                    CreateGLXPixmap -> IO ()
createGLXPixmap c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getVisualConfigs ::
                   Graphics.XHB.Connection.Types.Connection ->
                     Word32 -> IO (Receipt GetVisualConfigsReply)
getVisualConfigs c screen
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetVisualConfigs screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
destroyGLXPixmap ::
                   Graphics.XHB.Connection.Types.Connection ->
                     Graphics.XHB.Gen.Glx.Types.PIXMAP -> IO ()
destroyGLXPixmap c glx_pixmap
  = do let req = MkDestroyGLXPixmap glx_pixmap
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
vendorPrivate ::
                Graphics.XHB.Connection.Types.Connection -> VendorPrivate -> IO ()
vendorPrivate c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
vendorPrivateWithReply ::
                         Graphics.XHB.Connection.Types.Connection ->
                           VendorPrivateWithReply -> IO (Receipt VendorPrivateWithReplyReply)
vendorPrivateWithReply c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryExtensionsString ::
                        Graphics.XHB.Connection.Types.Connection ->
                          Word32 -> IO (Receipt Word32)
queryExtensionsString c screen
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (n_QueryExtensionsStringReply `fmap` deserialize))
       let req = MkQueryExtensionsString screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryServerString ::
                    Graphics.XHB.Connection.Types.Connection ->
                      Word32 -> Word32 -> IO (Receipt QueryServerStringReply)
queryServerString c screen name
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryServerString screen name
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
clientInfo ::
             Graphics.XHB.Connection.Types.Connection -> ClientInfo -> IO ()
clientInfo c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getFBConfigs ::
               Graphics.XHB.Connection.Types.Connection ->
                 Word32 -> IO (Receipt GetFBConfigsReply)
getFBConfigs c screen
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetFBConfigs screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createPixmap ::
               Graphics.XHB.Connection.Types.Connection -> CreatePixmap -> IO ()
createPixmap c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
destroyPixmap ::
                Graphics.XHB.Connection.Types.Connection ->
                  Graphics.XHB.Gen.Glx.Types.PIXMAP -> IO ()
destroyPixmap c glx_pixmap
  = do let req = MkDestroyPixmap glx_pixmap
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createNewContext ::
                   Graphics.XHB.Connection.Types.Connection ->
                     CreateNewContext -> IO ()
createNewContext c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
queryContext ::
               Graphics.XHB.Connection.Types.Connection ->
                 Graphics.XHB.Gen.Glx.Types.CONTEXT ->
                   IO (Receipt QueryContextReply)
queryContext c context
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryContext context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
makeContextCurrent ::
                     Graphics.XHB.Connection.Types.Connection ->
                       MakeContextCurrent -> IO (Receipt CONTEXT_TAG)
makeContextCurrent c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (context_tag_MakeContextCurrentReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createPbuffer ::
                Graphics.XHB.Connection.Types.Connection -> CreatePbuffer -> IO ()
createPbuffer c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
destroyPbuffer ::
                 Graphics.XHB.Connection.Types.Connection -> PBUFFER -> IO ()
destroyPbuffer c pbuffer
  = do let req = MkDestroyPbuffer pbuffer
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getDrawableAttributes ::
                        Graphics.XHB.Connection.Types.Connection ->
                          Graphics.XHB.Gen.Glx.Types.DRAWABLE ->
                            IO (Receipt GetDrawableAttributesReply)
getDrawableAttributes c drawable
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDrawableAttributes drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
changeDrawableAttributes ::
                           Graphics.XHB.Connection.Types.Connection ->
                             ChangeDrawableAttributes -> IO ()
changeDrawableAttributes c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createWindow ::
               Graphics.XHB.Connection.Types.Connection -> CreateWindow -> IO ()
createWindow c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
deleteWindow ::
               Graphics.XHB.Connection.Types.Connection ->
                 Graphics.XHB.Gen.Glx.Types.WINDOW -> IO ()
deleteWindow c glxwindow
  = do let req = MkDeleteWindow glxwindow
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
newList ::
          Graphics.XHB.Connection.Types.Connection -> NewList -> IO ()
newList c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
endList ::
          Graphics.XHB.Connection.Types.Connection -> CONTEXT_TAG -> IO ()
endList c context_tag
  = do let req = MkEndList context_tag
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
deleteLists ::
              Graphics.XHB.Connection.Types.Connection -> DeleteLists -> IO ()
deleteLists c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
genLists ::
           Graphics.XHB.Connection.Types.Connection ->
             CONTEXT_TAG -> Int32 -> IO (Receipt Word32)
genLists c context_tag range
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (ret_val_GenListsReply `fmap` deserialize))
       let req = MkGenLists context_tag range
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
feedbackBuffer ::
                 Graphics.XHB.Connection.Types.Connection -> FeedbackBuffer -> IO ()
feedbackBuffer c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
selectBuffer ::
               Graphics.XHB.Connection.Types.Connection ->
                 CONTEXT_TAG -> Int32 -> IO ()
selectBuffer c context_tag size
  = do let req = MkSelectBuffer context_tag size
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
renderMode ::
             Graphics.XHB.Connection.Types.Connection ->
               CONTEXT_TAG -> Word32 -> IO (Receipt RenderModeReply)
renderMode c context_tag mode
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkRenderMode context_tag mode
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
finish ::
         Graphics.XHB.Connection.Types.Connection ->
           CONTEXT_TAG -> IO (Receipt FinishReply)
finish c context_tag
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkFinish context_tag
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
pixelStoref ::
              Graphics.XHB.Connection.Types.Connection -> PixelStoref -> IO ()
pixelStoref c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
pixelStorei ::
              Graphics.XHB.Connection.Types.Connection -> PixelStorei -> IO ()
pixelStorei c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
readPixels ::
             Graphics.XHB.Connection.Types.Connection ->
               ReadPixels -> IO (Receipt [Word8])
readPixels c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (data_ReadPixelsReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getBooleanv ::
              Graphics.XHB.Connection.Types.Connection ->
                CONTEXT_TAG -> Int32 -> IO (Receipt GetBooleanvReply)
getBooleanv c context_tag pname
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetBooleanv context_tag pname
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getClipPlane ::
               Graphics.XHB.Connection.Types.Connection ->
                 CONTEXT_TAG -> Int32 -> IO (Receipt [FLOAT64])
getClipPlane c context_tag plane
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (data_GetClipPlaneReply `fmap` deserialize))
       let req = MkGetClipPlane context_tag plane
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getDoublev ::
             Graphics.XHB.Connection.Types.Connection ->
               CONTEXT_TAG -> Word32 -> IO (Receipt GetDoublevReply)
getDoublev c context_tag pname
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDoublev context_tag pname
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getError ::
           Graphics.XHB.Connection.Types.Connection ->
             CONTEXT_TAG -> IO (Receipt Int32)
getError c context_tag
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (error_GetErrorReply `fmap` deserialize))
       let req = MkGetError context_tag
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getFloatv ::
            Graphics.XHB.Connection.Types.Connection ->
              CONTEXT_TAG -> Word32 -> IO (Receipt GetFloatvReply)
getFloatv c context_tag pname
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetFloatv context_tag pname
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getIntegerv ::
              Graphics.XHB.Connection.Types.Connection ->
                CONTEXT_TAG -> Word32 -> IO (Receipt GetIntegervReply)
getIntegerv c context_tag pname
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetIntegerv context_tag pname
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getLightfv ::
             Graphics.XHB.Connection.Types.Connection ->
               GetLightfv -> IO (Receipt GetLightfvReply)
getLightfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getLightiv ::
             Graphics.XHB.Connection.Types.Connection ->
               GetLightiv -> IO (Receipt GetLightivReply)
getLightiv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getMapdv ::
           Graphics.XHB.Connection.Types.Connection ->
             GetMapdv -> IO (Receipt GetMapdvReply)
getMapdv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getMapfv ::
           Graphics.XHB.Connection.Types.Connection ->
             GetMapfv -> IO (Receipt GetMapfvReply)
getMapfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getMapiv ::
           Graphics.XHB.Connection.Types.Connection ->
             GetMapiv -> IO (Receipt GetMapivReply)
getMapiv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getMaterialfv ::
                Graphics.XHB.Connection.Types.Connection ->
                  GetMaterialfv -> IO (Receipt GetMaterialfvReply)
getMaterialfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getMaterialiv ::
                Graphics.XHB.Connection.Types.Connection ->
                  GetMaterialiv -> IO (Receipt GetMaterialivReply)
getMaterialiv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getPixelMapfv ::
                Graphics.XHB.Connection.Types.Connection ->
                  CONTEXT_TAG -> Word32 -> IO (Receipt GetPixelMapfvReply)
getPixelMapfv c context_tag map
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetPixelMapfv context_tag map
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getPixelMapuiv ::
                 Graphics.XHB.Connection.Types.Connection ->
                   CONTEXT_TAG -> Word32 -> IO (Receipt GetPixelMapuivReply)
getPixelMapuiv c context_tag map
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetPixelMapuiv context_tag map
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getPixelMapusv ::
                 Graphics.XHB.Connection.Types.Connection ->
                   CONTEXT_TAG -> Word32 -> IO (Receipt GetPixelMapusvReply)
getPixelMapusv c context_tag map
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetPixelMapusv context_tag map
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getPolygonStipple ::
                    Graphics.XHB.Connection.Types.Connection ->
                      CONTEXT_TAG -> Bool -> IO (Receipt [Word8])
getPolygonStipple c context_tag lsb_first
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (data_GetPolygonStippleReply `fmap` deserialize))
       let req = MkGetPolygonStipple context_tag lsb_first
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getString ::
            Graphics.XHB.Connection.Types.Connection ->
              CONTEXT_TAG -> Word32 -> IO (Receipt GetStringReply)
getString c context_tag name
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetString context_tag name
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexEnvfv ::
              Graphics.XHB.Connection.Types.Connection ->
                GetTexEnvfv -> IO (Receipt GetTexEnvfvReply)
getTexEnvfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexEnviv ::
              Graphics.XHB.Connection.Types.Connection ->
                GetTexEnviv -> IO (Receipt GetTexEnvivReply)
getTexEnviv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexGendv ::
              Graphics.XHB.Connection.Types.Connection ->
                GetTexGendv -> IO (Receipt GetTexGendvReply)
getTexGendv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexGenfv ::
              Graphics.XHB.Connection.Types.Connection ->
                GetTexGenfv -> IO (Receipt GetTexGenfvReply)
getTexGenfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexGeniv ::
              Graphics.XHB.Connection.Types.Connection ->
                GetTexGeniv -> IO (Receipt GetTexGenivReply)
getTexGeniv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexImage ::
              Graphics.XHB.Connection.Types.Connection ->
                GetTexImage -> IO (Receipt GetTexImageReply)
getTexImage c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexParameterfv ::
                    Graphics.XHB.Connection.Types.Connection ->
                      GetTexParameterfv -> IO (Receipt GetTexParameterfvReply)
getTexParameterfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexParameteriv ::
                    Graphics.XHB.Connection.Types.Connection ->
                      GetTexParameteriv -> IO (Receipt GetTexParameterivReply)
getTexParameteriv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexLevelParameterfv ::
                         Graphics.XHB.Connection.Types.Connection ->
                           GetTexLevelParameterfv -> IO (Receipt GetTexLevelParameterfvReply)
getTexLevelParameterfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTexLevelParameteriv ::
                         Graphics.XHB.Connection.Types.Connection ->
                           GetTexLevelParameteriv -> IO (Receipt GetTexLevelParameterivReply)
getTexLevelParameteriv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
isList ::
         Graphics.XHB.Connection.Types.Connection ->
           CONTEXT_TAG -> Word32 -> IO (Receipt BOOL32)
isList c context_tag list
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (ret_val_IsListReply `fmap` deserialize))
       let req = MkIsList context_tag list
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
flush ::
        Graphics.XHB.Connection.Types.Connection -> CONTEXT_TAG -> IO ()
flush c context_tag
  = do let req = MkFlush context_tag
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
areTexturesResident ::
                      Graphics.XHB.Connection.Types.Connection ->
                        AreTexturesResident -> IO (Receipt AreTexturesResidentReply)
areTexturesResident c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
deleteTextures ::
                 Graphics.XHB.Connection.Types.Connection -> DeleteTextures -> IO ()
deleteTextures c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
genTextures ::
              Graphics.XHB.Connection.Types.Connection ->
                CONTEXT_TAG -> Int32 -> IO (Receipt [Word32])
genTextures c context_tag n
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (data_GenTexturesReply `fmap` deserialize))
       let req = MkGenTextures context_tag n
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
isTexture ::
            Graphics.XHB.Connection.Types.Connection ->
              CONTEXT_TAG -> Word32 -> IO (Receipt BOOL32)
isTexture c context_tag texture
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (ret_val_IsTextureReply `fmap` deserialize))
       let req = MkIsTexture context_tag texture
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getColorTable ::
                Graphics.XHB.Connection.Types.Connection ->
                  GetColorTable -> IO (Receipt GetColorTableReply)
getColorTable c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getColorTableParameterfv ::
                           Graphics.XHB.Connection.Types.Connection ->
                             GetColorTableParameterfv ->
                               IO (Receipt GetColorTableParameterfvReply)
getColorTableParameterfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getColorTableParameteriv ::
                           Graphics.XHB.Connection.Types.Connection ->
                             GetColorTableParameteriv ->
                               IO (Receipt GetColorTableParameterivReply)
getColorTableParameteriv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getConvolutionFilter ::
                       Graphics.XHB.Connection.Types.Connection ->
                         GetConvolutionFilter -> IO (Receipt GetConvolutionFilterReply)
getConvolutionFilter c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getConvolutionParameterfv ::
                            Graphics.XHB.Connection.Types.Connection ->
                              GetConvolutionParameterfv ->
                                IO (Receipt GetConvolutionParameterfvReply)
getConvolutionParameterfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getConvolutionParameteriv ::
                            Graphics.XHB.Connection.Types.Connection ->
                              GetConvolutionParameteriv ->
                                IO (Receipt GetConvolutionParameterivReply)
getConvolutionParameteriv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getSeparableFilter ::
                     Graphics.XHB.Connection.Types.Connection ->
                       GetSeparableFilter -> IO (Receipt GetSeparableFilterReply)
getSeparableFilter c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getHistogram ::
               Graphics.XHB.Connection.Types.Connection ->
                 GetHistogram -> IO (Receipt GetHistogramReply)
getHistogram c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getHistogramParameterfv ::
                          Graphics.XHB.Connection.Types.Connection ->
                            GetHistogramParameterfv ->
                              IO (Receipt GetHistogramParameterfvReply)
getHistogramParameterfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getHistogramParameteriv ::
                          Graphics.XHB.Connection.Types.Connection ->
                            GetHistogramParameteriv ->
                              IO (Receipt GetHistogramParameterivReply)
getHistogramParameteriv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getMinmax ::
            Graphics.XHB.Connection.Types.Connection ->
              GetMinmax -> IO (Receipt [Word8])
getMinmax c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (data_GetMinmaxReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getMinmaxParameterfv ::
                       Graphics.XHB.Connection.Types.Connection ->
                         GetMinmaxParameterfv -> IO (Receipt GetMinmaxParameterfvReply)
getMinmaxParameterfv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getMinmaxParameteriv ::
                       Graphics.XHB.Connection.Types.Connection ->
                         GetMinmaxParameteriv -> IO (Receipt GetMinmaxParameterivReply)
getMinmaxParameteriv c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getCompressedTexImageARB ::
                           Graphics.XHB.Connection.Types.Connection ->
                             GetCompressedTexImageARB ->
                               IO (Receipt GetCompressedTexImageARBReply)
getCompressedTexImageARB c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
deleteQueriesARB ::
                   Graphics.XHB.Connection.Types.Connection ->
                     DeleteQueriesARB -> IO ()
deleteQueriesARB c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
genQueriesARB ::
                Graphics.XHB.Connection.Types.Connection ->
                  CONTEXT_TAG -> Int32 -> IO (Receipt [Word32])
genQueriesARB c context_tag n
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (data_GenQueriesARBReply `fmap` deserialize))
       let req = MkGenQueriesARB context_tag n
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
isQueryARB ::
             Graphics.XHB.Connection.Types.Connection ->
               CONTEXT_TAG -> Word32 -> IO (Receipt BOOL32)
isQueryARB c context_tag id
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (ret_val_IsQueryARBReply `fmap` deserialize))
       let req = MkIsQueryARB context_tag id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getQueryivARB ::
                Graphics.XHB.Connection.Types.Connection ->
                  GetQueryivARB -> IO (Receipt GetQueryivARBReply)
getQueryivARB c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getQueryObjectivARB ::
                      Graphics.XHB.Connection.Types.Connection ->
                        GetQueryObjectivARB -> IO (Receipt GetQueryObjectivARBReply)
getQueryObjectivARB c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getQueryObjectuivARB ::
                       Graphics.XHB.Connection.Types.Connection ->
                         GetQueryObjectuivARB -> IO (Receipt GetQueryObjectuivARBReply)
getQueryObjectuivARB c req
  = do (receipt, rReceipt) <- newDeserReceipt
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt