module Graphics.XHB.Gen.DPMS
       (extension, getVersion, capable, getTimeouts, setTimeouts, enable,
        disable, forceLevel, info, module Graphics.XHB.Gen.DPMS.Types)
       where
import Graphics.XHB.Gen.DPMS.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
 
extension :: ExtensionId
extension = "DPMS"
 
getVersion ::
             Graphics.XHB.Connection.Types.Connection ->
               Word16 -> Word16 -> IO (Receipt GetVersionReply)
getVersion c client_major_version client_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetVersion client_major_version client_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
capable ::
          Graphics.XHB.Connection.Types.Connection -> IO (Receipt Bool)
capable c
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (capable_CapableReply `fmap` deserialize))
       let req = MkCapable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getTimeouts ::
              Graphics.XHB.Connection.Types.Connection ->
                IO (Receipt GetTimeoutsReply)
getTimeouts c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetTimeouts
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setTimeouts ::
              Graphics.XHB.Connection.Types.Connection -> SetTimeouts -> IO ()
setTimeouts c req
  = do putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
enable :: Graphics.XHB.Connection.Types.Connection -> IO ()
enable c
  = do let req = MkEnable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
disable :: Graphics.XHB.Connection.Types.Connection -> IO ()
disable c
  = do let req = MkDisable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
forceLevel ::
             Graphics.XHB.Connection.Types.Connection -> DPMSMode -> IO ()
forceLevel c power_level
  = do let req = MkForceLevel power_level
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
info ::
       Graphics.XHB.Connection.Types.Connection -> IO (Receipt InfoReply)
info c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkInfo
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt