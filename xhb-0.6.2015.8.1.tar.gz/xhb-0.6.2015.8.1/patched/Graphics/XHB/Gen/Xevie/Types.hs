module Graphics.XHB.Gen.Xevie.Types
       (deserializeError, deserializeEvent, QueryVersion(..),
        QueryVersionReply(..), Start(..), StartReply(..), End(..),
        EndReply(..), Datatype(..), Event(..), Send(..), SendReply(..),
        SelectInput(..), SelectInputReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent _ = Nothing
 
data QueryVersion = MkQueryVersion{client_major_version_QueryVersion
                                   :: Word16,
                                   client_minor_version_QueryVersion :: Word16}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "XEVIE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__
                     = 4 + size (client_major_version_QueryVersion x) +
                         size (client_minor_version_QueryVersion x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (client_major_version_QueryVersion x)
               serialize (client_minor_version_QueryVersion x)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{server_major_version_QueryVersionReply
                                             :: Word16,
                                             server_minor_version_QueryVersionReply :: Word16}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               server_major_version <- deserialize
               server_minor_version <- deserialize
               skip 20
               let _ = isCard32 length
               return
                 (MkQueryVersionReply server_major_version server_minor_version)
 
data Start = MkStart{screen_Start :: Word32}
           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Start where
        extensionId _ = "XEVIE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__ = 4 + size (screen_Start x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (screen_Start x)
               putSkip (requiredPadding size__)
 
data StartReply = MkStartReply{}
                deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize StartReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               let _ = isCard32 length
               return (MkStartReply)
 
data End = MkEnd{cmap_End :: Word32}
         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest End where
        extensionId _ = "XEVIE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__ = 4 + size (cmap_End x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (cmap_End x)
               putSkip (requiredPadding size__)
 
data EndReply = MkEndReply{}
              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize EndReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               let _ = isCard32 length
               return (MkEndReply)
 
data Datatype = DatatypeUnmodified
              | DatatypeModified
              deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Datatype where
        toValue DatatypeUnmodified{} = 0
        toValue DatatypeModified{} = 1
        fromValue 0 = DatatypeUnmodified
        fromValue 1 = DatatypeModified
 
data Event = MkEvent{}
           deriving (Show, Typeable, Eq, Ord)
 
instance Serialize Event where
        serialize x = do putSkip 32
        size x = 32
 
instance Deserialize Event where
        deserialize
          = do skip 32
               return (MkEvent)
 
data Send = MkSend{event_Send :: Event, data_type_Send :: Word32}
          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Send where
        extensionId _ = "XEVIE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__ = 4 + size (event_Send x) + size (data_type_Send x) + 64
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (event_Send x)
               serialize (data_type_Send x)
               putSkip 64
               putSkip (requiredPadding size__)
 
data SendReply = MkSendReply{}
               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize SendReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               let _ = isCard32 length
               return (MkSendReply)
 
data SelectInput = MkSelectInput{event_mask_SelectInput :: Word32}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SelectInput where
        extensionId _ = "XEVIE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4 + size (event_mask_SelectInput x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (event_mask_SelectInput x)
               putSkip (requiredPadding size__)
 
data SelectInputReply = MkSelectInputReply{}
                      deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize SelectInputReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               skip 24
               let _ = isCard32 length
               return (MkSelectInputReply)