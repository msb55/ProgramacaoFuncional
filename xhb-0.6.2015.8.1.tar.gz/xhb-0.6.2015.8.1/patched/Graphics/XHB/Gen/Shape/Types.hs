module Graphics.XHB.Gen.Shape.Types
       (deserializeError, deserializeEvent, OP, KIND, SO(..), SK(..),
        NotifyEvent(..), QueryVersion(..), QueryVersionReply(..),
        Rectangles(..), Mask(..), Combine(..), Offset(..),
        QueryExtents(..), QueryExtentsReply(..), SelectInput(..),
        InputSelected(..), InputSelectedReply(..), GetRectangles(..),
        GetRectanglesReply(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get NotifyEvent))
deserializeEvent _ = Nothing
 
type OP = Word8
 
type KIND = Word8
 
data SO = SOSet
        | SOUnion
        | SOIntersect
        | SOSubtract
        | SOInvert
        deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum SO where
        toValue SOSet{} = 0
        toValue SOUnion{} = 1
        toValue SOIntersect{} = 2
        toValue SOSubtract{} = 3
        toValue SOInvert{} = 4
        fromValue 0 = SOSet
        fromValue 1 = SOUnion
        fromValue 2 = SOIntersect
        fromValue 3 = SOSubtract
        fromValue 4 = SOInvert
 
data SK = SKBounding
        | SKClip
        | SKInput
        deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum SK where
        toValue SKBounding{} = 0
        toValue SKClip{} = 1
        toValue SKInput{} = 2
        fromValue 0 = SKBounding
        fromValue 1 = SKClip
        fromValue 2 = SKInput
 
data NotifyEvent = MkNotifyEvent{shape_kind_NotifyEvent :: SK,
                                 affected_window_NotifyEvent :: WINDOW,
                                 extents_x_NotifyEvent :: Int16, extents_y_NotifyEvent :: Int16,
                                 extents_width_NotifyEvent :: Word16,
                                 extents_height_NotifyEvent :: Word16,
                                 server_time_NotifyEvent :: TIMESTAMP, shaped_NotifyEvent :: Bool}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event NotifyEvent
 
instance Deserialize NotifyEvent where
        deserialize
          = do skip 1
               shape_kind <- liftM fromValue (deserialize :: Get KIND)
               skip 2
               affected_window <- deserialize
               extents_x <- deserialize
               extents_y <- deserialize
               extents_width <- deserialize
               extents_height <- deserialize
               server_time <- deserialize
               shaped <- deserialize
               skip 11
               return
                 (MkNotifyEvent shape_kind affected_window extents_x extents_y
                    extents_width
                    extents_height
                    server_time
                    shaped)
 
data QueryVersion = MkQueryVersion{}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryVersion where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data QueryVersionReply = MkQueryVersionReply{major_version_QueryVersionReply
                                             :: Word16,
                                             minor_version_QueryVersionReply :: Word16}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               let _ = isCard32 length
               return (MkQueryVersionReply major_version minor_version)
 
data Rectangles = MkRectangles{operation_Rectangles :: SO,
                               destination_kind_Rectangles :: SK,
                               ordering_Rectangles :: ClipOrdering,
                               destination_window_Rectangles :: WINDOW,
                               x_offset_Rectangles :: Int16, y_offset_Rectangles :: Int16,
                               rectangles_Rectangles :: [RECTANGLE]}
                deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Rectangles where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (undefined :: OP) + size (undefined :: KIND) +
                         size (undefined :: Word8)
                         + 1
                         + size (destination_window_Rectangles x)
                         + size (x_offset_Rectangles x)
                         + size (y_offset_Rectangles x)
                         + sum (map size (rectangles_Rectangles x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (operation_Rectangles x) :: OP)
               serialize (toValue (destination_kind_Rectangles x) :: KIND)
               serialize (toValue (ordering_Rectangles x) :: Word8)
               putSkip 1
               serialize (destination_window_Rectangles x)
               serialize (x_offset_Rectangles x)
               serialize (y_offset_Rectangles x)
               serializeList (rectangles_Rectangles x)
               putSkip (requiredPadding size__)
 
data Mask = MkMask{operation_Mask :: SO,
                   destination_kind_Mask :: SK, destination_window_Mask :: WINDOW,
                   x_offset_Mask :: Int16, y_offset_Mask :: Int16,
                   source_bitmap_Mask :: PIXMAP}
          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Mask where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (undefined :: OP) + size (undefined :: KIND) + 2 +
                         size (destination_window_Mask x)
                         + size (x_offset_Mask x)
                         + size (y_offset_Mask x)
                         + size (source_bitmap_Mask x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (operation_Mask x) :: OP)
               serialize (toValue (destination_kind_Mask x) :: KIND)
               putSkip 2
               serialize (destination_window_Mask x)
               serialize (x_offset_Mask x)
               serialize (y_offset_Mask x)
               serialize (source_bitmap_Mask x)
               putSkip (requiredPadding size__)
 
data Combine = MkCombine{operation_Combine :: SO,
                         destination_kind_Combine :: SK, source_kind_Combine :: SK,
                         destination_window_Combine :: WINDOW, x_offset_Combine :: Int16,
                         y_offset_Combine :: Int16, source_window_Combine :: WINDOW}
             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Combine where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__
                     = 4 + size (undefined :: OP) + size (undefined :: KIND) +
                         size (undefined :: KIND)
                         + 1
                         + size (destination_window_Combine x)
                         + size (x_offset_Combine x)
                         + size (y_offset_Combine x)
                         + size (source_window_Combine x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (operation_Combine x) :: OP)
               serialize (toValue (destination_kind_Combine x) :: KIND)
               serialize (toValue (source_kind_Combine x) :: KIND)
               putSkip 1
               serialize (destination_window_Combine x)
               serialize (x_offset_Combine x)
               serialize (y_offset_Combine x)
               serialize (source_window_Combine x)
               putSkip (requiredPadding size__)
 
data Offset = MkOffset{destination_kind_Offset :: SK,
                       destination_window_Offset :: WINDOW, x_offset_Offset :: Int16,
                       y_offset_Offset :: Int16}
            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest Offset where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__
                     = 4 + size (undefined :: KIND) + 3 +
                         size (destination_window_Offset x)
                         + size (x_offset_Offset x)
                         + size (y_offset_Offset x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (toValue (destination_kind_Offset x) :: KIND)
               putSkip 3
               serialize (destination_window_Offset x)
               serialize (x_offset_Offset x)
               serialize (y_offset_Offset x)
               putSkip (requiredPadding size__)
 
data QueryExtents = MkQueryExtents{destination_window_QueryExtents
                                   :: WINDOW}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest QueryExtents where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__ = 4 + size (destination_window_QueryExtents x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (destination_window_QueryExtents x)
               putSkip (requiredPadding size__)
 
data QueryExtentsReply = MkQueryExtentsReply{bounding_shaped_QueryExtentsReply
                                             :: Bool,
                                             clip_shaped_QueryExtentsReply :: Bool,
                                             bounding_shape_extents_x_QueryExtentsReply :: Int16,
                                             bounding_shape_extents_y_QueryExtentsReply :: Int16,
                                             bounding_shape_extents_width_QueryExtentsReply ::
                                             Word16,
                                             bounding_shape_extents_height_QueryExtentsReply ::
                                             Word16,
                                             clip_shape_extents_x_QueryExtentsReply :: Int16,
                                             clip_shape_extents_y_QueryExtentsReply :: Int16,
                                             clip_shape_extents_width_QueryExtentsReply :: Word16,
                                             clip_shape_extents_height_QueryExtentsReply :: Word16}
                       deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize QueryExtentsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               bounding_shaped <- deserialize
               clip_shaped <- deserialize
               skip 2
               bounding_shape_extents_x <- deserialize
               bounding_shape_extents_y <- deserialize
               bounding_shape_extents_width <- deserialize
               bounding_shape_extents_height <- deserialize
               clip_shape_extents_x <- deserialize
               clip_shape_extents_y <- deserialize
               clip_shape_extents_width <- deserialize
               clip_shape_extents_height <- deserialize
               let _ = isCard32 length
               return
                 (MkQueryExtentsReply bounding_shaped clip_shaped
                    bounding_shape_extents_x
                    bounding_shape_extents_y
                    bounding_shape_extents_width
                    bounding_shape_extents_height
                    clip_shape_extents_x
                    clip_shape_extents_y
                    clip_shape_extents_width
                    clip_shape_extents_height)
 
data SelectInput = MkSelectInput{destination_window_SelectInput ::
                                 WINDOW,
                                 enable_SelectInput :: Bool}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest SelectInput where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__
                     = 4 + size (destination_window_SelectInput x) +
                         size (enable_SelectInput x)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (destination_window_SelectInput x)
               serialize (enable_SelectInput x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data InputSelected = MkInputSelected{destination_window_InputSelected
                                     :: WINDOW}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest InputSelected where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4 + size (destination_window_InputSelected x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (destination_window_InputSelected x)
               putSkip (requiredPadding size__)
 
data InputSelectedReply = MkInputSelectedReply{enabled_InputSelectedReply
                                               :: Bool}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize InputSelectedReply where
        deserialize
          = do skip 1
               enabled <- deserialize
               skip 2
               length <- deserialize
               let _ = isCard32 length
               return (MkInputSelectedReply enabled)
 
data GetRectangles = MkGetRectangles{window_GetRectangles ::
                                     WINDOW,
                                     source_kind_GetRectangles :: SK}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest GetRectangles where
        extensionId _ = "SHAPE"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__
                     = 4 + size (window_GetRectangles x) + size (undefined :: KIND) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_GetRectangles x)
               serialize (toValue (source_kind_GetRectangles x) :: KIND)
               putSkip 3
               putSkip (requiredPadding size__)
 
data GetRectanglesReply = MkGetRectanglesReply{ordering_GetRectanglesReply
                                               :: ClipOrdering,
                                               rectangles_len_GetRectanglesReply :: Word32,
                                               rectangles_GetRectanglesReply :: [RECTANGLE]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize GetRectanglesReply where
        deserialize
          = do skip 1
               ordering <- liftM fromValue (deserialize :: Get Word8)
               skip 2
               length <- deserialize
               rectangles_len <- deserialize
               skip 20
               rectangles <- deserializeList (fromIntegral rectangles_len)
               let _ = isCard32 length
               return (MkGetRectanglesReply ordering rectangles_len rectangles)