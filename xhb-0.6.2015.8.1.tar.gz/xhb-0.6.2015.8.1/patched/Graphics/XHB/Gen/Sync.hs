module Graphics.XHB.Gen.Sync
       (extension, initialize, listSystemCounters, createCounter,
        destroyCounter, queryCounter, await, changeCounter, setCounter,
        createAlarm, changeAlarm, destroyAlarm, queryAlarm, setPriority,
        getPriority, module Graphics.XHB.Gen.Sync.Types)
       where
import Graphics.XHB.Gen.Sync.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
extension :: ExtensionId
extension = "SYNC"
 
initialize ::
             Graphics.XHB.Connection.Types.Connection ->
               Word8 -> Word8 -> IO (Receipt InitializeReply)
initialize c desired_major_version desired_minor_version
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkInitialize desired_major_version desired_minor_version
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
listSystemCounters ::
                     Graphics.XHB.Connection.Types.Connection ->
                       IO (Receipt ListSystemCountersReply)
listSystemCounters c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkListSystemCounters
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createCounter ::
                Graphics.XHB.Connection.Types.Connection ->
                  COUNTER -> INT64 -> IO ()
createCounter c id initial_value
  = do let req = MkCreateCounter id initial_value
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
destroyCounter ::
                 Graphics.XHB.Connection.Types.Connection -> COUNTER -> IO ()
destroyCounter c counter
  = do let req = MkDestroyCounter counter
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
queryCounter ::
               Graphics.XHB.Connection.Types.Connection ->
                 COUNTER -> IO (Receipt INT64)
queryCounter c counter
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (counter_value_QueryCounterReply `fmap` deserialize))
       let req = MkQueryCounter counter
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
await ::
        Graphics.XHB.Connection.Types.Connection ->
          [WAITCONDITION] -> IO ()
await c wait_list
  = do let req = MkAwait wait_list
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
changeCounter ::
                Graphics.XHB.Connection.Types.Connection ->
                  COUNTER -> INT64 -> IO ()
changeCounter c counter amount
  = do let req = MkChangeCounter counter amount
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
setCounter ::
             Graphics.XHB.Connection.Types.Connection ->
               COUNTER -> INT64 -> IO ()
setCounter c counter value
  = do let req = MkSetCounter counter value
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createAlarm ::
              Graphics.XHB.Connection.Types.Connection ->
                ALARM -> ValueParam Word32 -> IO ()
createAlarm c id value
  = do let req = MkCreateAlarm id value
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
changeAlarm ::
              Graphics.XHB.Connection.Types.Connection ->
                ALARM -> ValueParam Word32 -> IO ()
changeAlarm c id value
  = do let req = MkChangeAlarm id value
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
destroyAlarm ::
               Graphics.XHB.Connection.Types.Connection -> ALARM -> IO ()
destroyAlarm c alarm
  = do let req = MkDestroyAlarm alarm
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
queryAlarm ::
             Graphics.XHB.Connection.Types.Connection ->
               ALARM -> IO (Receipt QueryAlarmReply)
queryAlarm c alarm
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryAlarm alarm
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
setPriority ::
              Graphics.XHB.Connection.Types.Connection ->
                Word32 -> Int32 -> IO ()
setPriority c id priority
  = do let req = MkSetPriority id priority
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getPriority ::
              Graphics.XHB.Connection.Types.Connection ->
                Word32 -> IO (Receipt Int32)
getPriority c id
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (priority_GetPriorityReply `fmap` deserialize))
       let req = MkGetPriority id
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt