module Graphics.XHB.Gen.XF86Dri
       (extension, queryVersion, queryDirectRenderingCapable,
        openConnection, closeConnection, getClientDriverName,
        createContext, destroyContext, createDrawable, destroyDrawable,
        getDrawableInfo, getDeviceInfo, authConnection,
        module Graphics.XHB.Gen.XF86Dri.Types)
       where
import Graphics.XHB.Gen.XF86Dri.Types
import Graphics.XHB.Connection.Internal
import Graphics.XHB.Connection.Extension
import Graphics.XHB.Connection.Types
import Control.Concurrent.STM
import Foreign.C.Types
import Data.Word
import Data.Int
import Data.Binary.Get
import Data.Binary.Put (runPut)
import Graphics.XHB.Shared hiding (Event(..), Error(..))
 
extension :: ExtensionId
extension = "XFree86-DRI"
 
queryVersion ::
               Graphics.XHB.Connection.Types.Connection ->
                 IO (Receipt QueryVersionReply)
queryVersion c
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkQueryVersion
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
queryDirectRenderingCapable ::
                              Graphics.XHB.Connection.Types.Connection ->
                                Word32 -> IO (Receipt Bool)
queryDirectRenderingCapable c screen
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet
                                   (is_capable_QueryDirectRenderingCapableReply `fmap` deserialize))
       let req = MkQueryDirectRenderingCapable screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
openConnection ::
                 Graphics.XHB.Connection.Types.Connection ->
                   Word32 -> IO (Receipt OpenConnectionReply)
openConnection c screen
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkOpenConnection screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
closeConnection ::
                  Graphics.XHB.Connection.Types.Connection -> Word32 -> IO ()
closeConnection c screen
  = do let req = MkCloseConnection screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getClientDriverName ::
                      Graphics.XHB.Connection.Types.Connection ->
                        Word32 -> IO (Receipt GetClientDriverNameReply)
getClientDriverName c screen
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetClientDriverName screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
createContext ::
                Graphics.XHB.Connection.Types.Connection ->
                  CreateContext -> IO (Receipt Word32)
createContext c req
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (hw_context_CreateContextReply `fmap` deserialize))
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
destroyContext ::
                 Graphics.XHB.Connection.Types.Connection ->
                   Word32 -> Word32 -> IO ()
destroyContext c screen context
  = do let req = MkDestroyContext screen context
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
createDrawable ::
                 Graphics.XHB.Connection.Types.Connection ->
                   Word32 -> Word32 -> IO (Receipt Word32)
createDrawable c screen drawable
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet
                                   (hw_drawable_handle_CreateDrawableReply `fmap` deserialize))
       let req = MkCreateDrawable screen drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
destroyDrawable ::
                  Graphics.XHB.Connection.Types.Connection ->
                    Word32 -> Word32 -> IO ()
destroyDrawable c screen drawable
  = do let req = MkDestroyDrawable screen drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequest c chunk
 
getDrawableInfo ::
                  Graphics.XHB.Connection.Types.Connection ->
                    Word32 -> Word32 -> IO (Receipt GetDrawableInfoReply)
getDrawableInfo c screen drawable
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDrawableInfo screen drawable
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
getDeviceInfo ::
                Graphics.XHB.Connection.Types.Connection ->
                  Word32 -> IO (Receipt GetDeviceInfoReply)
getDeviceInfo c screen
  = do (receipt, rReceipt) <- newDeserReceipt
       let req = MkGetDeviceInfo screen
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt
 
authConnection ::
                 Graphics.XHB.Connection.Types.Connection ->
                   Word32 -> Word32 -> IO (Receipt Word32)
authConnection c screen magic
  = do (receipt, rReceipt) <- newEmptyReceipt
                                (runGet (authenticated_AuthConnectionReply `fmap` deserialize))
       let req = MkAuthConnection screen magic
       putAction <- serializeExtensionRequest c req
       let chunk = runPut putAction
       sendRequestWithReply c chunk rReceipt
       return receipt