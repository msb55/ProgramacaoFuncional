module Graphics.XHB.Gen.XPrint.Types
       (deserializeError, deserializeEvent, STRING8, PRINTER(..),
        PCONTEXT, GetDoc(..), EvMask(..), Detail(..), Attr(..),
        PrintQueryVersion(..), PrintQueryVersionReply(..),
        PrintGetPrinterList(..), PrintGetPrinterListReply(..),
        PrintRehashPrinterList(..), CreateContext(..), PrintSetContext(..),
        PrintGetContext(..), PrintGetContextReply(..),
        PrintDestroyContext(..), PrintGetScreenOfContext(..),
        PrintGetScreenOfContextReply(..), PrintStartJob(..),
        PrintEndJob(..), PrintStartDoc(..), PrintEndDoc(..),
        PrintPutDocumentData(..), PrintGetDocumentData(..),
        PrintGetDocumentDataReply(..), PrintStartPage(..),
        PrintEndPage(..), PrintSelectInput(..), PrintInputSelected(..),
        PrintInputSelectedReply(..), PrintGetAttributes(..),
        PrintGetAttributesReply(..), PrintGetOneAttributes(..),
        PrintGetOneAttributesReply(..), PrintSetAttributes(..),
        PrintGetPageDimensions(..), PrintGetPageDimensionsReply(..),
        PrintQueryScreens(..), PrintQueryScreensReply(..),
        PrintSetImageResolution(..), PrintSetImageResolutionReply(..),
        PrintGetImageResolution(..), PrintGetImageResolutionReply(..),
        NotifyEvent(..), AttributNotifyEvent(..))
       where
import Data.Word
import Data.Int
import Foreign.C.Types
import Data.Bits
import Data.Binary.Put
import Data.Binary.Get
import Data.Typeable
import Control.Monad
import Control.Exception
import Data.List
import Graphics.XHB.Shared hiding (Event, Error)
import qualified Graphics.XHB.Shared
import Graphics.XHB.Gen.Xproto.Types
       hiding (deserializeError, deserializeEvent)
import qualified Graphics.XHB.Gen.Xproto.Types
 
deserializeError :: Word8 -> Maybe (Get SomeError)
deserializeError _ = Nothing
 
deserializeEvent :: Word8 -> Maybe (Get SomeEvent)
deserializeEvent 0
  = return (liftM toEvent (deserialize :: Get NotifyEvent))
deserializeEvent 1
  = return (liftM toEvent (deserialize :: Get AttributNotifyEvent))
deserializeEvent _ = Nothing
 
type STRING8 = CChar
 
data PRINTER = MkPRINTER{nameLen_PRINTER :: Word32,
                         name_PRINTER :: [STRING8], descLen_PRINTER :: Word32,
                         description_PRINTER :: [STRING8]}
             deriving (Show, Typeable, Eq, Ord)
 
instance Serialize PRINTER where
        serialize x
          = do serialize (nameLen_PRINTER x)
               serializeList (name_PRINTER x)
               serialize (descLen_PRINTER x)
               serializeList (description_PRINTER x)
        size x
          = size (nameLen_PRINTER x) + sum (map size (name_PRINTER x)) +
              size (descLen_PRINTER x)
              + sum (map size (description_PRINTER x))
 
instance Deserialize PRINTER where
        deserialize
          = do nameLen <- deserialize
               name <- deserializeList (fromIntegral nameLen)
               descLen <- deserialize
               description <- deserializeList (fromIntegral descLen)
               return (MkPRINTER nameLen name descLen description)
 
newtype PCONTEXT = MkPCONTEXT Xid
                   deriving (Eq, Ord, Show, Serialize, Deserialize, XidLike)
 
data GetDoc = GetDocFinished
            | GetDocSecondConsumer
            deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum GetDoc where
        toValue GetDocFinished{} = 0
        toValue GetDocSecondConsumer{} = 1
        fromValue 0 = GetDocFinished
        fromValue 1 = GetDocSecondConsumer
 
data EvMask = EvMaskPrintMask
            | EvMaskAttributeMask
            deriving (Show, Eq, Ord, Enum, Typeable)
 
instance BitEnum EvMask where
        toBit EvMaskPrintMask{} = 0
        toBit EvMaskAttributeMask{} = 1
        fromBit 0 = EvMaskPrintMask
        fromBit 1 = EvMaskAttributeMask
 
data Detail = DetailStartJobNotify
            | DetailEndJobNotify
            | DetailStartDocNotify
            | DetailEndDocNotify
            | DetailStartPageNotify
            | DetailEndPageNotify
            deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Detail where
        toValue DetailStartJobNotify{} = 1
        toValue DetailEndJobNotify{} = 2
        toValue DetailStartDocNotify{} = 3
        toValue DetailEndDocNotify{} = 4
        toValue DetailStartPageNotify{} = 5
        toValue DetailEndPageNotify{} = 6
        fromValue 1 = DetailStartJobNotify
        fromValue 2 = DetailEndJobNotify
        fromValue 3 = DetailStartDocNotify
        fromValue 4 = DetailEndDocNotify
        fromValue 5 = DetailStartPageNotify
        fromValue 6 = DetailEndPageNotify
 
data Attr = AttrJobAttr
          | AttrDocAttr
          | AttrPageAttr
          | AttrPrinterAttr
          | AttrServerAttr
          | AttrMediumAttr
          | AttrSpoolerAttr
          deriving (Show, Eq, Ord, Enum, Typeable)
 
instance SimpleEnum Attr where
        toValue AttrJobAttr{} = 1
        toValue AttrDocAttr{} = 2
        toValue AttrPageAttr{} = 3
        toValue AttrPrinterAttr{} = 4
        toValue AttrServerAttr{} = 5
        toValue AttrMediumAttr{} = 6
        toValue AttrSpoolerAttr{} = 7
        fromValue 1 = AttrJobAttr
        fromValue 2 = AttrDocAttr
        fromValue 3 = AttrPageAttr
        fromValue 4 = AttrPrinterAttr
        fromValue 5 = AttrServerAttr
        fromValue 6 = AttrMediumAttr
        fromValue 7 = AttrSpoolerAttr
 
data PrintQueryVersion = MkPrintQueryVersion{}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintQueryVersion where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 0
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data PrintQueryVersionReply = MkPrintQueryVersionReply{major_version_PrintQueryVersionReply
                                                       :: Word16,
                                                       minor_version_PrintQueryVersionReply ::
                                                       Word16}
                            deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintQueryVersionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               major_version <- deserialize
               minor_version <- deserialize
               let _ = isCard32 length
               return (MkPrintQueryVersionReply major_version minor_version)
 
data PrintGetPrinterList = MkPrintGetPrinterList{printerNameLen_PrintGetPrinterList
                                                 :: Word32,
                                                 localeLen_PrintGetPrinterList :: Word32,
                                                 printer_name_PrintGetPrinterList :: [STRING8],
                                                 locale_PrintGetPrinterList :: [STRING8]}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintGetPrinterList where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 1
               let size__
                     = 4 + size (printerNameLen_PrintGetPrinterList x) +
                         size (localeLen_PrintGetPrinterList x)
                         + sum (map size (printer_name_PrintGetPrinterList x))
                         + sum (map size (locale_PrintGetPrinterList x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (printerNameLen_PrintGetPrinterList x)
               serialize (localeLen_PrintGetPrinterList x)
               serializeList (printer_name_PrintGetPrinterList x)
               serializeList (locale_PrintGetPrinterList x)
               putSkip (requiredPadding size__)
 
data PrintGetPrinterListReply = MkPrintGetPrinterListReply{listCount_PrintGetPrinterListReply
                                                           :: Word32,
                                                           printers_PrintGetPrinterListReply ::
                                                           [PRINTER]}
                              deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintGetPrinterListReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               listCount <- deserialize
               skip 20
               printers <- deserializeList (fromIntegral listCount)
               let _ = isCard32 length
               return (MkPrintGetPrinterListReply listCount printers)
 
data PrintRehashPrinterList = MkPrintRehashPrinterList{}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintRehashPrinterList where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 20
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data CreateContext = MkCreateContext{context_id_CreateContext ::
                                     Word32,
                                     printerNameLen_CreateContext :: Word32,
                                     localeLen_CreateContext :: Word32,
                                     printerName_CreateContext :: [STRING8],
                                     locale_CreateContext :: [STRING8]}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest CreateContext where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 2
               let size__
                     = 4 + size (context_id_CreateContext x) +
                         size (printerNameLen_CreateContext x)
                         + size (localeLen_CreateContext x)
                         + sum (map size (printerName_CreateContext x))
                         + sum (map size (locale_CreateContext x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_id_CreateContext x)
               serialize (printerNameLen_CreateContext x)
               serialize (localeLen_CreateContext x)
               serializeList (printerName_CreateContext x)
               serializeList (locale_CreateContext x)
               putSkip (requiredPadding size__)
 
data PrintSetContext = MkPrintSetContext{context_PrintSetContext ::
                                         Word32}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintSetContext where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 3
               let size__ = 4 + size (context_PrintSetContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintSetContext x)
               putSkip (requiredPadding size__)
 
data PrintGetContext = MkPrintGetContext{}
                     deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintGetContext where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 4
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data PrintGetContextReply = MkPrintGetContextReply{context_PrintGetContextReply
                                                   :: Word32}
                          deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintGetContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               context <- deserialize
               let _ = isCard32 length
               return (MkPrintGetContextReply context)
 
data PrintDestroyContext = MkPrintDestroyContext{context_PrintDestroyContext
                                                 :: Word32}
                         deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintDestroyContext where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 5
               let size__ = 4 + size (context_PrintDestroyContext x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintDestroyContext x)
               putSkip (requiredPadding size__)
 
data PrintGetScreenOfContext = MkPrintGetScreenOfContext{}
                             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintGetScreenOfContext where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 6
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data PrintGetScreenOfContextReply = MkPrintGetScreenOfContextReply{root_PrintGetScreenOfContextReply
                                                                   :: WINDOW}
                                  deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintGetScreenOfContextReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               root <- deserialize
               let _ = isCard32 length
               return (MkPrintGetScreenOfContextReply root)
 
data PrintStartJob = MkPrintStartJob{output_mode_PrintStartJob ::
                                     Word8}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintStartJob where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 7
               let size__ = 4 + size (output_mode_PrintStartJob x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (output_mode_PrintStartJob x)
               putSkip (requiredPadding size__)
 
data PrintEndJob = MkPrintEndJob{cancel_PrintEndJob :: Bool}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintEndJob where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 8
               let size__ = 4 + size (cancel_PrintEndJob x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (cancel_PrintEndJob x)
               putSkip (requiredPadding size__)
 
data PrintStartDoc = MkPrintStartDoc{driver_mode_PrintStartDoc ::
                                     Word8}
                   deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintStartDoc where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 9
               let size__ = 4 + size (driver_mode_PrintStartDoc x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (driver_mode_PrintStartDoc x)
               putSkip (requiredPadding size__)
 
data PrintEndDoc = MkPrintEndDoc{cancel_PrintEndDoc :: Bool}
                 deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintEndDoc where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 10
               let size__ = 4 + size (cancel_PrintEndDoc x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (cancel_PrintEndDoc x)
               putSkip (requiredPadding size__)
 
data PrintPutDocumentData = MkPrintPutDocumentData{drawable_PrintPutDocumentData
                                                   :: DRAWABLE,
                                                   len_data_PrintPutDocumentData :: Word32,
                                                   len_fmt_PrintPutDocumentData :: Word16,
                                                   len_options_PrintPutDocumentData :: Word16,
                                                   data_PrintPutDocumentData :: [Word8],
                                                   doc_format_PrintPutDocumentData :: [STRING8],
                                                   options_PrintPutDocumentData :: [STRING8]}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintPutDocumentData where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 11
               let size__
                     = 4 + size (drawable_PrintPutDocumentData x) +
                         size (len_data_PrintPutDocumentData x)
                         + size (len_fmt_PrintPutDocumentData x)
                         + size (len_options_PrintPutDocumentData x)
                         + sum (map size (data_PrintPutDocumentData x))
                         + sum (map size (doc_format_PrintPutDocumentData x))
                         + sum (map size (options_PrintPutDocumentData x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (drawable_PrintPutDocumentData x)
               serialize (len_data_PrintPutDocumentData x)
               serialize (len_fmt_PrintPutDocumentData x)
               serialize (len_options_PrintPutDocumentData x)
               serializeList (data_PrintPutDocumentData x)
               serializeList (doc_format_PrintPutDocumentData x)
               serializeList (options_PrintPutDocumentData x)
               putSkip (requiredPadding size__)
 
data PrintGetDocumentData = MkPrintGetDocumentData{context_PrintGetDocumentData
                                                   :: PCONTEXT,
                                                   max_bytes_PrintGetDocumentData :: Word32}
                          deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintGetDocumentData where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 12
               let size__
                     = 4 + size (context_PrintGetDocumentData x) +
                         size (max_bytes_PrintGetDocumentData x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintGetDocumentData x)
               serialize (max_bytes_PrintGetDocumentData x)
               putSkip (requiredPadding size__)
 
data PrintGetDocumentDataReply = MkPrintGetDocumentDataReply{status_code_PrintGetDocumentDataReply
                                                             :: Word32,
                                                             finished_flag_PrintGetDocumentDataReply
                                                             :: Word32,
                                                             dataLen_PrintGetDocumentDataReply ::
                                                             Word32,
                                                             data_PrintGetDocumentDataReply ::
                                                             [Word8]}
                               deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintGetDocumentDataReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               status_code <- deserialize
               finished_flag <- deserialize
               dataLen <- deserialize
               skip 12
               data_ <- deserializeList (fromIntegral dataLen)
               let _ = isCard32 length
               return
                 (MkPrintGetDocumentDataReply status_code finished_flag dataLen
                    data_)
 
data PrintStartPage = MkPrintStartPage{window_PrintStartPage ::
                                       WINDOW}
                    deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintStartPage where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 13
               let size__ = 4 + size (window_PrintStartPage x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (window_PrintStartPage x)
               putSkip (requiredPadding size__)
 
data PrintEndPage = MkPrintEndPage{cancel_PrintEndPage :: Bool}
                  deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintEndPage where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 14
               let size__ = 4 + size (cancel_PrintEndPage x) + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (cancel_PrintEndPage x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data PrintSelectInput = MkPrintSelectInput{context_PrintSelectInput
                                           :: PCONTEXT,
                                           event_PrintSelectInput :: ValueParam Word32}
                      deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintSelectInput where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 15
               let size__
                     = 4 + size (context_PrintSelectInput x) +
                         size (event_PrintSelectInput x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintSelectInput x)
               serialize (event_PrintSelectInput x)
               putSkip (requiredPadding size__)
 
data PrintInputSelected = MkPrintInputSelected{context_PrintInputSelected
                                               :: PCONTEXT}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintInputSelected where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 16
               let size__ = 4 + size (context_PrintInputSelected x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintInputSelected x)
               putSkip (requiredPadding size__)
 
data PrintInputSelectedReply = MkPrintInputSelectedReply{event_PrintInputSelectedReply
                                                         :: ValueParam Word32,
                                                         all_events_PrintInputSelectedReply ::
                                                         ValueParam Word32}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintInputSelectedReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               event <- deserialize
               all_events <- deserialize
               let _ = isCard32 length
               return (MkPrintInputSelectedReply event all_events)
 
data PrintGetAttributes = MkPrintGetAttributes{context_PrintGetAttributes
                                               :: PCONTEXT,
                                               pool_PrintGetAttributes :: Word8}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintGetAttributes where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 17
               let size__
                     = 4 + size (context_PrintGetAttributes x) +
                         size (pool_PrintGetAttributes x)
                         + 3
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintGetAttributes x)
               serialize (pool_PrintGetAttributes x)
               putSkip 3
               putSkip (requiredPadding size__)
 
data PrintGetAttributesReply = MkPrintGetAttributesReply{stringLen_PrintGetAttributesReply
                                                         :: Word32,
                                                         attributes_PrintGetAttributesReply ::
                                                         STRING8}
                             deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintGetAttributesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               stringLen <- deserialize
               skip 20
               attributes <- deserialize
               let _ = isCard32 length
               return (MkPrintGetAttributesReply stringLen attributes)
 
data PrintGetOneAttributes = MkPrintGetOneAttributes{context_PrintGetOneAttributes
                                                     :: PCONTEXT,
                                                     nameLen_PrintGetOneAttributes :: Word32,
                                                     pool_PrintGetOneAttributes :: Word8,
                                                     name_PrintGetOneAttributes :: [STRING8]}
                           deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintGetOneAttributes where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 19
               let size__
                     = 4 + size (context_PrintGetOneAttributes x) +
                         size (nameLen_PrintGetOneAttributes x)
                         + size (pool_PrintGetOneAttributes x)
                         + 3
                         + sum (map size (name_PrintGetOneAttributes x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintGetOneAttributes x)
               serialize (nameLen_PrintGetOneAttributes x)
               serialize (pool_PrintGetOneAttributes x)
               putSkip 3
               serializeList (name_PrintGetOneAttributes x)
               putSkip (requiredPadding size__)
 
data PrintGetOneAttributesReply = MkPrintGetOneAttributesReply{valueLen_PrintGetOneAttributesReply
                                                               :: Word32,
                                                               value_PrintGetOneAttributesReply ::
                                                               [STRING8]}
                                deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintGetOneAttributesReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               valueLen <- deserialize
               skip 20
               value <- deserializeList (fromIntegral valueLen)
               let _ = isCard32 length
               return (MkPrintGetOneAttributesReply valueLen value)
 
data PrintSetAttributes = MkPrintSetAttributes{context_PrintSetAttributes
                                               :: PCONTEXT,
                                               stringLen_PrintSetAttributes :: Word32,
                                               pool_PrintSetAttributes :: Word8,
                                               rule_PrintSetAttributes :: Word8,
                                               attributes_PrintSetAttributes :: [STRING8]}
                        deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintSetAttributes where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 18
               let size__
                     = 4 + size (context_PrintSetAttributes x) +
                         size (stringLen_PrintSetAttributes x)
                         + size (pool_PrintSetAttributes x)
                         + size (rule_PrintSetAttributes x)
                         + 2
                         + sum (map size (attributes_PrintSetAttributes x))
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintSetAttributes x)
               serialize (stringLen_PrintSetAttributes x)
               serialize (pool_PrintSetAttributes x)
               serialize (rule_PrintSetAttributes x)
               putSkip 2
               serializeList (attributes_PrintSetAttributes x)
               putSkip (requiredPadding size__)
 
data PrintGetPageDimensions = MkPrintGetPageDimensions{context_PrintGetPageDimensions
                                                       :: PCONTEXT}
                            deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintGetPageDimensions where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 21
               let size__ = 4 + size (context_PrintGetPageDimensions x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintGetPageDimensions x)
               putSkip (requiredPadding size__)
 
data PrintGetPageDimensionsReply = MkPrintGetPageDimensionsReply{width_PrintGetPageDimensionsReply
                                                                 :: Word16,
                                                                 height_PrintGetPageDimensionsReply
                                                                 :: Word16,
                                                                 offset_x_PrintGetPageDimensionsReply
                                                                 :: Word16,
                                                                 offset_y_PrintGetPageDimensionsReply
                                                                 :: Word16,
                                                                 reproducible_width_PrintGetPageDimensionsReply
                                                                 :: Word16,
                                                                 reproducible_height_PrintGetPageDimensionsReply
                                                                 :: Word16}
                                 deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintGetPageDimensionsReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               width <- deserialize
               height <- deserialize
               offset_x <- deserialize
               offset_y <- deserialize
               reproducible_width <- deserialize
               reproducible_height <- deserialize
               let _ = isCard32 length
               return
                 (MkPrintGetPageDimensionsReply width height offset_x offset_y
                    reproducible_width
                    reproducible_height)
 
data PrintQueryScreens = MkPrintQueryScreens{}
                       deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintQueryScreens where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 22
               let size__ = 4
               serialize (convertBytesToRequestSize size__ :: Int16)
               putSkip (requiredPadding size__)
 
data PrintQueryScreensReply = MkPrintQueryScreensReply{listCount_PrintQueryScreensReply
                                                       :: Word32,
                                                       roots_PrintQueryScreensReply :: [WINDOW]}
                            deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintQueryScreensReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               listCount <- deserialize
               skip 20
               roots <- deserializeList (fromIntegral listCount)
               let _ = isCard32 length
               return (MkPrintQueryScreensReply listCount roots)
 
data PrintSetImageResolution = MkPrintSetImageResolution{context_PrintSetImageResolution
                                                         :: PCONTEXT,
                                                         image_resolution_PrintSetImageResolution ::
                                                         Word16}
                             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintSetImageResolution where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 23
               let size__
                     = 4 + size (context_PrintSetImageResolution x) +
                         size (image_resolution_PrintSetImageResolution x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintSetImageResolution x)
               serialize (image_resolution_PrintSetImageResolution x)
               putSkip (requiredPadding size__)
 
data PrintSetImageResolutionReply = MkPrintSetImageResolutionReply{status_PrintSetImageResolutionReply
                                                                   :: Bool,
                                                                   previous_resolutions_PrintSetImageResolutionReply
                                                                   :: Word16}
                                  deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintSetImageResolutionReply where
        deserialize
          = do skip 1
               status <- deserialize
               skip 2
               length <- deserialize
               previous_resolutions <- deserialize
               let _ = isCard32 length
               return (MkPrintSetImageResolutionReply status previous_resolutions)
 
data PrintGetImageResolution = MkPrintGetImageResolution{context_PrintGetImageResolution
                                                         :: PCONTEXT}
                             deriving (Show, Typeable, Eq, Ord)
 
instance ExtensionRequest PrintGetImageResolution where
        extensionId _ = "XpExtension"
        serializeRequest x extOpCode
          = do putWord8 extOpCode
               putWord8 24
               let size__ = 4 + size (context_PrintGetImageResolution x)
               serialize (convertBytesToRequestSize size__ :: Int16)
               serialize (context_PrintGetImageResolution x)
               putSkip (requiredPadding size__)
 
data PrintGetImageResolutionReply = MkPrintGetImageResolutionReply{image_resolution_PrintGetImageResolutionReply
                                                                   :: Word16}
                                  deriving (Show, Typeable, Eq, Ord)
 
instance Deserialize PrintGetImageResolutionReply where
        deserialize
          = do skip 1
               skip 1
               skip 2
               length <- deserialize
               image_resolution <- deserialize
               let _ = isCard32 length
               return (MkPrintGetImageResolutionReply image_resolution)
 
data NotifyEvent = MkNotifyEvent{detail_NotifyEvent :: Word8,
                                 context_NotifyEvent :: PCONTEXT, cancel_NotifyEvent :: Bool}
                 deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event NotifyEvent
 
instance Deserialize NotifyEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               context <- deserialize
               cancel <- deserialize
               return (MkNotifyEvent detail context cancel)
 
data AttributNotifyEvent = MkAttributNotifyEvent{detail_AttributNotifyEvent
                                                 :: Word8,
                                                 context_AttributNotifyEvent :: PCONTEXT}
                         deriving (Show, Typeable, Eq, Ord)
 
instance Graphics.XHB.Shared.Event AttributNotifyEvent
 
instance Deserialize AttributNotifyEvent where
        deserialize
          = do skip 1
               detail <- deserialize
               skip 2
               context <- deserialize
               return (MkAttributNotifyEvent detail context)